OP = "geometry.build"


def _auto_positions(objects, room_width, room_depth, margin, gap):
    """Stable shelf-packing by recipe footprint; avoids the overlap-prone naive grid."""
    from cozy_engine import primitives
    usable_w = room_width - 2 * margin
    usable_d = room_depth - 2 * margin
    if usable_w <= 0 or usable_d <= 0:
        raise ValueError("margin leaves no usable floor area")
    rows = []
    for item in objects:
        recipes = primitives.recipes_for_atom(item["object"])
        if not recipes:
            raise ValueError(f"No primitive recipe for {item['object']}")
        sx, _, sz = recipes[0].size
        rows.append((item["object"], sx, sz))
    # Large footprints first reduces fragmentation; tie-break by stable object name.
    rows.sort(key=lambda v: (-max(v[1], v[2]), v[0]))
    x_cursor = 0.0
    z_cursor = 0.0
    row_depth = 0.0
    out = {}
    for name, sx, sz in rows:
        rotation = 0.0
        if sx > usable_w and sz <= usable_w:
            sx, sz, rotation = sz, sx, 90.0
        if sx > usable_w or sz > usable_d:
            raise ValueError(f"{name}: footprint {sx:.2f}x{sz:.2f}m does not fit room floor")
        if x_cursor > 0 and x_cursor + sx > usable_w:
            z_cursor += row_depth + gap
            x_cursor = 0.0
            row_depth = 0.0
        if z_cursor + sz > usable_d:
            raise ValueError("Objects do not fit room floor; increase room_width/room_depth or reduce count")
        out[name] = {
            "x": -room_width / 2 + margin + x_cursor + sx / 2,
            "z": -room_depth / 2 + margin + z_cursor + sz / 2,
            "rotation_y_deg": rotation,
            "scale": 1.0,
        }
        x_cursor += sx + gap
        row_depth = max(row_depth, sz)
    return out


def apply(context, params):
    from integration.runtime import dispatch_cozy
    from cozy_engine import primitives

    upstream = context["upstream"]
    plan = upstream["atmosphere"]["atmosphere"]
    palette_out = upstream["palette"]
    material_colors = palette_out.get("slot_colors") or plan.get("slot_colors", {})
    room_width = float(params.get("room_width", 5.0))
    room_depth = float(params.get("room_depth", 4.0))
    margin = float(params.get("margin", 0.35))
    gap = float(params.get("gap", 0.12))
    if room_width <= 0 or room_depth <= 0 or margin < 0 or gap < 0:
        raise ValueError("room_width/room_depth должны быть > 0, margin/gap >= 0")

    items = plan["objects"]
    placements = params.get("placements") or _auto_positions(items, room_width, room_depth, margin, gap)
    objects, boxes = [], []
    for item in items:
        name = item["object"]
        place = placements.get(name, {})
        x, z = float(place.get("x", 0.0)), float(place.get("z", 0.0))
        rotation = float(place.get("rotation_y_deg", 0.0))
        scale = float(place.get("scale", 1.0))
        if scale <= 0:
            raise ValueError(f"scale должен быть > 0 для {name}")
        result = dispatch_cozy("instantiate_object", {
            "object": name, "x": x, "z": z, "rotation_y_deg": rotation,
            "scale": scale, "colors": material_colors,
        })
        parts = result["parts"]
        # Conservative footprint from recipe dimensions; rotated AABB in XZ.
        recipe = primitives.RECIPES[result["recipe"]]
        sx, _, sz = recipe.size
        import math
        a = math.radians(rotation)
        hx = (abs(math.cos(a)) * sx + abs(math.sin(a)) * sz) * scale / 2
        hz = (abs(math.sin(a)) * sx + abs(math.cos(a)) * sz) * scale / 2
        box = {"object": name, "min_x": x-hx, "max_x": x+hx, "min_z": z-hz, "max_z": z+hz}
        boxes.append(box)
        objects.append({"object": name, "recipe": result["recipe"], "parts": parts, "position": {"x": x, "z": z}, "footprint": box})

    return {"geometry": {"room": {"width": room_width, "depth": room_depth},
                          "objects": objects, "footprints": boxes,
                          "coordinate_system": "XZ floor plane; Y up; meters"}}
