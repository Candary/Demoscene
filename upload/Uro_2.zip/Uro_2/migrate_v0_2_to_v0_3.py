#!/usr/bin/env python3
"""Migrate a project from the old single-file `engine.py` (v0.2) to the
new `uroboros` package (v0.3).

Что делает:
  * Находит `from engine import ...` и `import engine` во всех .py
    файлах под --target (исключая .venv, .git, .uroboros, сам uroboros/ и т.п.).
  * Переписывает:
        from engine import A, B, ...   ->  from uroboros import A, B, ...
        from engine import read_json   ->  from uroboros.memory import read_json
        import engine                  ->  import uroboros as engine
        import engine as e             ->  import uroboros as e
  * Сохраняет trailing-комментарии (однострочные импорты).
  * Опционально создаёт `engine.py`-шим в --target (для кода,
    который пока нельзя мигрировать).
  * Предупреждает про `from engine import *`, неизвестные имена и
    `engine.read_json` (последний не реэкспортируется из uroboros).

По умолчанию — dry-run. Реальная запись только с --apply.

Примеры:
    # 1. Посмотреть, что будет изменено (без записи)
    python scripts/migrate_v0_2_to_v0_3.py --target . --diff

    # 2. Применить с резервными копиями
    python scripts/migrate_v0_2_to_v0_3.py --target . --apply --backup

    # 3. Создать engine.py-шим рядом с patches/ (для кода, который
    #    нельзя тронуть сразу)
    python scripts/migrate_v0_2_to_v0_3.py --target . --apply --create-shim

    # 4. Проверка в CI: exit 1, если есть что мигрировать
    python scripts/migrate_v0_2_to_v0_3.py --target . --check

Коды возврата:
    0  успех
    1  --check нашёл изменения, либо были файлы с ошибками
    2  фатальная ошибка (нет пути, uroboros не установлен и т.п.)
"""
from __future__ import annotations

import argparse
import ast
import difflib
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable


# ---------------------------------------------------------------------------
# Mapping
# ---------------------------------------------------------------------------

# Имена, которые uroboros/__init__.py экспортирует на верхнем уровне.
UROBOROS_TOP = {
    "Uroboros", "FileMemory", "PatchRegistry",
    "FORMAT", "PatchError", "canonical", "digest",
}

# Имена, которые живут в подмодулях. Значение — полный путь модуля.
UROBOROS_SUBMODULE = {"read_json": "uroboros.memory"}

# Каталоги, которые никогда не мигрируются.
DEFAULT_EXCLUDES = {
    ".git", ".venv", "venv", "__pycache__", "build", "dist",
    ".pytest_cache", ".mypy_cache", ".tox", ".uroboros", "node_modules",
    "uroboros",  # сам пакет — не трогаем, чтобы не менять себя
}

SHIM_TEMPLATE = '''\
"""Auto-generated shim by scripts/migrate_v0_2_to_v0_3.py.

Обеспечивает обратную совместимость для кода, который всё ещё делает
`from engine import ...`. Удалите файл, когда все импорты будут
переведены на `uroboros`.
"""
from uroboros import (  # noqa: F401
    FORMAT, PatchError, FileMemory, PatchRegistry, Uroboros, canonical, digest,
)
from uroboros.memory import read_json  # noqa: F401

__all__ = [
    "Uroboros", "FileMemory", "PatchRegistry",
    "FORMAT", "PatchError", "canonical", "digest", "read_json",
]
'''


# ---------------------------------------------------------------------------
# Per-file result
# ---------------------------------------------------------------------------

@dataclass
class FileResult:
    path: Path
    changes: int = 0
    warnings: list[str] = field(default_factory=list)
    old_source: str = ""
    new_source: str = ""
    error: str | None = None

    @property
    def changed(self) -> bool:
        return self.changes > 0 and self.error is None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_from_import(module: str, names: list[tuple[str, str | None]]) -> str:
    parts = [f"{n} as {a}" if a else n for n, a in names]
    return f"from {module} import {', '.join(parts)}"


def _indent_of(line: str) -> str:
    return line[: len(line) - len(line.lstrip())]


def _extract_trailing_comment(line: str) -> tuple[str, str]:
    """Разделить `code  # comment` на (`code`, ` # comment`). Наивно,
    но для импортов достаточно: учитывает простой случай с кавычками."""
    stripped = line.rstrip()
    if " #" not in stripped:
        return stripped, ""
    idx = stripped.rfind(" #")
    before = stripped[:idx]
    # Если перед ` #` нечётное число кавычек — `#` внутри строки, не комментарий.
    if before.count('"') % 2 == 1 or before.count("'") % 2 == 1:
        return stripped, ""
    return before.rstrip(), stripped[idx:]


def _rewrite_importfrom(node: ast.ImportFrom) -> tuple[list[str], list[str]]:
    """Построить замену для `from engine import ...`.

    Возвращает (replacement_lines, warnings).
    Бросает ValueError для `from engine import *`.
    """
    if node.level != 0:
        raise ValueError("относительные импорты от `engine` не поддерживаются")
    if any(a.name == "*" for a in node.names):
        raise ValueError(
            "`from engine import *` не мигрируется автоматически; "
            "перечислите имена явно или используйте --create-shim"
        )

    top: list[tuple[str, str | None]] = []
    sub: dict[str, list[tuple[str, str | None]]] = {}
    unknown: list[str] = []

    for alias in node.names:
        name, asname = alias.name, alias.asname
        if name in UROBOROS_TOP:
            top.append((name, asname))
        elif name in UROBOROS_SUBMODULE:
            sub.setdefault(UROBOROS_SUBMODULE[name], []).append((name, asname))
        else:
            unknown.append(name)
            top.append((name, asname))

    warnings: list[str] = []
    if unknown:
        warnings.append(
            f"неизвестные имена {unknown}; оставлены в `from uroboros import ...` "
            f"(вероятно, упадут при импорте — используйте --create-shim)"
        )

    lines: list[str] = []
    if top:
        lines.append(_format_from_import("uroboros", top))
    for module, names in sub.items():
        lines.append(_format_from_import(module, names))
    return lines, warnings


def _uses_attr(tree: ast.AST, attr: str, names: set[str]) -> bool:
    """True, если в файле есть `<name>.<attr>` для какого-либо name из names."""
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id in names
            and node.attr == attr
        ):
            return True
    return False


# ---------------------------------------------------------------------------
# Core migration for one file
# ---------------------------------------------------------------------------

def migrate_file(path: Path) -> FileResult:
    res = FileResult(path=path)
    try:
        source = path.read_text("utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        res.error = f"read error: {exc}"
        return res

    res.old_source = source
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        res.error = f"syntax error: {exc}"
        return res

    lines = source.splitlines(keepends=True)
    # (start_lineno, end_lineno, replacement_lines, indent)
    edits: list[tuple[int, int, list[str], str]] = []

    for node in ast.walk(tree):
        # --- `from engine import ...` -----------------------------------
        if isinstance(node, ast.ImportFrom) and node.module == "engine":
            try:
                replacement, warns = _rewrite_importfrom(node)
            except ValueError as exc:
                res.warnings.append(f"{path}:{node.lineno}: {exc}")
                continue
            res.warnings.extend(f"{path}:{node.lineno}: {w}" for w in warns)
            start = node.lineno
            end = node.end_lineno or node.lineno
            indent = _indent_of(lines[start - 1])
            edits.append((start, end, replacement, indent))
            continue

        # --- `import engine` (или `import engine as X`) ------------------
        if isinstance(node, ast.Import):
            engine_aliases = [a for a in node.names if a.name == "engine"]
            if not engine_aliases:
                continue
            if len(engine_aliases) > 1:
                res.warnings.append(
                    f"{path}:{node.lineno}: несколько `engine` в одном import; пропущено"
                )
                continue
            alias = engine_aliases[0]
            target_name = alias.asname or "engine"
            others = [a for a in node.names if a is not alias]

            replacement: list[str] = []
            if others:
                other_text = ", ".join(
                    f"{a.name} as {a.asname}" if a.asname else a.name
                    for a in others
                )
                replacement.append(f"import {other_text}")
            replacement.append(f"import uroboros as {target_name}")

            if _uses_attr(tree, "read_json", {target_name}):
                res.warnings.append(
                    f"{path}:{node.lineno}: используется `{target_name}.read_json`; "
                    f"uroboros не реэкспортирует read_json на верхнем уровне. "
                    f"Используйте `from uroboros.memory import read_json` "
                    f"или запустите с --create-shim."
                )

            indent = _indent_of(lines[node.lineno - 1])
            start = node.lineno
            end = node.end_lineno or node.lineno
            edits.append((start, end, replacement, indent))

    if not edits:
        return res

    new_lines = list(lines)

    # Применяем снизу вверх, чтобы индексы не съезжали.
    for start, end, repl, indent in sorted(edits, key=lambda e: e[0], reverse=True):
        comment = ""
        if start == end:  # сохраняем trailing-комментарий только для однострочных
            _, comment = _extract_trailing_comment(lines[start - 1])

        block = [indent + r + "\n" for r in repl]
        if comment and block:
            block[-1] = block[-1].rstrip("\n") + "  " + comment.lstrip() + "\n"

        new_lines[start - 1:end] = block
        res.changes += 1

    new_source = "".join(new_lines)
    if new_source == source:
        res.changes = 0
        return res
    res.new_source = new_source
    return res


def apply_result(res: FileResult, *, backup: bool) -> None:
    if not res.changed:
        return
    if backup:
        shutil.copy2(res.path, res.path.with_suffix(res.path.suffix + ".bak"))
    res.path.write_text(res.new_source, "utf-8")


# ---------------------------------------------------------------------------
# File walking
# ---------------------------------------------------------------------------

def find_python_files(target: Path, excludes: list[Path]) -> Iterable[Path]:
    resolved_excludes = [e.resolve() for e in excludes if e.exists()]
    for p in target.rglob("*.py"):
        try:
            rp = p.resolve()
        except OSError:
            continue
        if any(rp.is_relative_to(e) for e in resolved_excludes):
            continue
        # Шим, который мы могли создать, не мигрируем.
        if p.name == "engine.py" and p.parent == target:
            continue
        if p.suffix == ".bak" or p.name.endswith(".py.bak"):
            continue
        yield p


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="migrate_v0_2_to_v0_3",
        description="Переписать `from engine import ...` на `from uroboros import ...`.",
    )
    p.add_argument("--target", default=".", help="корень проекта (default: .)")
    p.add_argument("--apply", action="store_true",
                   help="реально писать изменения (по умолчанию dry-run)")
    p.add_argument("--backup", action="store_true",
                   help="сохранять <file>.bak перед записью")
    p.add_argument("--diff", action="store_true",
                   help="печатать unified diff для каждого изменённого файла")
    p.add_argument("--create-shim", action="store_true",
                   help="создать engine.py-шим в --target (слой совместимости)")
    p.add_argument("--exclude", action="append", default=[], metavar="DIR",
                   help="дополнительный каталог для пропуска (можно повторять)")
    p.add_argument("--check", action="store_true",
                   help="выход с кодом 1, если что-то нужно мигрировать; "
                        "подразумевает --dry-run")
    p.add_argument("--quiet", action="store_true",
                   help="только итог, без списка файлов")
    return p


def _print_diff(res: FileResult) -> None:
    diff_lines = list(difflib.unified_diff(
        res.old_source.splitlines(keepends=True),
        res.new_source.splitlines(keepends=True),
        fromfile=str(res.path),
        tofile=str(res.path),
        n=2,
    ))
    sys.stdout.writelines(diff_lines)
    if diff_lines and not diff_lines[-1].endswith("\n"):
        sys.stdout.write("\n")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    target = Path(args.target).resolve()
    if not target.is_dir():
        print(f"error: не каталог: {target}", file=sys.stderr)
        return 2

    try:
        import uroboros  # noqa: F401
    except ImportError:
        print(
            "error: `uroboros` не импортируется. "
            "Сначала `pip install -e .` (или `pip install -e path/to/uroboros-0.3.0`).",
            file=sys.stderr,
        )
        return 2

    # --check подразумевает dry-run.
    if args.check:
        args.apply = False

    # Каталоги-исключения.
    excludes = [target / name for name in DEFAULT_EXCLUDES]
    for extra in args.exclude:
        excludes.append((target / extra).resolve())

    files = sorted(find_python_files(target, excludes))
    if not files:
        print(f"не найдено .py файлов в {target}")
        return 0

    total_imports = 0
    changed_files: list[FileResult] = []
    all_warnings: list[str] = []
    errored_files: list[FileResult] = []

    for path in files:
        try:
            res = migrate_file(path)
        except Exception as exc:  # noqa: BLE001 — защитно
            all_warnings.append(f"{path}: internal error: {type(exc).__name__}: {exc}")
            continue

        if res.error:
            errored_files.append(res)
            all_warnings.append(f"{path}: {res.error}")
            continue

        all_warnings.extend(res.warnings)
        if not res.changed:
            continue

        total_imports += res.changes
        changed_files.append(res)

        if args.apply:
            apply_result(res, backup=args.backup)
            if not args.quiet:
                print(f"rewrote: {res.path.relative_to(target)} "
                      f"({res.changes} import(s))")
                if args.diff:
                    _print_diff(res)
        else:
            if not args.quiet:
                print(f"would rewrite: {res.path.relative_to(target)} "
                      f"({res.changes} import(s))")
                if args.diff:
                    _print_diff(res)

    # Шим.
    shim_created = False
    shim_skipped = False
    if args.create_shim:
        shim_path = target / "engine.py"
        if shim_path.exists():
            print(f"warning: {shim_path.relative_to(target)} уже существует; "
                  f"не перезаписываю", file=sys.stderr)
            all_warnings.append(f"{shim_path}: уже существует")
            shim_skipped = True
        elif args.apply:
            shim_path.write_text(SHIM_TEMPLATE, "utf-8")
            shim_created = True
            print(f"created: {shim_path.relative_to(target)}")
        elif not args.quiet:
            print(f"would create: {shim_path.relative_to(target)}")

    # Итог.
    print()
    print(f"Scanned: {len(files)} file(s)")
    print(f"Changed: {len(changed_files)} file(s), {total_imports} import(s)")
    if args.create_shim:
        if shim_created:
            print("Shim: created")
        elif shim_skipped:
            print("Shim: skipped (already exists)")
        elif not args.apply:
            print("Shim: dry-run (use --apply to create)")
    if errored_files:
        print(f"Errors: {len(errored_files)} file(s)")
    if all_warnings:
        print(f"Warnings: {len(all_warnings)}")
        for w in all_warnings:
            print(f"  - {w}")
    if not args.apply and not args.check:
        print()
        print("Dry-run. Запустите с --apply, чтобы записать изменения.")

    if args.check and changed_files:
        return 1
    if errored_files:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())