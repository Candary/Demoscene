import tempfile, unittest
from pathlib import Path
from uroboros.btb import BTB
from uroboros.exchange import Router, envelope, ExchangeError
from uroboros.sigil import parse, SigilError
from uroboros.hybrid import HybridCore
from uroboros import Uroboros

class HybridTests(unittest.TestCase):
    def test_sigil_json_and_compact(self):
        self.assertEqual(parse('@uroboros\nintent: generate_scene\nuse: [cozy, color_matrix]\ncache: auto')['intent'],'generate_scene')
        self.assertEqual(parse('intent: x\nuse: [cozy, color_matrix]')['use'], ['cozy','color_matrix'])
        self.assertEqual(parse('{"intent":"x"}')['intent'],'x')
        with self.assertRaises(SigilError): parse('cache: auto')
    def test_exchange_roundtrip(self):
        r=Router(); r.register('cozy',lambda p,m:{'ok':p['x']})
        response=r.dispatch(envelope('glm','cozy','REQUEST',{'x':7}))
        self.assertEqual(response['payload']['ok'],7)
        with self.assertRaises(ExchangeError): r.dispatch({'protocol':'bad'})
    def test_btb_learns_then_predicts(self):
        with tempfile.TemporaryDirectory() as d:
            b=BTB(d,mode='prefetch',min_confidence=.5)
            sig='scene|cozy'
            b.observe(sig,[],['object','palette'])
            b.observe(sig,['object','palette'],['object','palette'])
            p=b.predict(sig,{'object':1,'palette':2})
            self.assertTrue(p['eligible'])
            self.assertEqual(set(p['prefetched']),{'object','palette'})
            b.observe(sig,['object','palette'],['object','palette'])
            self.assertEqual(b.stats()['btb_hit_rate'],1.0)
    def test_hybrid_facade(self):
        with tempfile.TemporaryDirectory() as d:
            patches=Path(__file__).parents[1]/'patches'
            e=Uroboros(root=Path(d)/'mem',patches=patches,workers=1)
            h=HybridCore(e,btb_root=Path(d)/'btb')
            plan={'format':'uroboros.patch/2','name':'tiny','nodes':[{'id':'a','target':'test','operation':'test.echo','params':{}}]}
            # Install a temporary trusted operation directly in registry for isolated core test.
            e.patches.ops['test.echo']=lambda c,p:{'ok':True}; e.patches.versions['test.echo']='v1'
            out=h.run(plan,require_approval=False)
            self.assertEqual(out['status'],'approved')
            self.assertIn('btb_stats',out['hybrid'])
            self.assertIn('cache_hit_rate',out['metrics'])

if __name__=='__main__': unittest.main()
