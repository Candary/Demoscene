OP = "scene.assemble"

def apply(context, params):
    upstream = context["upstream"]
    atmosphere = upstream["atmosphere"]["atmosphere"]
    geometry = upstream["geometry"]["geometry"]
    palette_out = upstream["palette"]
    return {"scene": {
        "schema": "cozy_scene/1",
        "room": atmosphere["room"],
        "atmosphere": {"hints": atmosphere.get("atmosphere_hints", {}),
                       "evidence_source": atmosphere.get("label_source"),
                       "provenance": atmosphere.get("provenance")},
        "geometry": geometry,
        "palette": palette_out.get("palette", {}),
        "slot_colors": palette_out.get("slot_colors", {}),
        "lighting": params.get("lighting", "soft_indirect"),
    }}
