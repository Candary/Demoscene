"""Small, deliberately non-programmable Sigil intent format."""
from __future__ import annotations
import json

class SigilError(ValueError):
    pass


def parse(text: str) -> dict:
    """Parse JSON body or a compact key: value block. Nested values use JSON."""
    source = text.strip()
    if source.startswith('@uroboros'):
        source = source[len('@uroboros'):].strip()
    if source.startswith('{'):
        obj = json.loads(source)
    else:
        obj = {}
        section = None
        for raw in source.splitlines():
            indent = len(raw) - len(raw.lstrip(' \t'))
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if line.endswith(':') and not line.startswith('-'):
                section = line[:-1].strip(); obj.setdefault(section, {}); continue
            if ':' not in line:
                raise SigilError(f"Expected key: value, got {line!r}")
            key, value = (x.strip() for x in line.split(':', 1))
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError:
                if value.startswith('[') and value.endswith(']'):
                    parsed = [part.strip().strip('"\'') for part in value[1:-1].split(',') if part.strip()]
                else:
                    parsed = value.strip('"\'')
            if section and indent > 0:
                obj[section][key] = parsed
            else:
                section = None; obj[key] = parsed
    if not isinstance(obj, dict) or not obj.get('intent'):
        raise SigilError("Sigil requires an object with non-empty 'intent'")
    allowed = {'intent','use','target','constraints','execution','cache','cycle','metadata'}
    unknown = set(obj) - allowed
    if unknown: raise SigilError(f"Unknown Sigil fields: {sorted(unknown)}")
    return obj


def to_json(intent: dict) -> str:
    parse(json.dumps(intent))
    return json.dumps(intent, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
