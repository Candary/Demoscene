# Обсуждение: Scene Manager + Uroboros для Demo Intro

**Дата:** 7 ноября 2026  
**Контекст:** Проект demo_intro (C++/OpenGL 3.3 + WebGL2 preview, v49), категория — Unlimited Demo  
**Участники:** пользователь + ассистент  
**Темы:** Scene Manager, парадигма Uroboros, DurationAllocator, PaletteEvolution

---

## 1. Исходный анализ проекта по четырём критериям

Проект demo_intro находится в зрелом состоянии (v49): рабочий raymarcher с SDF-морфингом, частицами, каплями, WebGL2-превью, code booster v1.1, валидация GLSL. Это сильная база, но ещё не финальная форма демо.

По критерию **лёгкости реализации** проект опирается на философию демосцены — максимум на минимум байт. Вся графика живёт в одном фрагментном шейдере (`shaders.h`, 866 строк), C++-обвязка минимальна (Win32 + OpenGL 3.3, без SDL/Glfw/Glew), есть `preview.html` для быстрой итерации. Тяжеловесные части — Scene Manager ещё не реализован, музыки нет вообще, упаковка в single .exe не сделана. Практические советы: не писать Scene Manager «на вырост», начать с Variant B (Uber Shader) — один шейдер, переключение через `uSceneId` + `smoothstep` на переходах; музыку брать сразу 4Klang (для 4K/64K) или C99 (для 64K); использовать `preview.html` как основной инструмент итерации; `glslangValidator` обязателен перед каждым `!*shader*` delivery.

По **оптимизации** уже сделано многое: lazy SDF eval (~370 вызовов/пиксель экономии), bounding-sphere skip для частиц, RayMarch 60→48 шагов, Coarse 30→20, DPR cap 2→1, precompute частиц, tetrahedron trick для `CalcNormal` (-33% вызовов `MapScene`). Что ещё можно выжать: half-precision floats (`mediump`), early ray termination по bounding sphere сцены, async compute для пост-процессинга, GPU profiling per scene через `glQueryCounter`. Python (Color Matrix / Cozy Engine) дальше оптимизировать не нужно — `cozy_palette()` ~60 мс после Phase 2, дальше закон Амдала.

По **гибкости** главный вопрос — какую compo-категорию целим. Для 4K реалистичен только Variant B (Uber Shader), для 64K — A или B, для Demo — полная свобода D (Cozy Generative) или E (Layered). Практические советы: разделить «контент сцены» и «оркестрацию», вынести параметры в `scenes.json` или `meta.auto`; per-scene uniforms (`uPrimaryColor`, `uAccentColor`, `uIntensity`, `uMotionSpeed`); transition library (CUT / CROSSFADE / WIPE / FLASH); mood spine — не более 5 опорных настроений на всё демо.

По **скорости генерации** есть два смысла: скорость рендеринга самого демо и скорость работы над ним. Headless Chrome даёт 30 FPS (ceiling тестовой среды, не проблема кода). На реальной GPU (GTX 750) после `!fix perf-all` выигрыш 2-3×. Target budget: 16.6 мс/кадр @ 1080p. Code booster v1.1 даёт top-3=77% на GLSL-автодополнении, Pandoc pipeline — 0.5 сек vs 5 сек старого генератора (25× быстрее), BTB (prefetch) читается в начале сессии.

Главный риск проекта — отсутствие музыки. Визуал без звука — это не demo, это screensaver. Начинать нужно с выбора soundtrack'а или synth'а.

---

## 2. Уточнение категории: Unlimited Demo

После выбора категории Demo стратегия пересматривается. Demo-категория снимает лимит размера (171 КБ .exe вписывается без сжатия), даёт максимальную свободу. Рекомендуемый variant — D (Cozy Generative) для showcase Cozy Engine или E (Layered Hybrid) для professional look. Variant C (Music-Synced) — если цель audio-driven visual.

Для Demo-категории нужно 4-8 сцен (стандарт), полный post-processing pipeline (bloom + grain + aberration + color grade + motion blur), rich transitions (alpha blend, multi-pass, beat-triggered). Конкуренция — по качеству, нужен polished look.

Конкретный план действий разбит на 8 фаз: сценарий (1 час), Scene Manager (3 часа), shader content (4-6 часов), music (4-8 часов), sync + transitions (2 часа), post-processing (2 часа), packaging (1 час), test + submit (1 час). Итого: ~18-24 часа работы.

Чего НЕ делать: не городить Layered Compositing сразу (начать с Timeline), не писать Scene Manager с audio-sync сразу, не оптимизировать GLSL дальше без GPU-профилинга, не откладывать музыку, не делать больше 8 сцен.

---

## 3. Анализ tools.py (Scene Manager)

tools.py — это наработка по Scene Manager. Вердикт: подходит на 60%. Это хороший **дизайн-тайм** инструмент (помогает создавать демо), но не покрывает критические gaps: нет codegen в C++, нет scene_generator (atom → GLSL), нет интеграции с code booster и glslangValidator. Для Demo compo нужно масштабировать.

Что хорошо: единый toolbox для трёх систем (Color Matrix + Cozy Engine + Scene Manager, имена не пересекаются); атомарный edit_show с undo/redo — ключевая фича для итеративного дизайна; analyze_audio с маркерами — автоматическое обнаружение drop/breakdown/build из коробки; suggest_palette с feel-метками — палитра driven by mood; bake как финальная сборка — концептуально верно.

Что плохо: непрозрачный bake (неясно, что он генерирует — C++ код, JSON, preview.html или всё сразу); нет scene_generator (mood → scenes); нет интеграции с code booster (booster_final.json, 74 КБ, 3674 контекста n-gram, top-3=77% на GLSL); suggest_transitions не имеет явной логики выбора типа; analyze_audio имеет unreliable warning; нет preview integration (проект имеет preview.html как основной инструмент итерации); нет GPU profiler integration.

Gap analysis показывает 6 критичных/важных пропущенных функций: scene_generator (critical), C++ codegen (critical), preview.html generator (important), GLSL validator integration (critical), code booster integration (important), GPU profiler (important).

Варианты масштабирования: минимальный (4 часа — добавить generate_scenes + codegen_cpp + validate_glsl), полный (12 часов — добавить ещё preview_generate + profile_gpu + music_sync + booster_integrate + compo_pack), гибридный (рекомендуется, ~10 часов — вариант 1 + preview_generate + music_sync + compo_pack).

---

## 4. Парадигма Uroboros для generate_scenes

Предложена парадигма Uroboros — цикличное использование кода и компонентов. Это не просто красивая метафора, а конкретный архитектурный принцип, который решает три ключевые проблемы проекта: дублирование кода (один и тот же SDF-примитив в 5 сценах не нужно переписывать), разрыв между сценами (палитра Scene 1 должна влиять на Scene 2), бесконечная вариативность (из 64 атомов можно построить фрактальные структуры, не увеличивая binary size).

Главная идея: выходные данные `generate_scenes` становятся входными для следующей итерации. Сцена → атом → shader → booster → новая сцена → ...

Шесть механизмов Uroboros:

**Рекурсивные атомы (Atoms-as-Scenes)** — атом не только геометрия, но и полноценная мини-сцена со своей длительностью, палитрой и mood. Сцена может содержать вложенные сцены, образуя фрактальную структуру. Один и тот же атом `nebula_raymarch` можно использовать как самостоятельную сцену на 30 сек, как под-сцену внутри `particle_swarm` на 10 сек, как микро-элемент внутри `morph_grid` на 3 сек. Без увеличения binary size — переиспользуется один и тот же shader-код. Реализация через расширение `cozy_engine/scenes.py` — добавить `children: list[Scene]` в `Scene` struct. 3 уровня вложенности = 3× больше визуального контента.

**Цветовая эстафета (Color Relay)** — палитра сцены становится seed для следующей сцены. Scene 1 имеет палитру anxiety (red/purple), Scene 2 использует эту палитру как seed для генерации палитры tension (red/orange), Scene 3 — warmth (orange/yellow). И так далее. Это не означает одинаковые цвета — цвета эволюционируют по mood flow. Реализация через новый параметр `seed` в `ColorToolbox.find_colors`.

**Shader Code Reuse через Booster** — booster учится на существующих shader'ах, генерирует новые, которые снова учат booster. 77% accuracy на GLSL completion → 3× быстрее написание shader'ов. Реализация через интеграцию `booster_final.json` в `generate_scenes`.

**Transitions как сцены (Transition-as-Scene)** — переход между сценами сам является сценой с собственной длительностью и mood. Transitions становятся first-class citizen, их можно анимировать, синхронизировать с музыкой. Реализация через расширение `SceneManager` — добавить `Transition` как подкласс `Scene`.

**Mood Flow как замкнутый цикл** — последняя сцена плавно переходит в первую, демо можно зациклить. Бесконечное демо для exhibition / art installation. Реализация через новый параметр `loop=True` в `generate_scenes`.

**Self-Referential Generation (версионирование)** — `generate_scenes` принимает предыдущую версию сцен, добавляет/изменяет только то, что нужно. Безопасная итеративная разработка, undo/redo на уровне всего show. Реализация через расширение `ShowSession` — добавить `clone()` и `validate()`.

Формат данных: Scene Graph с обратными ссылками. Не создавать новый формат, а расширить существующий `ShowSession` в `tools.py`. Класс `UroborosSceneGraph` содержит color_relay, atom_nesting, code_reuse, mood_cycle, transitions_as_scenes. Метод `generate_cpp()` генерирует C++ код с учётом всех Uroboros-механизмов.

В `FullToolbox` добавляются 3 инструмента: `generate_uroboros_scenes`, `codegen_uroboros_cpp`, `validate_uroboros`.

Практические советы: начать с Color Relay (30 минут), потом добавить Code Reuse через Booster (2 часа), Transitions-as-Scenes опционально (1 час), Atom Nesting только для Demo compo (3 часа), Mood Cycle для exhibition / art installation (30 минут).

---

## 5. Два аспекта Uroboros — независимые оси

Два механизма рассматриваются как независимые оси, которые могут работать раздельно или вместе. Они оперируют разными типами данных и решают разные задачи.

### Аспект 1: Рекурсивные атомы (Atoms-as-Scenes)

Атом Cozy Engine — это не только геометрия, но и полноценная мини-сцена со своей длительностью, палитрой и mood. Данные: атомы из `cozy_engine/vocab.py` (64 атома: 27 objects + 10 materials + 4 lights + 8 palettes + 5 quality + 10 rooms), структура вложенности (новый формат `SceneGraph` — дерево `Scene` с `children: list[Scene]`), длительности из `meta.auto`, shader mapping из `shaders.h`. Важно: данные атомов — это лексикон, а не содержимое сцен.

Cozy Engine уже имеет `SceneStore` (хранение сцен с `presence` — 64-мерный вектор атомов), `CozyMatrix` (64×64×64 матрица корреляций), `primitives.instantiate()` (создание геометрии из атома). Нужно добавить `SceneGraph` (расширение `SceneStore` с поддержкой вложенности), `AtomRenderer` (маппинг атомов на shader-функции), `DurationAllocator` (распределение total_duration по дереву).

Реализация через классы `SceneNode` (узел графа сцен — может быть атомом или контейнером) и `SceneGraph` (граф сцен с поддержкой рекурсивной вложенности). Методы: `flatten()` (разворачивает дерево в список листьев), `generate_shaders_h()`, `generate_scene_manager_cpp()`. Валидация: все листья имеют атом из ATOM_SHADER_MAP, глубина вложенности <= 3, сумма длительностей == total_duration.

Практичные советы: начать с 2 уровней вложенности (root → scenes → leaves); ограничить число уникальных атомов до 8-10 на всё демо (иначе binary size вырастет); DurationAllocator — ключевая функция; не оптимизировать GPU заранее (рекурсивные атомы — структурная оптимизация); валидация через glslangValidator обязательна.

### Аспект 2: Цветовая эстафета (Color Relay)

Палитра сцены становится seed для следующей сцены. Это создаёт визуальную согласованность: цвета плавно эволюционируют, а не скачут. Данные: палитры из `color_matrix_python/colorspace.py` (RGB hex, OKLab, LCH), feel-метки из Color Matrix prior (anxiety, tension, warmth, delight, neutral), seed-палитры (выход предыдущей сцены), empathy-вектор (64-мерный вектор, совпадает с Cozy Engine). Важно: данные Color Matrix — это палитры и feel-метки, а не атомы. Это другая ось данных.

Color Matrix уже имеет `find_colors(count, feel, seed)`, `check_palette()`, `simulate_cvd()`, empathy-вектор. Нужно добавить `ColorRelay` (класс для управления эстафетой палитр), `PaletteEvolution` (функция для плавной интерполяции), `FeelTransition` (маппинг mood flow на feel-метки).

Реализация через классы `Palette` (палитра с feel-меткой) и `ColorRelay` (управление эстафетой). Метод `generate_palette()` генерирует палитру с учётом seed, `_evolve_palette()` эволюционирует палитру от seed к target_feel (выбирает кандидатов в пределах max_delta_e), `_interpolate_empathy()` интерполирует empathy-вектор (70% seed, 30% target). Метод `generate_palette_sequence()` генерирует последовательность палитр для mood flow.

Практичные советы: `max_delta_e` — ключевой параметр (0.10 — очень плавные, 0.15 — умеренные, рекомендуется, 0.25 — выраженные, >0.30 — скачки); не использовать seed для первой сцены; валидация через `check_palette()` обязательна; empathy-вектор — мост между Color Matrix и Cozy Engine (оба 64-мерные, можно использовать для cross-system sync); не интерполировать палитры в runtime (генерируются на design-time, в runtime передаются как uniforms).

### Точка взаимодействия: Empathy-вектор

Empathy-вектор — мост между двумя аспектами. Color Matrix: empathy-вектор для feel-метки. Cozy Engine: presence-вектор для атома. Оба 64-мерные. Можно использовать для cross-system sync через функцию `sync_atom_with_feel(atom, feel)` — косинусное сходство. Если > 0.7 — атом хорошо согласуется с mood.

Практический workflow: design-time (задаём mood flow, генерируем палитры через ColorRelay, выбираем атомы через sync_atom_with_feel, строим дерево через SceneGraph), codegen (generate_shaders_h() + generate_scene_manager_cpp()), runtime (Scene Manager переключает сцены по timeline, каждая сцена использует свою палитру и свой shader).

Начать с Аспекта 2 (Color Relay) — проще в реализации (30 минут) и даёт быстрый визуальный результат. Потом добавить Аспект 1 (Рекурсивные атомы) — сложнее (3 часа), но даёт структурную основу для Demo compo. Cross-system sync — опционально.

---

## 6. DurationAllocator — распределение времени по дереву сцен

DurationAllocator — функция, которая берёт `total_duration` демо (например, 180 секунд) и распределяет его по дереву сцен с учётом: mood weight (какие сцены важнее — climax vs breakdown), atom complexity (какие атомы требуют больше времени для восприятия), user preferences (если заданы явные длительности), music structure (если есть audio markers — beat/section).

Главная идея: не просто делить поровну, а распределять пропорционально значимости.

Реализация через классы `DurationConfig` (конфигурация с mood_weights, atom_complexity, min/max_scene_duration, transition_duration) и `DurationAllocator` (распределяет total_duration по дереву). Метод `allocate()` — основной: вычисляет веса для каждого узла, выравнивает с audio markers (если есть), нормализует веса, распределяет duration, применяет min/max ограничения.

Вспомогательные методы: `_compute_weights()` (вес = mood_weight × atom_complexity для листьев, сумма весов детей для контейнеров), `_align_with_audio()` (корректирует веса под audio markers: drop ×1.5, breakdown ×0.7, build ×1.2), `_assign_durations()` (рекурсивное назначение), `_clamp_durations()` (применение min/max).

Стандартные mood weights: anxiety=0.8 (короткое, напряжённое), tension=1.0 (среднее), neutral=1.2 (длинное, спокойное), warmth=1.5 (длинное, приятное), delight=1.0 (среднее, яркое). Для Demo compo — увеличить warmth и neutral. Для 4K/64K — уменьшить все веса.

Atom complexity — не угадывать, замерять через `glQueryCounter`. Нормализовать: самый сложный атом = 2.0.

Audio markers — опционально, но мощно. Если есть `analyze_audio` из `tools.py`, передаём markers в DurationAllocator.

Min/max ограничения: min_scene_duration=5.0 (меньше — зритель не успеет воспринять), max_scene_duration=60.0 (больше — зритель заскучает). Для Demo compo: min=10.0, max=45.0.

Transition duration — вычитать из total_duration.

Интеграция с tools.py: инструмент `allocate_durations` в `FullToolbox` с параметрами total_duration, audio_markers, mood_weights, atom_complexity.

Effort: 2 часа на реализацию + 1 час на калибровку weights. Главный принцип: duration — это не случайное число, а функция от mood, atom и music.

---

## 7. PaletteEvolution — эволюция палитры во времени

PaletteEvolution отличается от Color Relay. Color Relay — механизм передачи палитры от сцены к сцене (seed → следующая палитра). PaletteEvolution — функция, описывающая КАК палитра меняется: внутри сцены (30 сек — от start до end), между сценами (transition 2 сек — плавный переход с сохранением гармонии), по mood flow (anxiety → tension → warmth → delight → neutral).

Главная идея: палитра — это не статичный набор цветов, а функция времени `palette(t)`, которая возвращает 5-8 цветов для любого момента демо.

Данные: палитры из `color_matrix_python/colorspace.py` (RGB hex, OKLCH — L, C, h), feel-метки, harmony type (analogous, complementary, triadic, split_complementary), animation path, empathy-вектор. Важно: PaletteEvolution работает в OKLCH пространстве (не RGB), потому что L и C — линейная интерполяция работает, а h (hue) — нужна кратчайшая дуга.

Реализация через классы `PaletteKeyframe` (ключевой кадр палитры — состояние в определённый момент времени: time, colors, feel, harmony, intensity) и `PaletteEvolution` (эволюция палитры во времени). Метод `evaluate(t)` возвращает палитру для момента времени t через интерполяцию между keyframes в OKLCH пространстве с smoothstep для плавности.

Ключевой метод `_interpolate_palettes()`: интерполирует L (lightness) линейно, C (chroma) линейно, h (hue) по кратчайшей дуге. Метод `_interpolate_hue()` — разница по модулю 360, выбор кратчайшего пути, интерполяция. Метод `_pad_palette()` дополняет палитру до target_size (дублированием последнего цвета, если число цветов разное).

Метод `to_uniforms(t)` возвращает uniforms для GLSL шейдера: uPrimaryColor, uSecondaryColor, uAccentColor, uBgColor, uIntensity. В шейдере используем uniforms вместо hardcoded цветов, с учётом intensity.

Factory функция `create_evolution_from_mood_flow()` создаёт PaletteEvolution из mood flow: для каждой сцены генерирует палитру через find_colors, проверяет гармонию через check_palette_harmony, вычисляет intensity (anxiety=0.9, tension=0.8, neutral=0.5, warmth=0.6, delight=1.0).

Практичные советы:

Интерполяция hue — кратчайшая дуга (критично!). Неправильно: `h = h_a + (h_b - h_a) * alpha` (может дать 350° → 10° через 180°). Правильно: `diff = (h_b - h_a) % 360.0; if diff > 180.0: diff -= 360.0; h = (h_a + diff * alpha) % 360.0`. Если h_a=350° (красный) и h_b=10° (тоже красный), линейная интерполяция даст переход через весь спектр, кратчайшая дуга — плавный переход.

Smoothstep для alpha (не линейно). Неправильно: `alpha = (t - t_a) / (t_b - t_a)`. Правильно: `alpha = alpha * alpha * (3.0 - 2.0 * alpha)`. Линейная интерполяция даёт "механические" переходы, smoothstep — плавное ускорение/замедление.

Не интерполировать в RGB (только OKLCH). RGB интерполяция даёт "грязные" цвета (серые оттенки в середине), OKLCH — perceptually uniform переходы.

Harmony preservation — не смешивать harmony types. Если Scene 1 analogous и Scene 2 complementary, transition даёт визуальный хаос. Если нужно сменить harmony — делать через transition scene (2-3 сек) с промежуточной harmony.

Intensity — не просто brightness. Неправильно: `col *= uIntensity`. Правильно: `L = L * uIntensity; C = C * (0.5 + 0.5 * uIntensity)` — chroma тоже масштабируется. Если intensity=0.5, просто умножение на 0.5 даст тёмные цвета, но нужны приглушённые (меньше chroma, не только меньше brightness).

Keyframes — не больше 5-7 на всё демо. Больше keyframes = больше вычислений + визуальный шум. 5-7 keyframes достаточно для 3-минутного демо.

Валидация через check_palette — после интерполяции проверять палитру. Интерполяция может дать палитру, где два цвета слишком похожи (delta_e < 0.06).

Интеграция с tools.py: инструменты `create_palette_evolution`, `evaluate_palette`, `get_palette_uniforms` в `FullToolbox`.

Effort: 3 часа на реализацию + 1 час на калибровку keyframes. Главный принцип: палитра — это функция времени, а не статичный набор цветов.

---

## Итоги обсуждения

Проект demo_intro готов к переходу на следующий уровень — от одиночного интро к полноценному Demo compo. Scene Manager (tools.py) — хороший фундамент (8/10 архитектурно для Unlimited Demo), но требует масштабирования через 3 критических инструмента: `generate_scenes`, `codegen_cpp`, `validate_glsl`.

Парадигма Uroboros — не просто красивая метафора, а конкретный архитектурный принцип, который решает три ключевые проблемы: дублирование кода, разрыв между сценами, бесконечная вариативность. Два аспекта (рекурсивные атомы и цветовая эстафета) — независимые оси, которые могут работать раздельно или вместе. Точка взаимодействия — empathy-вектор (64-мерный, совпадает между Color Matrix и Cozy Engine).

DurationAllocator и PaletteEvolution — два конкретных механизма, которые делают Uroboros работающим. DurationAllocator распределяет время пропорционально значимости (mood × atom complexity × audio markers). PaletteEvolution описывает палитру как функцию времени в OKLCH пространстве с кратчайшей дугой для hue и smoothstep для alpha.

Минимальный набор для старта (4 часа): Color Relay (30 мин) + Code Reuse через Booster (2 часа) + Transitions-as-Scenes (1 час) + Mood Cycle (30 мин). Полный набор (8 часов): + Atom Nesting (3 часа) + Self-Referential Generation (1 час).

Главный принцип Uroboros: выходные данные становятся входными. Сцена → палитра → следующая сцена → палитра → ... → замыкание цикла.

Следующий шаг: реализовать `generate_scenes` с Color Relay как первый конкретный механизм, затем интегрировать с code booster для shader generation, затем добавить DurationAllocator и PaletteEvolution для полного pipeline от design до runtime.