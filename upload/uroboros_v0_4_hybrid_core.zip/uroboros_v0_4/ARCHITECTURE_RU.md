# Архитектура интеграции Uroboros / Cozy Engine / Color Matrix

## 1. Назначение

Uroboros — не новый генератор геометрии и не новая цветовая система. Это orchestration layer: он передаёт компактные patches между уже существующими компонентами, контролирует зависимости, хранит версии и кеш, организует feedback loop и фиксирует пользовательское одобрение.

## 2. Границы ответственности

| Компонент | Ответственность | Чего не делает |
|---|---|---|
| GLM-5.2 | Интерпретирует запрос, выбирает цель, предлагает изменения параметров | Не исполняет произвольный Python, не утверждает результат сам |
| Uroboros | DAG, Patch contract, кеш, история, итерации, approval gate | Не дублирует алгоритмы Color/Cozy |
| Cozy Engine | Объекты, примитивные рецепты, evidence, scene plan, material slots | Пока не решает полноценную планировку комнаты |
| Color Matrix | RGB lookup, профили цвета, palette search/build/check, contrast/CVD checks | Не измеряет человеческие эмоции |
| Validator | Проверяет формальные ограничения сцены | Не заменяет визуальный осмотр или физический движок |
| C++/OpenGL Runtime | Получает подготовленную сцену и отображает её | Не вызывает GLM, Python, Cozy или Color в per-frame loop |

## 3. Объединённый контракт Patch

Каждая операция описывается одним JSON-объектом `uroboros.patch/2`:

```json
{
  "format": "uroboros.patch/2",
  "id": "uuid",
  "parent": null,
  "run": "run-id",
  "iteration": 0,
  "target": "cozy|color|scene|validator",
  "operation": "atmosphere.resolve",
  "inputs": {},
  "params": {},
  "outputs": {},
  "status": "proposed|executed|cache_hit|failed",
  "approval": "pending|approved|rejected",
  "metrics": {},
  "memory": {}
}
```

Управляющий объект содержит данные и параметры. Реальный исполняемый код находится в доверенных файлах `patches/*.py`; модель не может прислать исполняемый код.

## 4. Объединение функций по логике pipeline

Функции объединены не механически, а по смысловой стадии создания демосцены.

| Patch operation | Внутренние функции движков | Результат |
|---|---|---|
| `atmosphere.resolve` | `cozy_scene_plan` → `cozy_suggest_objects`, `cozy_palette`, evidence | Объекты-кандидаты, подсказки атмосферы, palette roles, slot colors, provenance |
| `geometry.build` | `instantiate_object` / `primitives.instantiate` | Наборы box/cylinder/sphere parts и footprint каждого объекта |
| `palette.build` | Color Matrix `check_palette`; опционально `build_palette` | Роли палитры, цвета слотов, отчёт различимости |
| `scene.assemble` | интеграционная операция | Объединённый `cozy_scene/1` artifact |
| `scene.validate` | интеграционный validator | Ошибки, предупреждения и список проверок |

Почему именно так:

1. Атмосферу и состав объектов следует решать вместе: `cozy_scene_plan` уже связывает тип комнаты, object candidates и цветовые роли. Разделение на два независимых вызова повторяло бы работу и могло бы дать несогласованные планы.
2. Геометрия отделена от атмосферы: один и тот же список объектов можно пересобирать при изменении только координат/масштаба без повторного поиска объектов.
3. Палитра выделена в узел: её можно менять и проверять независимо; геометрия зависит от неё только потому, что материалам примитивов нужны итоговые slot colors.
4. Сборка сцены — чистая композиция результатов, без повторного поиска или генерации примитивов.
5. Валидация — отдельный gate перед пользовательским approval; ошибка геометрии не должна маскироваться удачной генерацией палитры.

## 5. Граф pipeline

```mermaid
flowchart TD
    A[GLM-5.2 request] --> B[Uroboros Patch plan]
    B --> C[atmosphere.resolve / Cozy]
    C --> E[palette.build / Color Matrix]
    C --> D[geometry.build / Cozy primitives]
    E --> D
    D --> F[scene.assemble]
    E --> F
    C --> F
    F --> G[scene.validate]
    G --> H{Hard errors?}
    H -- yes --> I[Feedback: GLM or user]
    H -- no --> J[User approval]
    I --> B
    J -- rejected --> I
    J -- approved --> K[Immutable approved artifact]
    K --> L[Pipeline memory + mental checklist]
```

## 6. Цикл обратной связи

- GLM получает краткую сводку результатов, footprints, palette roles, validation и checklist.
- GLM возвращает только `changes` — словарь параметров существующих узлов.
- Uroboros применяет изменения, начинает следующую итерацию и повторно использует кеш тех узлов, чьи ключи не изменились.
- Валидатор отделяет hard errors от warnings.
- Пользовательское одобрение — единственный commit gate. Без него run остаётся `awaiting_approval`.

## 7. Что хранится в Memory

```text
.uroboros_memory/
├── memory.jsonl          # append-only events: patches, feedback, approval, run_finished
├── blobs/                # immutable SHA-256 payloads
├── cache/                # operation result cache
├── runs/                 # полные snapshots запусков
└── pipeline_cache/       # все записанные experiences для fingerprint pipeline
```

Memory делится логически на:

- Execution Memory — что запускалось, какие версии и сколько заняло времени.
- Design Memory — какие параметры и комбинации привели к одобренному артефакту.
- Mental Checklist — ошибки, предупреждения, причины отказа и поправки между итерациями.

Сохранение этих данных не означает автоматическое дообучение весов GLM. Сейчас это воспроизводимый контекст для будущих запросов и отдельного процесса обучения.

## 8. Кеш и инвалидирование

Ключ результата операции зависит от:

`hash(operation script, runtime fingerprint, params, upstream outputs)`.

Из этого следует:

- изменение позиции объекта инвалидирует `geometry.build`, `scene.assemble` и `scene.validate`;
- изменение палитры инвалидирует `palette.build`, `scene.assemble` и `scene.validate`;
- изменение только освещения инвалидирует только `scene.assemble` и последующую валидацию;
- изменение исходного кода или файлов данных Cozy/Color меняет runtime fingerprint и не позволяет использовать устаревшие результаты.

Это не обещание определённого ускорения: эффект измеряется на конкретном pipeline и машине.

## 9. Геометрическая валидация v0.3

Автоматическая стартовая расстановка использует детерминированный shelf-packing по footprint размеров примитивного рецепта. Validator проверяет:

- выход footprint за границы комнаты;
- пересечение footprint двух объектов;
- результат проверки различимости палитры.

Ограничения: не учитываются двери, окна, проходы, доступность объектов, коллизии отдельных частей mesh и навигационные пути. Поэтому это предварительная проверка layout, а не доказательство физической корректности интерьера.

## 10. Рендеринг

Pipeline выдаёт декларативный JSON artifact. Дальше Scene Manager или C++ Runtime может преобразовать его в собственный baked format. GLM/Python/Cozy/Color не должны находиться в кадро-критическом цикле OpenGL.
