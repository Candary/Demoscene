# Aesthetic principles

**Документ:** aesthetics.md
**Дата:** 2026-10-31
**Статус:** v0.4 (cleaned — removed all project-specific references, kept pure principles + 3-image comparison)
**Reference images:**
  - `upload/8474358583453.jpg` — Image 1: dark surreal warehouse с vivid bottle accents
  - `upload/Без названия - 2026-05-09T101224.022.jpg` — Image 2: fantasy mage с purple-pink lightning whip
  - `upload/Без названия - 2026-02-24T195643.383.jpg` — Image 3: skeletal zombie horse in graveyard

---

## 1. Контекст

Principles, не taste. Между `vec3(0.10, 0.40, 0.80)` и `vec3(0.15, 0.42, 0.85)` выбор делается по принципам. Без явных principles default = «разумно, но не вдохновенно».

Этот документ — **checklist для application**, не рецепт креативности.

---

## 2. Эстетический профиль

```
70 / 25 / 5  ratio
│    │   └─ focal point (single light source, narrative anchor)
│    └───── vivid color accents (contrast against dominant)
└────────── dominant dark space (mood, breathing room)
```

**Anti-pattern:** uniform saturation (всё ярко) — теряет depth, выглядит flat/amateur.

---

## 3. Color theory

### 3.1. 60-30-10 rule

| Role | Доля пикселей | Luminance | Saturation |
|------|---------------|-----------|------------|
| Dominant | 60% | 0.05-0.20 | 0.3-0.5 |
| Secondary | 30% | 0.20-0.50 | 0.5-0.7 |
| Accent | 10% | 0.50-0.90 | 0.7-1.0 |

### 3.2. Color harmony (выбрать ОДНУ, не смешивать)

| Harmony | Colors | Когда |
|---------|--------|-------|
| **Complementary** | 2 colors напротив (cyan↔magenta, blue↔orange, purple↔yellow) | dramatic contrast, tension |
| Analogous | 3 соседних цвета (blue→cyan→teal) | calm, serene, mood-driven |
| Triadic | 3 равноудалённых (red/yellow/blue) | vibrant, playful |
| Split-complementary | 1 base + 2 neighbors of opposite | balanced drama |

### 3.3. Saturation/luminance balance

- **Core (dark) regions**: saturation 0.6-0.8, luminance 0.15-0.25
- **Mid regions**: saturation 0.4-0.5, luminance 0.30-0.50
- **Rim/accent regions**: saturation 0.3-0.4, luminance 0.60-0.80

**Anti-pattern:** saturated core + saturated rim = muddy. Saturated core + desaturated rim = depth.

### 3.4. Sample palette (DRAMATIC_DARK)

```
deep_purple_core:  rgb(0.08, 0.05, 0.20)  HSL(255, 0.60, 0.13)
cyan_mid:          rgb(0.10, 0.40, 0.80)  HSL(215, 0.78, 0.45)
magenta_rim:       rgb(0.80, 0.30, 0.50)  HSL(340, 0.55, 0.55)
star_white_pure:   rgb(1.00, 1.00, 0.95)  HSL(50, 1.00, 0.97)
void_black:        rgb(0.02, 0.02, 0.03)
```

Mood: cold/dramatic/deep. Use cases: core glow, atmospheric depth, rim light.

---

## 4. Composition

### 4.1. Focal point singularity

- **1 focal point per frame.** Если >1 — competing attention, eye fatigue.
- Focal = brightest single element OR highest saturation OR center-most.
- Other elements supporting, НЕ competing.

### 4.2. Rule of thirds

- Camera target / focal element на пересечении thirds (не в центре кадра).
- Для static camera: shift focal to (0.33, 0.50) или (0.66, 0.50).
- Для moving camera: target trajectory проходит через thirds.

### 4.3. Background-foreground density contrast

- Background density < foreground density. **НЕ** заполняйте кадр равномерно.
- Background noise subtle (amplitude 0.3-0.5), foreground accents яркие (amplitude 0.6-1.0).

### 4.4. Vignette as attention director

- Gentle vignette: 0.7-0.85 at edges
- Strong vignette = amateur, eye senses manipulation
- No vignette = flat, lacks depth

---

## 5. Motion (Disney 12 simplified для real-time)

### 5.1. Easing

- **smoothstep(t)** для organic motion (НЕ linear)
- Linear только для mechanical rotation (gears, clock hands)
- `mix(a, b, smoothstep(0.0, 1.0, t))` — standard pattern

### 5.2. Anticipation (10% перед main motion)

- Перед «впрыгиванием» camera — slight pull-back (10% amplitude, 100ms)
- В GLSL: `pos += sin(t * 5.0) * 0.02` перед основным motion

### 5.3. Follow-through (15% после main motion)

- После резкой остановки — slight overshoot + dampened oscillation
- `pos = target + sin((t - t_stop) * 8.0) * exp(-(t - t_stop) * 3.0) * 0.05`

### 5.4. Camera motion: 1 primary axis

- 1 axis primary (largest amplitude)
- Other axes secondary (≤30% of primary amplitude)
- Anti-pattern: chaotic 3-axis motion = nausea, not aesthetic

### 5.5. Phase offsets для variety

- Multiple light sources: each phase offset by ~1.7 radians (golden angle 2.3998 / 2 ≈ 1.7)
- Avoid synchronized pulsing — looks mechanical

---

## 6. Density

### 6.1. FBM octaves

- **4-5 max.** После 5 — mush, lost detail.
- amplitude half per octave (standard fbm)
- frequency double per octave

### 6.2. Light nodes count

- **3-5 max.** Больше — competing, less impact.
- Если добавить ещё — удалить или объединить существующие.

### 6.3. Star field density

- 1 star per ~50×50 pixel area max
- Brighter stars rarer (logarithmic distribution)
- Anti-pattern: dense star field = noise, not depth

### 6.4. Detail vs scale

- Big shapes first, small details last
- 3-tier hierarchy: macro (composition) / meso (light nodes) / micro (noise detail)
- All three tiers needed; missing one = flat

---

## 7. Contrast & luminance balance

### 7.1. Dynamic range

- Min luminance in frame: 0.02-0.05 (deep shadow)
- Max luminance in frame: 0.85-1.00 (HDR accent)
- Ratio: 20:1 to 50:1 — cinematic
- < 10:1 = flat / TV-broadcast look
- > 100:1 = HDR display required, иначе crushed blacks

### 7.2. Tone mapping (ACES recommended)

- `finalColor = ACESFilm(color)` — preserves highlights, lifts shadows
- ACES: `color = (color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.14)`

### 7.3. Color contrast (S-channel in HSL)

- Average saturation in frame: 0.4-0.6
- Peak saturation (accents): 0.8-1.0
- Anti-pattern: average saturation > 0.7 = eye strain

---

## 8. Self-critique checklist

```
aesthetic_notes:
  color:
    - palette: <name>
    - dominant/secondary/accent ratio: <60/30/10 | other>
    - harmony: <complementary | analogous | triadic>
  composition:
    - focal_point: <which element>
    - rule_of_thirds: <yes/no, where>
    - bg/fg_density_contrast: <yes/no>
  motion:
    - easing: <smoothstep | linear | mixed>
    - anticipation: <yes/no>
    - follow_through: <yes/no>
    - primary_axis: <x | y | z>
  density:
    - fbm_octaves: <N>
    - light_nodes: <N>
    - star_density: <low | med | high>
  contrast:
    - dynamic_range: <min/max luminance>
    - tone_mapping: <ACES | raw | other>
  reference_target:
    - which reference image this aims for: <path or description>
    - delta from reference: <what's different>
  self_critique:
    - 1-2 sentences: what works, what doesn't, what to try next
```

**Если любой пункт empty** — task не закрыт, вернуться к generation.

---

## 9. Comparative analysis — Image 1 vs Image 2 vs Image 3

### 9.1 Image 1: dark surreal warehouse (`upload/8474358583453.jpg`)

**Content:** dim warehouse, concrete walls, red bulb hanging, figure wrapped in cables, floor densely covered with colorful plastic bottles (pink/blue/green/orange/purple).

**Aesthetic profile:**
- Ratio: ~65/30/5 (dark dominant / bottle accents / red bulb focal)
- Color harmony: **chaotic multicolor** (6+ colors, no single harmony)
- Focal: red bulb (single, clear, directional lighting)
- Composition: figure center, bottles distributed — no rule of thirds
- Motion: static (gallery installation aesthetic)
- Dynamic range: ~30:1
- Narrative: figure eerie but passive

**Strongest principle:** focal singularity (red bulb).
**Weakest:** color harmony (chaotic multicolor).
**Archetype:** static surreal (gallery).

### 9.2 Image 2: fantasy mage with lightning whip (`upload/Без названия - 2026-05-09T101224.022.jpg`)

**Content:** old mage white hair/beard, red-purple glowing eyes, dark worn robes, combat pose. Right hand wields energy whip made of purple-pink lightning (S-shape around body). Dark scene, twisted dead trees background, floating debris, orange-red sparks and embers, ground fire glow.

**Aesthetic profile:**
- Ratio: ~60/30/10 (dark scene / whip+sparks accent / mage+eyes focal)
- Color harmony: **complementary** (purple-pink whip HSL ~320° ↔ orange-red sparks HSL ~25°)
- Focal: mage eyes + whip S-curve (dual, but whip leads eye)
- Composition: mage center — no rule of thirds, BUT whip S-curve creates dynamic flow
- Motion: strong implied (combat pose, whip S-curve, sparks trajectory)
- Dynamic range: ~50:1 (cinematic)
- Narrative: mage active combat — clear subject

**Strongest principle:** complementary color harmony + implied motion.
**Weakest:** ratio (10% accent > ideal 5%).
**Archetype:** dynamic dramatic (cinematic action).

### 9.3 Image 3: skeletal zombie horse in graveyard (`upload/Без названия - 2026-02-24T195643.383.jpg`)

**Content:** skeletal zombie horse with exposed bones, visible ribs, decayed flesh and blood traces, purple-red mane hanging in strands, halter on head, walking with head down. Night graveyard scene, tombstones and stones scattered, stone cross on right side, distant blurred tombstones. Purple-blue tone overall, crescent moon in sky, dead branches from upper left, hazy moonlight, Halloween horror atmosphere.

**Aesthetic profile:**
- Ratio: ~75/20/5 (dark graveyard dominant / purple-blue tone / crescent moon focal) — **closest to ideal 70/25/5 of all 3**
- Color harmony: **analogous** (purple-blue-violet, single harmony, focused but less dramatic than complementary)
- Focal: dual (crescent moon + zombie horse) — horse is subject, moon is light source
- Composition: horse walking diagonally, off-center — **rule of thirds ✓** (best of 3)
- Motion: implied walking (horse stride) — between Image 1 (static) and Image 2 (combat)
- Dynamic range: ~20:1 — **lowest of 3** (atmospheric, not cinematic)
- Narrative: strong (zombie horse + graveyard + Halloween mood, clear subject + setting)
- Tone: muted, atmospheric, fog/moonlight — distinct от flat (Img 1) и HDR (Img 2)

**Strongest principles:** ratio (closest to ideal) + rule of thirds + density control.
**Weakest:** dynamic range (low even for atmospheric style).
**Archetype:** atmospheric horror (mood-driven).

### 9.4 Score (9 principles, 3-way)

| Principle | Img 1 (warehouse) | Img 2 (mage) | Img 3 (horse) | Winner |
|-----------|-------------------|--------------|----------------|--------|
| 70/25/5 ratio (§2) | 65/30/5 ✓ | 60/30/10 | **75/20/5** ✓✓ | **Img 3** |
| Color harmony (§3.2) | chaotic | **complementary** | analogous | **Img 2** |
| Focal singularity (§4.1) | **single (bulb)** | dual | dual | **Img 1** |
| Rule of thirds (§4.2) | no | no (S-curve flow) | **yes (off-center)** ✓ | **Img 3** |
| Density balance (§6) | bottles very dense | sparks distributed | **sparse, controlled** | **Img 3** |
| Dynamic range (§7.1) | ~30:1 | **~50:1** | ~20:1 | **Img 2** |
| Motion (§5) | static | **strong implied** | implied (walking) | **Img 2** |
| Narrative (§4.1) | passive | **active combat** | active walking + setting | **Img 2** |
| Tone mapping (§7.2) | flat | **HDR/ACES feel** | muted atmospheric | **Img 2** |

**First places:** Image 1 = 1/9. Image 2 = 5/9. Image 3 = 3/9.

### 9.5 Principled verdict (3-way)

**Image 2 wins** by principles (5/9 first places). Image 3 is **strong second** (3/9), Image 1 is weakest (1/9).

**Image 2 wins on:** color harmony, dynamic range, motion, narrative, tone.
**Image 3 wins on:** ratio, rule of thirds, density.
**Image 1 wins on:** focal singularity (only).

**Image 2 vs Image 3 head-to-head:** Image 2 wins on drama (complementary harmony, HDR, motion). Image 3 wins on calm (ratio, composition, density). Different aesthetic targets — Image 2 for action, Image 3 for atmosphere.

### 9.6 Three aesthetic archetypes

| Archetype | Image | Defining traits | Best for |
|-----------|-------|-----------------|----------|
| **Static surreal** | Img 1 | chaotic color, static, single focal, gallery mood | ambient / menu / title screens |
| **Dynamic dramatic** | Img 2 | complementary harmony, motion, HDR, narrative action | action scenes, combat, climactic moments |
| **Atmospheric horror** | Img 3 | analogous harmony, muted tone, sparse density, mood-driven | exploration, mystery, somber scenes |

### 9.7 Honest caveat

This is **principled verdict**, не taste. Principles in this doc favor:
- Complementary over multicolor OR analogous harmony (drama > calm)
- Motion over static
- Cinematic dynamic range over muted
- Narrative action over ambient mood

If your taste prefers Image 3's atmospheric horror (calm, muted, mood-driven) — that's valid. Different aesthetics serve different contexts (gallery vs action film vs horror film vs illustration).

The 3 archetypes are not ranked absolutely — they serve different goals. Image 2 wins **by these principles**, but Image 3 might be the right choice for a different mood.
