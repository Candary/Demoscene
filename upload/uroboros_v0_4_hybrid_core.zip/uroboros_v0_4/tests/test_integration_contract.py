import json
import tempfile
import unittest
from pathlib import Path

from uroboros import Uroboros, FORMAT
from integration.runtime import runtime_fingerprint

ROOT = Path(__file__).resolve().parents[1]

class IntegrationTests(unittest.TestCase):
    def test_fingerprint_is_stable(self):
        self.assertEqual(runtime_fingerprint(), runtime_fingerprint())

    def test_real_engine_pipeline(self):
        plan = {
            "format": FORMAT,
            "name": "test-room",
            "nodes": [
                {"id": "atmosphere", "target": "cozy", "operation": "atmosphere.resolve",
                 "params": {"room": "living_room", "count": 3, "must_have": ["sofa"]}},
                {"id": "geometry", "target": "cozy", "operation": "geometry.build", "needs": ["atmosphere", "palette"],
                 "params": {"room_width": 7.0, "room_depth": 6.0, "margin": 0.5}},
                {"id": "palette", "target": "color", "operation": "palette.build", "needs": ["atmosphere"], "params": {}},
                {"id": "scene", "target": "scene", "operation": "scene.assemble",
                 "needs": ["atmosphere", "geometry", "palette"], "params": {}},
                {"id": "validation", "target": "validator", "operation": "scene.validate",
                 "needs": ["scene", "palette"], "params": {}},
            ],
        }
        with tempfile.TemporaryDirectory() as tmp:
            engine = Uroboros(root=tmp, patches=ROOT / "patches", workers=2,
                              runtime_fingerprint=runtime_fingerprint())
            result = engine.run(plan, max_iterations=1, require_approval=False)
            warm = engine.run(plan, max_iterations=1, require_approval=False)
            self.assertEqual(result["status"], "approved")
            self.assertEqual(warm["status"], "approved")
            self.assertTrue(all(p["status"] == "cache_hit" for p in warm["final"]["patches"]))
            self.assertIn("scene", result["final"]["outputs"])
            self.assertIn("validation", result["final"]["outputs"])
            scene = result["final"]["outputs"]["scene"]["scene"]
            self.assertEqual(scene["schema"], "cozy_scene/1")
            self.assertTrue(scene["geometry"]["objects"])
            self.assertTrue((Path(tmp) / "memory.jsonl").exists())
            self.assertTrue((Path(tmp) / "pipeline_cache").exists())

    def test_feedback_loop_reuses_unchanged_nodes(self):
        plan = {
            "format": FORMAT, "name": "feedback-room",
            "nodes": [
                {"id": "atmosphere", "target": "cozy", "operation": "atmosphere.resolve",
                 "params": {"room": "living_room", "count": 3, "must_have": ["sofa"]}},
                {"id": "geometry", "target": "cozy", "operation": "geometry.build", "needs": ["atmosphere", "palette"],
                 "params": {"room_width": 6.0, "room_depth": 6.0, "margin": 0.5}},
                {"id": "palette", "target": "color", "operation": "palette.build", "needs": ["atmosphere"], "params": {}},
                {"id": "scene", "target": "scene", "operation": "scene.assemble",
                 "needs": ["atmosphere", "geometry", "palette"], "params": {}},
                {"id": "validation", "target": "validator", "operation": "scene.validate",
                 "needs": ["scene", "palette"], "params": {}},
            ],
        }
        with tempfile.TemporaryDirectory() as tmp:
            engine = Uroboros(root=tmp, patches=ROOT / "patches", workers=2,
                              runtime_fingerprint=runtime_fingerprint())
            def feedback(result, iteration):
                if iteration == 0:
                    return engine.make_feedback({"geometry": {"params": {"room_width": 8.0}}},
                                                iteration=1, reason="widen room")
                return None
            result = engine.run(plan, max_iterations=2, feedback=feedback,
                                approval=lambda r: r["outputs"]["geometry"]["geometry"]["room"]["width"] == 8.0)
            self.assertTrue(result["approved"])
            self.assertEqual(len(result["iterations"]), 2)
            second = result["iterations"][1]["result"]["patches"]
            statuses = {p["operation"]: p["status"] for p in second}
            self.assertEqual(statuses["atmosphere.resolve"], "cache_hit")
            self.assertEqual(statuses["palette.build"], "cache_hit")
            self.assertEqual(statuses["geometry.build"], "executed")

    def test_requires_explicit_approval(self):
        plan = {
            "format": FORMAT, "name": "approval-gate",
            "nodes": [
                {"id": "atmosphere", "target": "cozy", "operation": "atmosphere.resolve",
                 "params": {"room": "living_room", "count": 2}},
            ],
        }
        with tempfile.TemporaryDirectory() as tmp:
            engine = Uroboros(root=tmp, patches=ROOT / "patches", workers=1,
                              runtime_fingerprint=runtime_fingerprint())
            result = engine.run(plan, max_iterations=1, require_approval=True)
            self.assertEqual(result["status"], "awaiting_approval")
            self.assertFalse(result["approved"])

if __name__ == "__main__":
    unittest.main()
