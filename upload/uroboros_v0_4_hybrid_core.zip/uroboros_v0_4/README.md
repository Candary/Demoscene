# Uroboros + Cozy Engine + Color Matrix — v0.4

Интеграционная реализация для переданных **Cozy Engine v1.2** и **Color Matrix v11**. Uroboros связывает существующие функции движков в один итерационный pipeline, хранит историю и кеш на диске и не считает результат готовым до пользовательского одобрения.

**SQLite не используется.** Основной язык патчей — Python. Данные управления — JSON/JSONL; большие бинарные данные остаются в файлах движков или сохраняются как SHA-256 blobs.

## Что реализовано

- Единый interchange-контракт `uroboros.patch/2`.
- Реальные адаптеры к исходным `ColorToolbox` и `CozyToolbox`; исходные пакеты движков сохранены без изменения.
- Пять операций pipeline: `atmosphere.resolve`, `geometry.build`, `palette.build`, `scene.assemble`, `scene.validate`.
- Связь Cozy → Color: Cozy выбирает объекты/роли, Color Matrix предоставляет цветовые профили и проверку палитры, цвета передаются в примитивы через material slots. При пользовательской базовой палитре цвета распределяются по фиксированному порядку ролей `wall`, `floor`, `textile_main`, `textile_accent`, `wood`, `light`.
- Итерации: GLM или человек меняет только параметры узлов; затем pipeline пересчитывает затронутые операции и повторно запрашивает одобрение.
- Файловый кеш операций, журнал событий, полные snapshots запусков и pipeline experience cache.
- Ключ кеша учитывает хеш patch-скрипта, параметры, upstream-входы и fingerprint исходного кода/данных движков.
- `scene.validate` проверяет границы комнаты, пересечение footprint-областей объектов и палитру.
- Опциональный callback для GLM-5.2 через OpenAI-compatible client. Uroboros не исполняет код, сгенерированный моделью.

## Быстрый запуск

Требования: Python 3.10+, NumPy. Проект содержит исходные данные и модули движков.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m unittest discover -s engines/color_matrix/tests -v
python examples/build_cozy_scene.py
```

Скрипт спросит подтверждение результата. Если пользователь отклонит результат, можно ввести JSON с изменениями параметров. Пример:

```json
{"geometry":{"params":{"placements":{"sofa":{"x":-0.4,"z":0.2}}}}}
```

Одобрение возможно только если `scene.validate` не вернул hard errors и callback пользователя вернул `True`. Если итерации закончились или пользователь не одобрил сцену, статус будет `awaiting_approval`, а не `approved`.

## Подключение GLM-5.2

GLM API намеренно не зашит в проект: URL, ключ и совместимость SDK зависят от вашего сервера. Создайте OpenAI-compatible client и передайте callback из `integration.glm`:

```python
from openai import OpenAI
from integration.glm import make_glm_feedback
from integration.runtime import runtime_fingerprint
from uroboros import Uroboros

client = OpenAI(
    api_key="YOUR_API_KEY",
    base_url="YOUR_GLM_COMPATIBLE_BASE_URL",
)
feedback = make_glm_feedback(client, model="GLM-5.2")
engine = Uroboros(
    root=".uroboros_memory",
    patches="patches",
    glm_propose=feedback,
    workers=2,
    runtime_fingerprint=runtime_fingerprint(),
)
# engine.run(plan, approval=your_user_approval_callback, max_iterations=4)
```

Это пример точки подключения, не подтверждение совместимости с конкретным endpoint. Реальный вызов GLM-5.2 и формат ответа должны быть проверены в вашей среде. GLM возвращает JSON-параметры, а не Python-код. Список узлов и параметров ограничен адаптером.

## Структура проекта

```text
uroboros_cozy_color_v0_3/
├── uroboros/              # Uroboros core: patch, DAG, cache, feedback, approval
├── patches/               # allow-listed Python operations
├── integration/           # adapters to Color/Cozy + optional GLM callback
├── engines/color_matrix/  # supplied Color Matrix + Cozy Engine + datasets
├── examples/              # executable example pipeline
├── tests/                 # integration tests
├── .uroboros_memory/      # created on run: local persistent memory
└── artifacts/             # created by example: run + approved scene JSON
```

## Данные и форматы

Поставка использует исходные файлы из архива:

- Color Matrix v11: `engines/color_matrix/output/color-matrix-full-rgb-v11.npz`.
- Cozy Matrix: `engines/color_matrix/output/cozy_data/cozy_matrix.npz`.
- Cozy color statistics: `cozy_color_stats.json`.

Никакой миграции в HDF5 не выполняется. В предоставленном архиве движков данные находятся в NPZ. Если HDF5 остаётся целевым форматом Color Matrix, нужен отдельный этап миграции reader/writer и тестов эквивалентности; текущая интеграция не притворяется, что это уже сделано.

## Ограничения текущей реализации

1. `geometry.build` создаёт стартовую расстановку shelf-packing по габаритам рецептов. Это не полноценный интерьерный планировщик.
2. `scene.validate` использует консервативные footprint AABB; пока нет проверки дверей/окон, проходов, траекторий движения, 3D mesh collisions или навигации.
3. CVD-пары для атмосферной палитры по умолчанию выводятся как warnings, а не hard errors. Для UI/графиков включайте `require_cvd_distinguishability` в параметрах узла `validation`.
4. Cozy-данные основаны на подписях GPT-4o, а не на человеческом опросе. Это отражается в provenance и не переименовывается в «человеческое ощущение уюта».
5. Эмоциональные характеристики Color Matrix остаются prior-оценками; `intensity` не является информационно-теоретической энтропией.
6. Реальный GLM-5.2 не запускался в рамках сборки. Нужна проверка endpoint и слепая оценка качества результата.
7. Это доверенная локальная среда, не sandbox. Не загружайте сторонние patch-файлы без проверки.

## Производительность и кеш

- Color/Cozy toolboxes загружаются лениво один раз на процесс.
- Независимые узлы одного DAG-слоя выполняются параллельно (`workers`). Перед увеличением числа потоков проверьте thread-safety и нагрузку NumPy.
- Cache key = operation + patch script hash + runtime fingerprint + params + upstream input hash.
- Полный pipeline trace сохраняется отдельно от кеша операций; поэтому кеширование не стирает историю итераций.
- Повторный запуск с теми же входами и теми же версиями движков должен дать cache hits для всех пяти операций.
- Никакие ускорения заранее не заявляются: измеряйте cold start, warm cache, latency каждого узла и peak RAM на целевой машине.

## Проверки

Сборка проверяется двумя наборами тестов:

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s engines/color_matrix/tests -v
```

Первый набор проверяет реальный end-to-end pipeline и cache reuse. Второй — оригинальные тесты поставленных движков. Результаты тестирования конкретной поставки указаны в `IMPLEMENTATION_REPORT_RU.md`.

## Uroboros v0.4 — Hybrid Core

v0.4 добавляет Hybrid facade поверх v0.3 без удаления старого API:

- `uroboros.sigil.parse()` — компактный декларативный intent parser;
- `uroboros.exchange` — общий envelope `uroboros.exchange/1` и локальный Router;
- `uroboros.btb.BTB` — файловые сигнатуры, Shadow Mode и ограниченный resource prefetch;
- `uroboros.hybrid.HybridCore` — связывает BTB и patch/DAG executor;
- агрегированные метрики cache, processing, wall time, cycles и BTB.

Подробности: [HYBRID_CORE_ARCHITECTURE_RU.md](HYBRID_CORE_ARCHITECTURE_RU.md).

Пример:

```bash
python examples/run_hybrid.py
```

BTB по умолчанию работает в `shadow`: первые запуски обучают сигнатуры и проверяют прогнозы, не меняя основной pipeline. Для режима prefetch:

```python
hybrid = HybridCore(engine, btb_mode="prefetch", min_confidence=0.75)
```

В v0.4 prefetch выбирает только уже доступные ресурсы, переданные вызывающей стороной; самостоятельный файловый loader пока не включён.
