// demo_runtime.cpp — минимальный рантайм для Scene Manager.
// Загружает demo.smt → рендерит через gl_executor.hpp.
// Намного проще main.cpp (1091 строк) — вся логика сцены в .smt.
//
// Сборка (MSVC): cl /std:c++17 /EHsc demo_runtime.cpp /link opengl32.lib user32.lib gdi32.lib
// Сборка (MinGW): g++ -std=c++17 -o demo_runtime.exe demo_runtime.cpp -lopengl32 -luser32 -lgdi32
//
// Запуск: demo_runtime.exe demo.smt
// ESC — выход.

#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <stdio.h>
#include <stdint.h>
#include <string>

#include "opengl_loader.h"
#include "sm_runtime.hpp"
#include "gl_executor.hpp"

// --- HUD: GDI-to-texture overlay ---
static HDC     g_hudDC = nullptr;
static HBITMAP g_hudBmp = nullptr;
static void*   g_hudBits = nullptr;
static GLuint  g_hudTex = 0;
static GLuint  g_hudProg = 0;
static GLuint  g_hudVAO = 0;
static int     g_hudW = 0, g_hudH = 0;

static const char* kHudVS = R"GLSL(
#version 330 core
void main() {
    vec2 p[4] = vec2[4](vec2(-1.0,-1.0), vec2(1.0,-1.0), vec2(-1.0,1.0), vec2(1.0,1.0));
    gl_Position = vec4(p[gl_VertexID], 0.0, 1.0);
}
)GLSL";

static const char* kHudFS = R"GLSL(
#version 330 core
uniform sampler2D uTex;
uniform vec2 uRes;
out vec4 FragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / uRes;
    // DIB is top-down (biHeight=-h), GL texture is bottom-up.
    // Flip Y to match: top of DIB → top of screen.
    uv.y = 1.0 - uv.y;
    FragColor = texture(uTex, uv);
}
)GLSL";

static GLuint compileHudShader(GLenum type, const char* src) {
    GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    return sh;  // simplified — no error check for brevity
}

static void initHUD(int w, int h) {
    g_hudW = w; g_hudH = h;
    // Create memory DC + DIB section (32-bit BGRA, top-down).
    g_hudDC = CreateCompatibleDC(nullptr);
    BITMAPINFO bmi = {};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h; // top-down: row 0 = top
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    g_hudBmp = CreateDIBSection(g_hudDC, &bmi, DIB_RGB_COLORS, &g_hudBits, nullptr, 0);
    SelectObject(g_hudDC, g_hudBmp);

    // Create GL texture.
    glGenTextures(1, &g_hudTex);
    glBindTexture(GL_TEXTURE_2D, g_hudTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // Compile HUD shader.
    GLuint vs = compileHudShader(GL_VERTEX_SHADER, kHudVS);
    GLuint fs = compileHudShader(GL_FRAGMENT_SHADER, kHudFS);
    g_hudProg = glCreateProgram();
    glAttachShader(g_hudProg, vs);
    glAttachShader(g_hudProg, fs);
    glLinkProgram(g_hudProg);
    glDeleteShader(vs);
    glDeleteShader(fs);

    // VAO for drawing.
    glGenVertexArrays(1, &g_hudVAO);
}

// Find current effect name from segment ops.
static const char* getCurrentEffect(const sm::Show& show, double T) {
    const sm::Segment* seg = show.segment_at(T);
    if (!seg) return "none";
    for (const auto& op : seg->ops) {
        if (op.op == "RENDER" || op.op == "TRANSITION") {
            for (const auto& c : show.clips) {
                if (c.id == op.clip) return c.effect.c_str();
            }
        }
    }
    return "none";
}

static void drawHUD(const char* effectName, double T, double duration) {
    // 1. Clear DIB to zeros (fully transparent).
    memset(g_hudBits, 0, (size_t)g_hudW * g_hudH * 4);

    // 2. Draw with GDI on memory DC.
    HFONT font = CreateFontA(22, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
                             OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                             DEFAULT_PITCH | FF_DONTCARE, "Consolas");
    SelectObject(g_hudDC, font);
    SetTextColor(g_hudDC, RGB(0, 255, 0));  // bright green
    SetBkMode(g_hudDC, TRANSPARENT);

    // Top-left: effect name.
    TextOutA(g_hudDC, 12, 10, effectName, (int)strlen(effectName));

    // 5 rainbow squares below the text.
    const COLORREF rainbow[] = {
        RGB(255, 0, 0),     // red
        RGB(255, 128, 0),   // orange
        RGB(255, 255, 0),   // yellow
        RGB(0, 255, 0),     // green
        RGB(0, 128, 255),   // blue
    };
    for (int i = 0; i < 5; i++) {
        HBRUSH brush = CreateSolidBrush(rainbow[i]);
        RECT rc = {12 + i * 24, 38, 12 + i * 24 + 20, 58};
        FillRect(g_hudDC, &rc, brush);
        DeleteObject(brush);
    }

    // Bottom-center: timer "T.X / D.X sec"
    char timer[64];
    snprintf(timer, sizeof(timer), "%.1f / %.1f sec", T, duration);
    int textLen = (int)strlen(timer);
    SIZE textSize = {};
    GetTextExtentPointA(g_hudDC, timer, textLen, &textSize);
    int tx = (g_hudW - textSize.cx) / 2;  // center horizontally
    int ty = g_hudH - 30;                  // 30px from bottom
    TextOutA(g_hudDC, tx, ty, timer, textLen);

    DeleteObject(font);

    // 3. Convert BGRA → RGBA + set alpha (non-black = opaque).
    unsigned char* px = (unsigned char*)g_hudBits;
    int total = g_hudW * g_hudH;
    for (int i = 0; i < total; i++) {
        unsigned char b = px[i * 4 + 0];
        unsigned char g = px[i * 4 + 1];
        unsigned char r = px[i * 4 + 2];
        px[i * 4 + 0] = r;  // R
        px[i * 4 + 1] = g;  // G
        px[i * 4 + 2] = b;  // B
        px[i * 4 + 3] = (r | g | b) ? 255 : 0;  // alpha: opaque if non-black
    }

    // 4. Upload to GL texture.
    glBindTexture(GL_TEXTURE_2D, g_hudTex);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, g_hudW, g_hudH,
                    GL_RGBA, GL_UNSIGNED_BYTE, g_hudBits);

    // 5. Draw fullscreen quad with alpha blending over the scene.
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, g_hudW, g_hudH);
    glUseProgram(g_hudProg);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_hudTex);
    GLint loc = glGetUniformLocation(g_hudProg, "uTex");
    if (loc >= 0) glUniform1i(loc, 0);
    loc = glGetUniformLocation(g_hudProg, "uRes");
    if (loc >= 0) glUniform2f(loc, (float)g_hudW, (float)g_hudH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBindVertexArray(g_hudVAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glDisable(GL_BLEND);
}

// --- Globals ---
static HWND g_hwnd = nullptr;
static HDC g_hdc = nullptr;
static HGLRC g_hglrc = nullptr;
static bool g_running = true;
static int g_width = 1280, g_height = 720;

static double getTime() {
    static LARGE_INTEGER freq;
    static bool init = false;
    if (!init) { QueryPerformanceFrequency(&freq); init = true; }
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    return (double)now.QuadPart / (double)freq.QuadPart;
}

static void Log(const char* fmt, ...) {
    char buf[1024]; va_list args; va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args); va_end(args);
    OutputDebugStringA(buf); OutputDebugStringA("\n");
    printf("%s\n", buf);
    // Also write to trace.log (project protocol).
    static FILE* s_log = nullptr;
    static bool s_tried = false;
    if (!s_tried) {
        s_tried = true;
        s_log = fopen("trace.log", "a");
        if (s_log) setvbuf(s_log, nullptr, _IONBF, 0);
    }
    if (s_log) { fprintf(s_log, "%s\n", buf); }
}

// Crash handler — catch access violations and log before dying.
static LONG WINAPI CrashHandler(EXCEPTION_POINTERS* ep) {
    if (ep && ep->ExceptionRecord) {
        Log("[FATAL] Exception 0x%08lX at address %p",
            (unsigned long)ep->ExceptionRecord->ExceptionCode,
            ep->ExceptionRecord->ExceptionAddress);
    } else {
        Log("[FATAL] Unknown exception");
    }
    return EXCEPTION_EXECUTE_HANDLER;
}

// Static WndProc — must be __stdcall (CALLBACK) for Win32.
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_KEYDOWN:
            if (wp == VK_ESCAPE) { g_running = false; PostQuitMessage(0); return 0; }
            break;
        case WM_CLOSE:
            g_running = false; PostQuitMessage(0); return 0;
        case WM_SIZE:
            g_width = LOWORD(lp); g_height = HIWORD(lp); return 0;
    }
    return DefWindowProc(hwnd, msg, wp, lp);
}

// --- Win32 + OpenGL context (simplified from main.cpp) ---
static HWND createWindow(int w, int h) {
    WNDCLASSEX wc = {};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = "DemoRuntime";
    RegisterClassEx(&wc);

    RECT rc = {0, 0, w, h};
    AdjustWindowRectEx(&rc, WS_POPUP, FALSE, 0);
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    return CreateWindowEx(0, "DemoRuntime", "Demo Runtime", WS_POPUP,
        (sw - (rc.right-rc.left))/2, (sh - (rc.bottom-rc.top))/2,
        rc.right-rc.left, rc.bottom-rc.top,
        nullptr, nullptr, GetModuleHandle(nullptr), nullptr);
}

static bool createGLContext(HWND hwnd) {
    g_hdc = GetDC(hwnd);
    PIXELFORMATDESCRIPTOR pfd = {};
    pfd.nSize = sizeof(pfd); pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA; pfd.cColorBits = 32; pfd.cDepthBits = 24;
    int pf = ChoosePixelFormat(g_hdc, &pfd);
    SetPixelFormat(g_hdc, pf, &pfd);
    HGLRC tmp = wglCreateContext(g_hdc);
    wglMakeCurrent(g_hdc, tmp);

    typedef HGLRC (WINAPI *PFN_wglCreateContextAttribsARB)(HDC, HGLRC, const int*);
    auto wglCreateContextAttribsARB = (PFN_wglCreateContextAttribsARB)(void*)wglGetProcAddress("wglCreateContextAttribsARB");
    if (wglCreateContextAttribsARB) {
        int attribs[] = {0x2091, 3, 0x2092, 3, 0x9126, 0x0001, 0x2094, 0, 0};
        HGLRC modern = wglCreateContextAttribsARB(g_hdc, nullptr, attribs);
        if (modern) { wglMakeCurrent(nullptr, nullptr); wglDeleteContext(tmp); wglMakeCurrent(g_hdc, modern); g_hglrc = modern; }
        else { g_hglrc = tmp; }
    } else { g_hglrc = tmp; }

    if (!LoadOpenGLFunctions()) { Log("[Error] OpenGL functions not loaded"); return false; }

    typedef BOOL (WINAPI *PFN_wglSwapIntervalEXT)(int);
    auto wglSwapIntervalEXT = (PFN_wglSwapIntervalEXT)(void*)wglGetProcAddress("wglSwapIntervalEXT");
    if (wglSwapIntervalEXT) wglSwapIntervalEXT(1);
    return true;
}

// --- Main ---
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    SetUnhandledExceptionFilter(CrashHandler);
    // Get .smt path from command line (or default).
    std::string smtPath = "demo.smt";
    std::string shaderDir = "shaders";
    // Parse command line for .smt path.
    LPSTR cmd = GetCommandLineA();
    if (cmd) {
        // Simple: find first .smt argument.
        const char* p = strstr(cmd, ".smt");
        if (p) {
            const char* start = p;
            while (start > cmd && start[-1] != ' ') start--;
            smtPath = std::string(start, p - start + 4);
        }
    }

    Log("[Start] Demo Runtime — loading %s", smtPath.c_str());

    // Load SMT.
    sm::Show show;
    try {
        show = sm::load(smtPath);
    } catch (const std::exception& e) {
        Log("[Error] Failed to load %s: %s", smtPath.c_str(), e.what());
        MessageBoxA(nullptr, ("Failed to load " + smtPath + ":\n" + e.what()).c_str(),
                    "Demo Runtime", MB_ICONERROR);
        return 1;
    }
    Log("[OK] SMT loaded: duration=%.1fs, %d clips, %d segments",
        show.duration, (int)show.clips.size(), (int)show.segs.size());

    g_width = show.w; g_height = show.h;

    // Create window + GL context.
    g_hwnd = createWindow(g_width, g_height);
    if (!g_hwnd) { Log("[Error] Window creation failed"); return 1; }
    if (!createGLContext(g_hwnd)) { Log("[Error] GL context failed"); return 2; }
    ShowWindow(g_hwnd, SW_SHOW);

    Log("[GL] %s / %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));

    // Init GL executor.
    glx::ShaderCache shaders;
    shaders.init(shaderDir);
    glx::FBOPool fbos;
    fbos.init(g_width, g_height);

    // Init HUD overlay.
    initHUD(g_width, g_height);
    Log("[OK] HUD initialized (%dx%d)", g_width, g_height);

    // Pre-warm: compile all shaders.
    int compiled = 0;
    for (const auto& c : show.clips) {
        if (c.effect != "finish" && c.effect != "-" && shaders.getProgram(c.effect)) compiled++;
    }
    Log("[OK] %d shader programs compiled", compiled);

    // Main loop.
    double startTime = getTime();
    double pausedTime = 0;
    bool paused = false;

    MSG msg = {};
    while (g_running) {
        while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) { g_running = false; break; }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        if (!g_running) break;

        if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
            if (!paused) { paused = true; pausedTime = getTime() - startTime; }
        } else {
            if (paused) { startTime = getTime() - pausedTime; paused = false; }
        }

        double T = getTime() - startTime;
        if (T >= show.duration) {
            Log("[Done] Show finished at T=%.2fs", T);
            break;
        }

        // Render frame.
        try {
            glx::renderFrame(show, T, shaders, fbos);
        } catch (const std::exception& e) {
            Log("[FATAL] renderFrame exception at T=%.2f: %s", T, e.what());
            break;
        }

        // Check for GL errors after frame.
        GLenum glErr = glGetError();
        if (glErr != GL_NO_ERROR) {
            Log("[GL ERROR] After frame T=%.2f: 0x%x", T, glErr);
        }

        // Draw HUD overlay on top of the scene.
        const char* effectName = getCurrentEffect(show, T);
        drawHUD(effectName, T, show.duration);

        // Debug: log once per second.
        static double lastLog = 0;
        if (T - lastLog >= 1.0) {
            lastLog = T;
            const sm::Segment* seg = show.segment_at(T);
            if (seg) {
                Log("[Frame] T=%.1fs seg=[%.1f,%.1f) ops=%d fbos=%d",
                    T, seg->start, seg->end, (int)seg->ops.size(), seg->fbos);
            }
        }

        // Present (swap buffers).
        SwapBuffers(g_hdc);
    }

    // Cleanup.
    if (g_hglrc) { wglMakeCurrent(nullptr, nullptr); wglDeleteContext(g_hglrc); }
    if (g_hdc && g_hwnd) ReleaseDC(g_hwnd, g_hdc);
    if (g_hwnd) DestroyWindow(g_hwnd);

    Log("[Exit] Demo Runtime ended");
    return 0;
}
