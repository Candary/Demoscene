"""Run the supplied Cozy/Color demo through the v0.4 Hybrid facade."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from examples.build_cozy_scene import PLAN
from integration.runtime import runtime_fingerprint
from uroboros import Uroboros
from uroboros.hybrid import HybridCore

engine = Uroboros(root=ROOT/'.uroboros_memory', patches=ROOT/'patches', workers=2,
                  runtime_fingerprint=runtime_fingerprint())
hybrid = HybridCore(engine, btb_root=ROOT/'.uroboros_memory'/'btb', btb_mode='shadow')
result = hybrid.run(PLAN, max_iterations=1, require_approval=False)
print('status:', result['status'])
print('metrics:', result['metrics'])
print('BTB:', result['hybrid']['btb_stats'])
print('run:', result['run'])
