// ============================================================================
// cozy_room_sdf.frag — SDF-комната из примитивов Cozy Engine
// ----------------------------------------------------------------------------
// Версия: v61-adapted (pipeline-ready)
// Контракт: uPrimitives (farray: shape,axis,sx,sy,sz,px,py,pz,rot_y,r,g,b × N),
//           uPrimitivesCount (int, float count), uLightColor (vec3),
//           uCamAngle (float).
//
// Pipeline integration:
//   uPrimaryColor vec3  — Color Matrix: базовый цвет комнаты
//   uAccentColor  vec3  — Color Matrix: акцентный цвет (лампа/свет)
//   uIntensity    float — Cyclic pipeline: общая яркость (0..2)
//   uMotionSpeed  float — motus: скорость камеры / вращения
//   uPulse        float — motus: пульсация освещения
//
// kind: scene, cost: 4
// Совместимость: OpenGL 3.3 core, GLSL 330
// ============================================================================

#version 330 core

// --- Стандартные uniforms (от Scene Manager runtime) -----------------------
uniform float uTime;
uniform float uClipTime;
uniform float uProgress;
uniform float uGlobalTime;
uniform vec2  uResolution;
uniform int   uSeed;
uniform float uBeat;
uniform float uBeatPhase;
uniform float uBarPhase;
uniform float uEnergy;

// --- Effect uniforms (из .smt / scene_bake.py) ------------------------------
uniform float uPrimitives[384];   // 32 prims × 12 floats (runtime отправляет actual count)
uniform int   uPrimitivesCount;   // float count (v55 fix: 120 для 10 prims × 12)
uniform vec3  uLightColor;        // цвет лампы (теплый свет)
uniform float uCamAngle;          // угол камеры (орбита)

// --- Pipeline uniforms (Color Matrix + motus + cyclic) ----------------------
// Note: no default initializers — GLSL ES 3.0 (WebGL2) doesn't allow them.
// Desktop GLSL 330 does, but we keep it compatible with both.
uniform vec3  uPrimaryColor;   // Color Matrix: базовый цвет
uniform vec3  uAccentColor;    // Color Matrix: акцент (лампа)
uniform float uIntensity;      // Cyclic: яркость
uniform float uMotionSpeed;    // motus: скорость
uniform float uPulse;          // motus: пульсация

// --- Выход ------------------------------------------------------------------
out vec4 FragColor;

// ============================================================================
// Константы
// ============================================================================
const float PI  = 3.14159265359;
const float TAU = 6.28318530718;
const int   MAX_PRIMS = 32;
const int   STRIDE = 12;

// ============================================================================
// SDF primitives
// ============================================================================
float sdSphere(vec3 p, float r) {
    return length(p) - r;
}

float sdBox(vec3 p, vec3 b) {
    vec3 q = abs(p) - b;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float sdCylinder(vec3 p, float r, float h) {
    vec2 d = vec2(length(p.xz) - r, abs(p.y) - h);
    return min(max(d.x, d.y), 0.0) + length(max(d, 0.0));
}

// ============================================================================
// Scene mapping — SDF union of all Cozy Engine primitives
// ----------------------------------------------------------------------------
// gHitColor: global, устанавливается в mapScene для передачи цвета ближайшей
// поверхности. В GLSL 330 это допустимо — один поток на пиксель.
// ============================================================================
vec3 gHitColor;

float mapScene(vec3 p) {
    float minDist = 1e9;
    gHitColor = max(uPrimaryColor, vec3(0.001)) * 0.5;  // default: не чёрный

    for (int i = 0; i < MAX_PRIMS; i++) {
        int b = i * STRIDE;
        if (b >= uPrimitivesCount) break;

        float shape = uPrimitives[b + 0];
        // b+1 = axis (не используется в базовом SDF, зарезервировано)
        vec3 size = vec3(uPrimitives[b + 2], uPrimitives[b + 3], uPrimitives[b + 4]);
        vec3 pos  = vec3(uPrimitives[b + 5], uPrimitives[b + 6], uPrimitives[b + 7]);
        float rotY = uPrimitives[b + 8];
        vec3 color = vec3(uPrimitives[b + 9], uPrimitives[b + 10], uPrimitives[b + 11]);

        // Transform to primitive local space
        vec3 lp = p - pos;
        float c = cos(-rotY), s = sin(-rotY);
        lp.xz = mat2(c, -s, s, c) * lp.xz;

        // SDF by shape type: 0=box, 1=sphere, 2=cylinder
        float d;
        if (shape < 0.5) {
            d = sdBox(lp, size * 0.5);
        } else if (shape < 1.5) {
            d = sdSphere(lp, size.x);
        } else {
            d = sdCylinder(lp, size.x, size.y * 0.5);
        }

        if (d < minDist) {
            minDist = d;
            // Pipeline: модулируем цвет примитива базовым цветом Color Matrix
            gHitColor = color * mix(1.0, 0.7, length(uPrimaryColor) * 0.3);
        }
    }
    return minDist;
}

// ============================================================================
// Normal calculation — tetrahedron technique (4 taps instead of 6)
// ============================================================================
vec3 calcNormal(vec3 p) {
    const vec2 k = vec2(1.0, -1.0);
    const float e = 0.001;
    return normalize(
        k.xyy * mapScene(p + k.xyy * e) +
        k.yyx * mapScene(p + k.yyx * e) +
        k.yxy * mapScene(p + k.yxy * e) +
        k.xxx * mapScene(p + k.xxx * e));
}

// ============================================================================
// Ray marching — bounding sphere + adaptive step
// ============================================================================
vec2 rayMarch(vec3 ro, vec3 rd) {
    // Bounding sphere R=8 — room fits inside
    vec3 oc = ro;
    float b = dot(oc, rd);
    float c = dot(oc, oc) - 64.0;
    float disc = b * b - c;
    if (disc < 0.0) return vec2(-1.0, 0.0);

    float t = max(0.0, -b - sqrt(disc));
    const int STEPS = 48;

    for (int i = 0; i < STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = mapScene(p);
        if (d < 0.001) return vec2(t, 1.0);
        if (t > 30.0) break;
        t += d;
    }
    return vec2(-1.0, 0.0);
}

// ============================================================================
// Background — тёмный градиент с tint от Color Matrix
// ============================================================================
vec3 backgroundColor(vec3 rd) {
    float t = 0.5 + 0.5 * rd.y;
    vec3 dark = vec3(0.02, 0.02, 0.03);
    vec3 light = vec3(0.05, 0.06, 0.08);
    // Pipeline: tint фона — guard against uPrimaryColor=0 (unset in .smt)
    vec3 tint = max(uPrimaryColor, vec3(0.001)) * 0.02 * (1.0 - t);
    return mix(dark, light, t) + tint;
}

// ============================================================================
// Soft shadow — простая penumb shadow для глубины
// ============================================================================
float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    for (int i = 0; i < 24; i++) {
        float h = mapScene(ro + rd * t);
        res = min(res, k * h / t);
        t += clamp(h, 0.02, 0.5);
        if (res < 0.01 || t > maxt) break;
    }
    return clamp(res, 0.0, 1.0);
}

// ============================================================================
// ACES tonemap
// ============================================================================
vec3 aces(vec3 c) {
    return (c * (2.51 * c + 0.03)) / (c * (2.43 * c + 0.59) + 0.14);
}

// ============================================================================
// Main
// ============================================================================
void main() {
    vec2 fragUv = gl_FragCoord.xy / uResolution;
    vec2 uv = (fragUv * 2.0 - 1.0) * vec2(uResolution.x / uResolution.y, 1.0);

    // --- Pipeline defaults: guard against unset uniforms (0 in GLSL) ---
    // .smt v61 only sets uLightColor + uCamAngle. Pipeline uniforms
    // (uPrimaryColor, uAccentColor, uIntensity, uMotionSpeed, uPulse) are
    // NOT in .smt → default to 0 → must guard with max().
    vec3  primaryColor = max(uPrimaryColor, vec3(0.001));  // avoid black tint
    float intensity    = max(uIntensity, 1.0);              // avoid ×0 = black
    float motionSpeed  = max(uMotionSpeed, 0.0);            // 0 = static camera
    float pulse        = max(uPulse, 0.0);                  // 0 = no pulse

    // --- Camera: orbits via uCamAngle + motus uMotionSpeed ---
    float a = uCamAngle + uTime * motionSpeed * 0.03;
    float dist = 6.0;
    vec3 ro = vec3(sin(a) * dist, 2.5, cos(a) * dist);
    vec3 ta = vec3(0.0, 1.0, 0.0);
    vec3 fwd = normalize(ta - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
    vec3 up = cross(fwd, right);
    vec3 rd = normalize(fwd + uv.x * right + uv.y * up);

    // --- Background ---
    vec3 bg = backgroundColor(rd);

    // --- Ray march ---
    vec2 hit = rayMarch(ro, rd);
    vec3 col;

    if (hit.x < 0.0) {
        col = bg;
    } else {
        vec3 p = ro + rd * hit.x;
        vec3 n = calcNormal(p);

        // --- Lighting ---
        vec3 ld = normalize(vec3(0.3, 0.8, 0.5));

        // Pipeline: пульсация освещения от motus uPulse
        float pulseMod = 1.0 + pulse * 0.3 * sin(uTime * 2.0);
        vec3 lightCol = uLightColor * pulseMod;

        float diff = max(dot(n, ld), 0.0);
        float amb = 0.2 + 0.15 * max(dot(n, vec3(0.0, 1.0, 0.0)), 0.0);

        // Specular
        vec3 viewDir = -rd;
        vec3 halfDir = normalize(ld + viewDir);
        float spec = pow(max(dot(n, halfDir), 0.0), 32.0);

        // Soft shadow
        float shadow = softShadow(p + n * 0.02, ld, 0.02, 10.0, 8.0);

        // Surface color: gHitColor (from primitives) × lighting
        vec3 surface = gHitColor * (amb + diff * 0.7 * shadow);
        surface += lightCol * spec * 0.4 * shadow;
        surface += lightCol * 0.1 * diff;

        // Pipeline: общая яркость (guarded — не 0 если uniform не установлен)
        surface *= intensity;

        // Fog: затухание с расстоянием
        float fog = 1.0 - exp(-hit.x * 0.06);
        col = mix(surface, bg, fog * 0.4);
    }

    // --- Vignette ---
    vec2 vd = fragUv - 0.5;
    col *= 1.0 - 0.25 * dot(vd, vd) * 2.0;

    // --- Tonemapping + gamma ---
    col = aces(col);
    col = pow(clamp(col, 0.0, 1.0), vec3(1.0 / 2.2));

    FragColor = vec4(col, 1.0);
}
