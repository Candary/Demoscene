"""Optional GLM-5.2 feedback adapter for an OpenAI-compatible client.

The client is created by the caller: endpoint, API key and model access are not
hard-coded into Uroboros. GLM returns parameter edits only, never Python code.
"""
from __future__ import annotations
import json

SYSTEM = """Ты GLM-5.2, предлагаешь безопасные итерационные правки сцены.
Верни только JSON-объект вида:
{"changes":{"geometry":{"params":{"placements":{"sofa":{"x":-0.5,"z":0.2}}}}},"reason":"..."}
Разрешены только изменения параметров существующих узлов:
- atmosphere: count, avoid, must_have, room
- geometry: room_width, room_depth, margin, gap, placements
- palette: base, scheme, size, background, min_delta_e
- scene: lighting
Не добавляй узлы, операции, исполняемый код, пути или команды. Не утверждай, что сцена одобрена.
Учитывай validation.problems, mental checklist и provenance. Не выдавай GPT-caption корреляции за человеческие оценки уюта.
"""


def make_glm_feedback(client, model: str):
    """Return callback compatible with Uroboros.run(feedback=...)."""
    def propose(result: dict, iteration: int):
        outputs = result.get("outputs", {})
        atmosphere = outputs.get("atmosphere", {}).get("atmosphere", {})
        geometry = outputs.get("geometry", {}).get("geometry", {})
        palette = outputs.get("palette", {})
        validation = outputs.get("validation", {}).get("validation", {})
        compact = {
            "iteration": iteration,
            "room": atmosphere.get("room"),
            "objects": [x.get("object") for x in atmosphere.get("objects", [])],
            "footprints": geometry.get("footprints", []),
            "room_dimensions": geometry.get("room", {}),
            "palette_roles": {k: v.get("hex") for k, v in palette.get("palette", {}).get("roles", {}).items()
                              if isinstance(v, dict)},
            "validation": validation,
            "checklist": result.get("checklist", {}),
            "instruction": "Предложи минимальные изменения параметров для следующей итерации. Если изменений не требуется, верни changes={}.",
        }
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": SYSTEM},
                      {"role": "user", "content": json.dumps(compact, ensure_ascii=False)}],
            response_format={"type": "json_object"},
            temperature=0.2,
        )
        content = response.choices[0].message.content
        data = json.loads(content or "{}")
        changes = data.get("changes", {})
        if not isinstance(changes, dict):
            raise ValueError("GLM feedback.changes must be an object")
        if not changes:
            return None
        allowed = {
            "atmosphere": {"room", "count", "avoid", "must_have"},
            "geometry": {"room_width", "room_depth", "margin", "gap", "placements"},
            "palette": {"base", "scheme", "size", "background", "min_delta_e"},
            "scene": {"lighting"},
        }
        for node_id, change in changes.items():
            if node_id not in allowed or not isinstance(change, dict):
                raise ValueError(f"GLM proposed unsupported node: {node_id}")
            values = change.get("params", change)
            if not isinstance(values, dict) or set(values) - allowed[node_id]:
                raise ValueError(f"GLM proposed unsupported parameters for {node_id}")
        return {
            "format": "uroboros.patch/2", "id": "glm-feedback",
            "parent": None, "run": None, "iteration": iteration + 1,
            "target": "uroboros", "operation": "feedback.apply",
            "inputs": {}, "params": {"changes": changes, "reason": str(data.get("reason", ""))},
            "outputs": {}, "status": "proposed", "approval": "pending",
            "metrics": {}, "memory": {},
        }
    return propose
