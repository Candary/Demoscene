"""Hybrid Core facade: Sigil + BTB + Exchange + existing cyclic patch engine."""
from __future__ import annotations
from pathlib import Path
from .btb import BTB
from .sigil import parse
from .exchange import Router, envelope

class HybridCore:
    def __init__(self, engine, *, btb_root=None, btb_mode='shadow', min_confidence=.75):
        self.engine=engine
        root=Path(btb_root) if btb_root else engine.memory.root/'btb'
        self.btb=BTB(root,mode=btb_mode,min_confidence=min_confidence)
        self.router=Router()
    def run(self, plan: dict, *, sigil: str | dict | None = None, **kwargs):
        intent=parse(sigil) if isinstance(sigil,str) else (sigil or {'intent':plan.get('name','pipeline')})
        signature='|'.join([str(intent.get('intent')), *map(str,intent.get('use',[])), str(intent.get('target',''))])
        resources={f"operation:{n['operation']}":n['operation'] for n in plan.get('nodes',[])}
        prediction=self.btb.predict(signature,resources)
        result=self.engine.run(plan,**kwargs)
        used=list(resources)
        self.btb.observe(signature,prediction.get('resources',[]),used)
        result['hybrid']={'signature':signature,'btb_prediction':prediction,'btb_stats':self.btb.stats(),
                          'protocol':'uroboros.hybrid/0.4'}
        stats=self.btb.stats()
        result['metrics'].update(stats)
        result['metrics']['btb_predictions']=stats['predictions']
        result['metrics']['btb_hits']=stats['hits']
        self.engine.memory.event({'type':'hybrid_summary','run':result['run'],'hybrid':result['hybrid'],'metrics':result['metrics']})
        return result
    def dispatch(self, target: str, payload: dict, *, source='glm', operation=None):
        msg=envelope(source,target,'REQUEST',payload,operation=operation)
        return self.router.dispatch(msg)
