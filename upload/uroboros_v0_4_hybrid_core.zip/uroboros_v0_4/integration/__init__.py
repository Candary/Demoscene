"""Adapters connecting Uroboros to the supplied engines."""
