# Мнение по проекту «Unlimited demo»

## Общая оценка

Сильная инженерная работа — но не в том месте, где вы думаете. У вас редкое качество: вы **умеете** делать правильно (root-cause, benchmark, validator, честные откаты). Проблема не в качестве, а в **фокусе**: 90% усилий ушло в инфраструктуру вокруг генерации, а не в саму генерацию. «Unlimited demo» как продукт пока не существует: есть куча модулей и 0 строк Scene Manager.

---

## Что хвалю (это правда хорошо)

- **v41–v43: доказанные корневые причины.** Вариадик-указатель → float promotion (`cvtss2sd`) → чёрный экран; cdecl/stdcall → краш. Разбор через дизассемблер — уровень senior, не каждый доходит.
- **5-layer validation pipeline.** L1 style → L2 dynamic → L3 blocking (glslangValidator) → L4 runtime (after-predicate) → L5 self-test — правильная архитектура для LLM-генерации шейдеров.
- **Честные замеры и откаты.** `np.einsum` дал 27× регресс — вы откатили. `np.unique` — 72× регресс — откатили. Это редкость: большинство «векторизуют» и не меряют.
- **Numeric SDF validators.** `check_sdCone_fix.py`, `check_tri_prism.py`, `emulate_raymarch.py` — золото. Старая формула конуса врала — вы это поймали численно, до шейдера.
- **Единый trace.log** = build + runtime. Правильно.
- **Работает на GTX 750 (2014)** — хорошая планка для оптимизации.

---

## Главная структурная проблема

**Дисбаланс «протокол ↔ демо».**

В roadmap **69 Tasks**. Из них про генерацию демо, SDF, шейдеры, музыку — примерно **10** (19, 54, 56, 60, 65 + общие 42/43). Остальные ~60 — это sigil+BTB, meta.auto, btb_stats, booster, pandoc, docx, killswitch, иронично приостановленный под лозунгом «не плодить инфраструктуру». Инфраструктуры уже 60 тасков.

Вы сами написали: *«проект не будет использовать бизнес-логику и другую логику, которая может повлиять на скорость»*. **Но sigil+BTB — это именно такая логика.** Она не генерирует демо, она обслуживает общение с ассистентом.

**Совет №1:** заморозьте протокол на текущей версии. Все новые Tasks — только про `demo_intro`. Через месяц решите, что из протокола реально пригодилось (скорее всего — `trace.log` и after-predicate, и почти ничего больше).

**Совет №2:** реализуйте **Scene Manager Variant A**. Это центральный кусок «Unlimited demo» — 682 строки дизайна, 0 кода. Variant A простой: timeline + crossfade через FBO, ~175 минут.

---

## По критериям

### 1. Лёгкость реализации

**❌ Patch-script culture.** 20+ файлов `patch_*.py`. `patch_nebula_bg.py` v1→v5 — 5 итераций патчинга одной функции, по 7–8 КБ Python каждая. `patch_shaders_optimize.py`, `patch_main_cpp_procfire.py`, `patch_optimize_v1.py`, `patch_procfire_v2.py`, `patch_letters_physics.py`.

Причина: **шейдер продублирован** в `shaders.h` (C++) и `preview.html` (JS). Любое изменение = два патча + sync-скрипт.

> **Совет №3 (0.5 дня):** один источник — `shaders/main.frag` + `shaders/main.vert`.
> - Для C++: build-script `embed_shaders.py` генерирует `shaders.h` из `.glsl` (или CMake `configure_file`).
> - Для preview.html: `<script type="x-shader" src="shaders/main.frag">` или build-скрипт инлайнит.
> - 20 patch-script'ов удаляются. Следующая правка небулы = Edit 20 строк в `.glsl`, а не 8 КБ patch-скрипта.

**❌ `--fail-if-warnings` в `pandoc_docx/build.py`.** Любой warning pandoc = abort. Для быстрой итерации это яд.

> **Совет №4 (5 минут):** уберите `--fail-if-warnings` из dev-build. Оставьте `--verbose` для отладки и отдельный флаг для release/CI.

**❌ Нет единого API.** Чтобы получить `.exe`: сгенерировать палитру Color Matrix → собрать палитру Cozy Engine → вручную вписать в шейдер → собрать `shaders.h` → MSVC → проверить trace.log. 6 шагов, 4 из них — ручные.

> **Совет №5 (2–3 дня):** один `generate.py config.json -o demo.exe`. Конфиг — данные:
> ```json
> {
>   "duration_sec": 180,
>   "scenes": [
>     {"feel": "anxiety", "duration": 30, "effects": ["droplets", "nebula"]},
>     {"feel": "warmth",  "duration": 75, "effects": ["fire", "letters"]},
>     {"feel": "delight", "duration": 75, "effects": ["particles"]}
>   ],
>   "music": "c99/synth_03.c"
> }
> ```
> Это и есть «скорость генерации»: 1 команда вместо 6, и повторяемо.

**✅ Что хорошо:** Color Matrix и Cozy Engine — чистые модули с тестами. `main.cpp` — один файл. `check_gl_coverage.py` — отличная идея (проверяет, что все GL-функции объявлены).

### 2. Оптимизация

**✅ Benchmark-driven** — плохие патчи откатываете. Правильно.

**❌ Color Matrix грузится полностью в RAM.** `np.load` читает 16.7M × (empathy float32 + entropy float32 + labels int8×2 + syn int8×3) ≈ **60–80 MB**. Для CLI-инструмента, вызываемого 30 раз за итерацию, это дорого.

> **Совет №6 (0.5 дня):** `np.load(path, mmap_mode='r')` + int8-quantization (`empathy → int8`, `entropy → uint8`, `L/C/h → uint16`). Размер падает до ~20 MB, точность для поиска (`empathy ±2`) сохраняется. А `SearchIndex` и так работает на stride=4 (274K) — полный массив ему не нужен.

**❌ Particle loop в `MapScene`.** 8 итераций × 60 шагов × 4 `CalcNormal` = ~1900 `sdSphere` на пиксель. Bounding-skip откатили — правильно (был overshoot). Но можно лучше: precompute `gParticleRadSq[i] = r*r` и **сортировать частицы по расстоянию от начала луча** один раз за кадр.

> **Совет №7 (0.5 дня):** в `RenderScene` сортировать `gParticlePos` по расстоянию до камеры; в `MapScene` идти от ближней к дальней и делать `if (d_part < 0.01) break;`. Для центральных пикселей — early exit, для периферийных — честный проход.

**✅ GLSL validator** — ошибки ловятся до доставки. Правильная блокирующая проверка.

**✅ Numeric SDF validators** — `check_sdCone_fix.py` (10 test cases) показал, что старая формула врала снаружи конуса. Это спасает от невидимых багов.

### 3. Гибкость

**❌ Сцены хардкодятся в шейдере.** Чтобы добавить сцену — править 800 строк fragment shader.

> **Совет №8 (1 день):** scene format в JSON (см. №5). Параметры: duration, palette roles, effect on/off, transition type. Генератор подставляет в шаблон. Даёт гибкость (новый scene = новый JSON-блок), скорость (кэш скомпилированных шейдеров по `(scene_type, effect_set)`), тестируемость (JSON → predict expected color checks).

**❌ 5 вариантов Scene Manager спроектированы, 0 строк кода.** Analysis excellent — но это не гибкость, это паралич выбора.

> **Совет №9:** выберите **Variant A (Timeline)** сейчас. Он совместим с C/D/E позже (migration path у вас описан). Variant B (Uber Shader) — задел на 4K/64K, если туда пойдёте. Сейчас Unlimited → Variant A.

**❌ Cozy Engine нерелевантен Unlimited demo.** 64 атома — это «sofa, cushion, rug, warm_light». Для SDF-интро вы уже используете 9 фигур (сфера, куб, тор…). `primitives.py` даёт диван из 6 box — но box в SDF-рендере **медленнее**, чем `sdBox` напрямую.

> **Совет №10:** либо явно выделите Cozy Engine в отдельный проект (он хорош для генерации интерьеров), либо используйте его минимально — `primitives.py` как «shape library» для SDF-сцен. Но честно: к Unlimited demo он отношения не имеет. Это scope creep.

**✅ Color Matrix / Cozy Engine разделены.** Хорошая модульность.

### 4. Скорость генерации

**✅ Pandoc 0.5s, GLSL validate 0.5s** — отлично.

**❌ Нет кэша.** Каждый запуск — полная пересборка: pandoc заново, MSVC заново, GLSL validate заново. Для 5–10 итераций в день это 30–60 секунд впустую.

> **Совет №11 (0.5 дня):** `build.py` с хэшем входа:
> - `shaders/*.glsl` → MD5 → если не менялся, не компилировать MSVC
> - `content/*.md` → MD5 → если не менялся, не пересобирать `.docx`
> - `.exe` → если не менялся, не запускать MSVC

**❌ Нет parallel сцен.** Если в конфиге 5 сцен — рендерятся последовательно. Для генерации видео-превью — минуты.

> **Совет №12:** для preview — параллельно через `multiprocessing`. Для финального `.exe` — GPU всё равно рендерит быстрее, чем CPU-оркестратор.

---

## Сводка по research points

| Research | Что делать |
|---|---|
| **demo_intro** (C++/OpenGL) | ✅ оставить. Сплит `main.cpp` на modules: `window`, `gl_context`, `fire`, `letters`, `render` |
| **preview.html** | ❌ дубликат `shaders.h`. Заменить на один источник + embed |
| **Color Matrix** | ❌ 60–80 MB RAM. `mmap_mode='r'` + int8 → 20 MB |
| **Cozy Engine** | ❓ нерелевантен Unlimited demo. Выделить или удалить |
| **Scene Manager** | 🔴 0 кода. Реализовать Variant A за 1–2 дня |
| **Code Booster** | ⚠️ L1 static (2500 tok) — оставить. L2 dynamic (15 queries/task) — убрать, overhead > польза. L3 validator — оставить |
| **GLSL validator** | ✅ оставить + add caching по MD5 |
| **after-predicate DSL** | ✅ оставить. Отличная идея для runtime verification |
| **Pandoc docx** | ✅ оставить. Убрать `--fail-if-warnings` из dev |
| **Protocol (sigil+BTB)** | 🔴 заморозить. 60/69 Tasks — не про demo |
| **Pipeline_intro.md** | ✅ оставить как roadmap. Закрыть G1–G6 (compo category, music, Scene Manager, shaders, packaging, duration) |
| **Aesthetics.md** | ⚠️ `aesthetic_notes` блок — хорошая идея, но не блокируйте delivery |
| **perf_analysis.md** | ✅ переиспользовать как template. Замер → откат при регрессе |
| **Patch scripts** | 🔴 удалить. Заменить на single source + build embed |

---

## Приоритетный план (2 недели)

**Неделя 1 — центральный кусок:**
1. `shaders/main.frag` как single source + `embed_shaders.py` (0.5 дня)
2. Удалить 20 patch-scripts (0.5 дня)
3. Scene Manager Variant A: C++ класс, timeline, CROSSFADE через FBO (2 дня)
4. Музыка: 4Klang или C99 synth, один трек 3 минуты (2–3 дня) — **блокирующее**

**Неделя 2 — оркестрация:**
5. `generate.py config.json → demo.exe` (2 дня)
6. mmap Color Matrix + int8 quantization (0.5 дня)
7. Build cache по MD5 (0.5 дня)
8. End-to-end test: config → `.exe` → smoke run → exit code 0 (1 день)
9. Заморозить протокол (0 дней, просто решение)

**После:** первая версия Unlimited demo. ~10 Tasks вместо 69. Дальше — по потребности.

---

## Финальная мысль

У вас **работающий** `demo_intro v49` на `GTX 750` и **правильная** инженерная культура. Не хватает одного: **фокуса на генерации, а не на инфраструктуре вокруг неё**. Уберите/заморозьте всё, что не генерирует демо, — и за две недели дойдёте до состояния «работающий Unlimited demo», а не «работающий протокол + работающий demo_intro по отдельности».

Самая дорогая ошибка в проекте — не баг ABI и не C2026. Самая дорогая — **Task 53 (!macro ОТКЛОНЁН)**, **Task 64 (kill-switch ОТКЛОНЁН)** и одновременно **60 тасков протокола**. Вы правильно отказались от `!macro` и `kill-switch` по принципу «не плодить инфраструктуру» — но не применили этот же принцип к самому протоколу. Примените.