// ============================================================================
// nebula_raymarch.frag
// ----------------------------------------------------------------------------
// Эффект: рэймарчинг туманности — volumetric 3D noise accumulation.
// (Основной эффект интро v49, в новой архитектуре Scene Manager.)
//
// Контракт (см. nebula_raymarch.effect.json):
//   uPrimaryColor vec3  — palette.primary (deep indigo base)
//   uAccentColor  vec3  — palette.accent (vibrant cyan/magenta highlights)
//   uIntensity    float — 0..2 (default bind: 0.4 + energy) — общая яркость
//   uMotionSpeed  float — 0..3 (default bind: 0.6 + energy*0.8) — скорость дрейфа
//   uPulse        float — 0..1 (default bind: pow(1-beat_phase, 4) * 0.4) — beat pulse
//
// Стандартные uniforms:
//   uTime, uClipTime, uProgress, uGlobalTime, uResolution, uSeed,
//   uBeat, uBeatPhase, uBarPhase, uEnergy
//
// Архитектура:
//   Volumetric raymarching через 3D noise field.
//   Для каждого пикселя: cast ray, march 40 шагов, на каждом шаге sample 3D FBM,
//   accumulate density × color. Не SDF — нет поверхности, только accumulation.
//
// Производительность: cost=4 (самый тяжёлый). 40 шагов × FBM (4 octaves) = heavy.
//   На GTX 480 @ 1080p — ожидаемо 30-50 FPS (vs 60+ для lighter shaders).
//
// Совместимость: OpenGL 3.3 core, GLSL 330. Total-semantic.
// ============================================================================

#version 330 core

// --- Стандартные uniforms ---------------------------------------------------
uniform float uTime;
uniform float uClipTime;
uniform float uProgress;
uniform float uGlobalTime;
uniform vec2  uResolution;
uniform int   uSeed;
uniform float uBeat;
uniform float uBeatPhase;
uniform float uBarPhase;
uniform float uEnergy;

// --- Effect uniforms (из manifest nebula_raymarch.effect.json) --------------
uniform vec3  uPrimaryColor;   // palette.primary — deep indigo
uniform vec3  uAccentColor;    // palette.accent — vibrant highlight
uniform float uIntensity;      // 0..2
uniform float uMotionSpeed;    // 0..3
uniform float uPulse;          // 0..1 — beat pulse

// --- Выход ------------------------------------------------------------------
out vec4 FragColor;

// --- v61: color-matrix-safe helpers -------------------------------------------
// Контракт: uPrimaryColor / uAccentColor — это ЦВЕТ НАСТРОЕНИЯ (hue), а не яркость.
// Шейдеры с volumetric accumulation умножают цвет на density и alpha (0.05..0.3),
// поэтому яркий mood-цвет всё равно тонет в фоне. Нормализуем хрому к эталонной
// яркости => любой цвет из Color Matrix даёт одинаковую видимую плотность.
const float REF_LUMA      = 0.35;   // целевая яркость «светящегося» цвета
const float COVERAGE_GAIN = 4.0;    // refmap alpha: 0.08 -> ~0.38 видимой плотности
const float EXPOSURE      = 0.75;    // общая яркость облака

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

// Приводит цвет к единичной яркости и масштабирует до REF_LUMA (hue сохраняется).
vec3 colorize(vec3 c) {
    c = clamp(c, 0.0, 1.0);
    return c * (REF_LUMA / max(luma(c), 1e-3));
}

// ============================================================================
// Константы
// ============================================================================

const float PI  = 3.14159265359;
const float TAU = 6.28318530718;

// Volumetric raymarch parameters.
uniform int uVolumeSteps;             // adaptive: 40 default, 24 low quality (set by runtime)
const int   MAX_VOLUME_STEPS = 40;    // GLSL 330: max bound for loop
const float VOLUME_NEAR  = 1.0;       // начать raymarch с t=1
const float VOLUME_FAR   = 20.0;      // заканчиваем на t=20
const float DENSITY_SCALE = 0.6;      // масштаб плотности (visual)

// ============================================================================
// Hash и noise
// ============================================================================

// v61: целочисленный hash. Старая версия складывала seed с координатой ДО
// умножения на 17: при seed >= 2e4 произведение ~1e8, float32 теряет дробную часть,
// fract(...) == 0 — шум умирал (nebula квантовалась шагом 1/16, anxiety была плоской).
float hash3(vec3 p) {
    // v61.1: целочисленный hash — без квантования (fract-версия давала ~64 уровня
    // и на пороге smoothstep превращалась в прямоугольные ступеньки).
    ivec3 i = ivec3(floor(p));
    uint h = uint(i.x) * 0x8da6b343u ^ uint(i.y) * 0xd8163841u
           ^ uint(i.z) * 0xcb1ab31fu ^ uint(uSeed);
    h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
    return float(h & 0xFFFFFFu) / 16777216.0;
}


// Value noise 3D — trilinear.
// v61.2 fix: renamed noise3 -> vnoise3 to avoid clash with GLSL reserved built-in
// (GLSL 330 spec lists `noise3` as legacy built-in; strict compilers reject
// user-defined overloads with "overloaded functions must have the same return type").
float vnoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float na = hash3(i + vec3(0.0, 0.0, 0.0));
    float nb = hash3(i + vec3(1.0, 0.0, 0.0));
    float nc = hash3(i + vec3(0.0, 1.0, 0.0));
    float nd = hash3(i + vec3(1.0, 1.0, 0.0));
    float ne = hash3(i + vec3(0.0, 0.0, 1.0));
    float nf = hash3(i + vec3(1.0, 0.0, 1.0));
    float ng = hash3(i + vec3(0.0, 1.0, 1.0));
    float nh = hash3(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(na, nb, f.x), mix(nc, nd, f.x), f.y),
               mix(mix(ne, nf, f.x), mix(ng, nh, f.x), f.y), f.z);
}

// 2-октавный FBM — для domain warp (дешевле полного 4-октавного).
float fbm2(vec3 p) {
    float v = 0.0;
    float a = 0.5;
    v += a * vnoise3(p);          p = p * 2.0 + vec3(1.7, 2.3, 3.1); a *= 0.5;
    v += a * vnoise3(p);
    return v;
}

// 4-octave FBM.
float fbm(vec3 p) {
    float v = 0.0;
    float a = 0.5;
    v += a * vnoise3(p);          p = p * 2.0 + vec3(1.7, 2.3, 3.1); a *= 0.5;
    v += a * vnoise3(p);          p = p * 2.0 + vec3(1.7, 2.3, 3.1); a *= 0.5;
    v += a * vnoise3(p);          p = p * 2.0 + vec3(1.7, 2.3, 3.1); a *= 0.5;
    v += a * vnoise3(p);
    return v;
}

// ============================================================================
// Volumetric density field
// ----------------------------------------------------------------------------
// Возвращает density (0..1) в точке p. Использует domain-warped FBM.
// ============================================================================

float densityField(vec3 p) {
    // Анимация: медленный дрейф со временем + uMotionSpeed.
    vec3 anim = vec3(0.0, 0.0, uTime * uMotionSpeed * 0.1);

    // Domain warp: FBM от FBM — даёт "облака" структуры.
    vec3 q = p + anim;
    float warp = fbm(q + vec3(5.2, 1.3, 0.0));
    float mist = fbm(q + vec3(2.0 * warp, 2.0 * warp, 0.0));

    // Threshold: только плотные области дают visible mist.
    // smoothstep даёт мягкий край.
    return smoothstep(0.42, 0.68, mist);   // v61: контрастнее облака
}

// ============================================================================
// Volumetric raymarch — accumulate color along ray
// ============================================================================
vec4 volumetricMarch(vec3 ro, vec3 rd) {
    // OPTIMIZATION: mediump для accumulation storage.
    // highp остаётся для ray position (точность важна), mediump для color accumulation.
    mediump vec3 totalColor = vec3(0.0);
    mediump float totalAlpha = 0.0;

    // OPTIMIZATION: Adaptive step size — larger steps in empty regions.
    // В плотных областях шаг нормальный (точность), в пустых — 2.5× (speed).
    float baseStepSize = (VOLUME_FAR - VOLUME_NEAR) / float(uVolumeSteps);

    float t = VOLUME_NEAR;
    for (int i = 0; i < MAX_VOLUME_STEPS; i++) {
        if (i >= uVolumeSteps) break;  // adaptive step count
        if (t >= VOLUME_FAR) break;
        vec3 p = ro + rd * t;

        float density = densityField(p) * DENSITY_SCALE;

        if (density > 0.001) {
            // Цвет: mix primary и accent в зависимости от density.
            float colorMix = smoothstep(0.2, 0.8, density);
            mediump vec3 localColor = mix(colorize(uPrimaryColor), colorize(uAccentColor), colorMix);

            // Brightness modulation: distance fade + uIntensity + uPulse.
            float distFade = 1.0 / (1.0 + t * 0.1);
            float brightness = uIntensity * distFade * (1.0 + uPulse * 0.5);

            // Front-to-back accumulation.
            mediump float sampleAlpha = density * baseStepSize * 0.3;
            mediump vec3 sampleColor = localColor * brightness;

            totalColor += (1.0 - totalAlpha) * sampleColor * sampleAlpha;
            totalAlpha += (1.0 - totalAlpha) * sampleAlpha;

            // Early exit if fully opaque.
            if (totalAlpha > 0.95) break;
        }

        // ADAPTIVE STEP: 2.5× larger step in empty regions (density < 0.01),
        // normal step in dense regions. Эффективно покрывает больше empty space
        // тем же числом iterations.
        float stepMult = (density < 0.01) ? 2.5 : 1.0;
        t += baseStepSize * stepMult;
    }

    return vec4(totalColor, totalAlpha);
}

// ============================================================================
// Background + post-processing
// ============================================================================

// Тёмный фон с лёгкой tint от primary color.
vec3 backgroundColor(vec3 rd) {
    float t = 0.5 + 0.5 * rd.y;
    vec3 base = mix(vec3(0.02, 0.02, 0.04), vec3(0.05, 0.06, 0.10), t);
    return base + uPrimaryColor * 0.03 * (1.0 - t);
}

// ACES tonemap.
vec3 aces(vec3 c) {
    return (c * (2.51 * c + 0.03)) / (c * (2.43 * c + 0.59) + 0.14);
}

// ============================================================================
// Main
// ============================================================================
void main() {

    // --- Pipeline defaults: guard against unset uniforms (0 in GLSL) ---
    vec3  primaryColor = max(uPrimaryColor, vec3(0.001));
    float intensity    = max(uIntensity, 1.0);
    float motionSpeed  = max(uMotionSpeed, 0.0);
    float pulse        = max(uPulse, 0.0);

    vec2 fragUv = gl_FragCoord.xy / uResolution;
    vec2 uv = (fragUv * 2.0 - 1.0) * vec2(uResolution.x / uResolution.y, 1.0);

    // Камера: статичная (или лёгкое вращение), смотрит вдоль +Z.
    float cam_t = uTime * 0.05 * motionSpeed;
    vec3 ro = vec3(sin(cam_t) * 1.5, 0.0, -6.0);
    vec3 ta = vec3(0.0, 0.0, 0.0);
    vec3 fwd = normalize(ta - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
    vec3 up = cross(fwd, right);
    vec3 rd = normalize(fwd + uv.x * right + uv.y * up);

    // Volumetric march.
    vec4 vol = volumetricMarch(ro, rd);

    // Background (виден там, где volumetric alpha < 1).
    vec3 bg = backgroundColor(rd);
    // v61: un-premultiply + coverage remap.
    // Без этого alpha ~0.08 гасит любой цвет: mix(bg, vol.rgb, 0.08) ≈ bg.
    vec3 avgLight = vol.rgb / max(vol.a, 1e-4);            // средний цвет облака вдоль луча
    float cover   = 1.0 - exp(-vol.a * COVERAGE_GAIN);     // видимая плотность 0..1
    vec3 col = mix(bg, avgLight * EXPOSURE, cover);

    // Pulse brightness boost.
    col += uAccentColor * pulse * 0.2;

    // Vignette.
    vec2 vd = fragUv - 0.5;
    col *= 1.0 - 0.35 * dot(vd, vd) * 2.0;

    // ACES + gamma.
    col = aces(col);
    col = pow(clamp(col, 0.0, 1.0), vec3(1.0 / 2.2));

    FragColor = vec4(col, 1.0);
}
