---

## 15. Миграция с прежней версии `engine.py`

Этот раздел — для тех, у кого уже есть код на старом `engine.py` (один файл ~200 строк из архива `For Deepseek/Uroboros/engine.py`). Новая версия — пакет `uroboros/` с сохранением всех публичных имён и совместимым `.uroboros/`-хранилищем.

### 15.1 Что изменилось (обзор)

| Аспект | Старая версия (`engine.py`) | Новая версия (`uroboros/`) |
|---|---|---|
| Форма поставки | один файл `engine.py` | пакет `uroboros/` + `pyproject.toml` |
| Импорт | `from engine import Uroboros, FileMemory, PatchRegistry, FORMAT, PatchError, canonical, digest, read_json` | `from uroboros import Uroboros, FileMemory, PatchRegistry, FORMAT, PatchError, canonical, digest, read_json` |
| Разбиение | всё в одном файле | `formats / memory / registry / engine / plan / adapters / glm / cli` |
| CLI | отсутствует | `python -m uroboros ...` и точка входа `uroboros` |
| Готовые планы | пишутся вручную | `plan.simple_room_plan`, `plan.full_plan` |
| Мосты в подсистемы | нет | `adapters` (Color Matrix / Cozy Engine) |
| GLM-feedback | через свой `glm_propose` | то же + готовый `glm.make_glm_proposer()` |
| Кеш параллельных записей | гонка tmp-файлов | uuid-суффиксы, безопасно |
| Сохранение `failed`-состояния | нет | есть (`save_run` в `except`) |
| Совместимость `.uroboros/` | — | полная, см. 15.6 |

### 15.2 Карта соответствия модулей

| Старый `engine.py` | Новый файл | Комментарий |
|---|---|---|
| `FORMAT`, `canonical`, `digest`, `PatchError` | `uroboros/formats.py` | без изменений |
| `read_json` | `uroboros/memory.py` | реэкспортируется через `uroboros` |
| `class FileMemory` | `uroboros/memory.py` | + `load_run`, `stats`, потокобезопасные tmp |
| `class PatchRegistry` | `uroboros/registry.py` | + проверка дубликатов `OP`, + `apply` с понятной ошибкой |
| `class Uroboros` | `uroboros/engine.py` | + try/except вокруг цикла, `state["error"]` при `failed` |
| `make_patch`, `make_feedback` | методы `Uroboros` | без изменений в сигнатуре |
| `_execute_one`, `_checklist` | методы `Uroboros` | без изменений в поведении |

Всё, что раньше импортировалось из `engine`, теперь доступно из корня пакета:

```python
from uroboros import (
    Uroboros, FileMemory, PatchRegistry,
    FORMAT, PatchError, canonical, digest,
)
from uroboros.memory import read_json   # read_json переехал сюда
```

### 15.3 Совместимость импортов

Полный список старых импортов и их замена:

```python
# старое
from engine import Uroboros, FileMemory, PatchRegistry, FORMAT, PatchError, canonical, digest, read_json

# новое
from uroboros import Uroboros, FileMemory, PatchRegistry, FORMAT, PatchError, canonical, digest
from uroboros.memory import read_json
```

Если менять код нельзя — положите рядом файл `engine.py`-шима:

```python
# engine.py (в корне проекта, рядом с patches/)
"""Шим для обратной совместимости со старой версией engine.py."""
from uroboros import (  # noqa: F401
    FORMAT, PatchError, FileMemory, PatchRegistry, Uroboros, canonical, digest,
)
from uroboros.memory import read_json  # noqa: F401
```

Тогда `from engine import ...` продолжит работать.

### 15.4 Изменения в API

Все публичные методы сохранены. Отличия — только расширения:

**`Uroboros.run`** — параметры те же (`plan, max_iterations, require_approval, approval, feedback`). Появилось:

- при исключении состояние всё равно сохраняется в `runs/` со `status="failed"` и полем `state["error"]`;
- в `state` всегда есть `"pipeline_cache_key"`.

```python
# старое (одинаково работает)
state = u.run(plan, max_iterations=4, require_approval=True, approval=approve)

# новое: удобно смотреть причину падения
try:
    u.run(plan, require_approval=False)
except PatchError as exc:
    last = u.memory.load_run(sorted(p.name for p in u.memory.runs.glob("*.json"))[-1])
    print(last["status"], last.get("error"))
```

**`FileMemory`** — новые методы:

- `load_run(run_id) -> dict | None`;
- `stats() -> dict` (`blobs`, `blob_size_bytes`, `cache_entries`, `runs`, `journal_lines`).

```python
u.memory.stats()
# {'root': '.uroboros', 'blobs': 3, 'blob_size_bytes': 42,
#  'cache_entries': 8, 'runs': 2, 'journal_lines': 17}
```

**`PatchRegistry`** — при дубликате `OP` теперь бросается `PatchError` на `__init__`, а не «последний выигрывает». Если в вашей папке случайно два файла с одинаковым `OP`, это выявится сразу.

**`make_feedback`** — сигнатура не изменилась. Вернувшийся объект по-прежнему валиден, движок проверит `format`/`operation`.

### 15.5 Исправленные баги

Мигрируя, вы получаете три исправления, которых не было в старой версии.

**1. Гонка tmp-файлов в `FileMemory`.** Старый код:

```python
tmp = path.with_suffix(".tmp")   # одинаковое имя для всех писателей!
tmp.write_bytes(canonical(record))
os.replace(tmp, path)
```

При параллельных записях в один `blob` или `cache_key` два потока били в один `*.tmp` и портили файл. Новый код:

```python
tmp = path.with_name(f"{path.name}.{uuid.uuid4().hex}.tmp")
```

Уникальный суффикс на каждый вызов, `os.replace` атомарен.

**2. Потеря состояния при падении.** Старый `run()` писал `save_run` только в конце; исключение в середине оставляло «висящий» run без записи. Новый код оборачивает цикл в try/except, пишет `state["status"]="failed"` и `state["error"]`, re-raise.

**3. `read_json` не был экспортирован.** Старый `engine.py` определял `read_json`, но `from engine import *` не включал его (не было `__all__`). В новом пакете `read_json` есть в `uroboros.memory` и реэкспортируется через `uroboros` (если нужно — используйте прямой импорт).

### 15.6 Совместимость `.uroboros/`

Формат папки не менялся. Все старые записи читаются новой версией, новые — старой (кроме исправлений, которых в старой просто не будет).

| Путь | Старая версия | Новая версия |
|---|---|---|
| `blobs/<xx>/<sha>` | ✅ | ✅ (тот же формат) |
| `cache/<xx>/<key>.json` | ✅ | ✅ (ключ не изменился) |
| `runs/<run_id>.json` | ✅ пишет в конце | ✅ пишет всегда, включая `failed` |
| `pipeline_cache/<xx>/<key>/<run_id>.json` | ✅ | ✅ |
| `memory.jsonl` | ✅ | ✅ (+ новые события `run_failed`) |

Ключ кеша строится так же: `digest({target, op, script_sha, params, input_hash})`. Если версии скриптов в `patches/` не менялись, кеш продолжит попадать. Если меняли скрипт — старые записи просто не используются (ключ содержит `script_sha`), новые создадутся.

**Проверка совместимости:**

```bash
# на старой версии посмотреть, какие run_id есть
ls .uroboros/runs

# на новой версии открыть один из них
python -m uroboros inspect --run <run_id>
```

Если `inspect` показывает `status="approved"` и `"iterations": [...]` — формат совместим.

### 15.7 Новые патчи

Старая папка `patches/` содержала три файла: `geometry.py`, `palette.py`, `compose.py`. Новая версия сохраняет их и **добавляет** три:

| Патч | Назначение | Появился |
|---|---|---|
| `geometry.generate` | геометрия комнаты | старая версия |
| `color.palette` | палитра по mood | старая версия (теперь с `adapters`) |
| `scene.compose` | сборка сцены | старая версия |
| `validate.scene` | проверка геометрии/палитры/настроения | **новый** |
| `color.describe` | профиль цвета через Color Matrix | **новый** |
| `cozy.plan_room` | план комнаты через Cozy Engine | **новый** |

Старые патчи работают как раньше, но теперь:

- `palette.py` сначала пробует `adapters.build_palette_via_matrix` и только при неудаче возвращает fallback. Выход получил поля `source` и `reason` (старое поле `palette` и `mood` сохранены).
- `geometry.py` пробует Cozy Engine, но при отсутствии возвращает тот же `room_geometry` с `source: "fallback_box"`.

**Старые потребители `outputs["palette"]["palette"]` продолжат работать** — структура ответа расширена, не заменена.

Если не хотите новых патчей — просто не добавляйте файлы в `patches/`. `PatchRegistry` грузит то, что есть.

### 15.8 Пошаговая миграция

**Шаг 0. Зафиксируйте текущее состояние.**

```bash
cp -r .uroboros .uroboros.backup
tar czf patches.backup.tgz patches/
```

**Шаг 1. Установите пакет.**

```bash
pip install -e .
```

(В вашем проекте — распакуйте `uroboros-0.3.0/` рядом и выполните `pip install -e uroboros-0.3.0/`.)

**Шаг 2. Переключите импорты.**

```diff
- from engine import Uroboros, FileMemory, PatchRegistry, FORMAT, PatchError
+ from uroboros import Uroboros, FileMemory, PatchRegistry, FORMAT, PatchError
```

Если менять код нельзя — положите `engine.py`-шим из 15.3.

**Шаг 3. Проверьте патчи.**

```bash
python -m uroboros patches
```

Должны увидеть все свои `OP` (плюс новые, если скопировали). Если нет — проверьте, что `--patches` указывает на вашу папку.

**Шаг 4. Прогоните один старый run через новую версию.**

```bash
python -m uroboros run --plan <старый_plan.json> --auto-approve
```

Сравните `outputs` с прошлым запуском. Если что-то не так — см. 15.9.

**Шаг 5. (Опционально) Включите интеграцию с подсистемами.**

```bash
export UROBOROS_COLOR_MATRIX_PATH=/path/to/parent
export UROBOROS_COLOR_MATRIX_NPZ=/path/to/color_matrix.npz
export UROBOROS_COZY_PATH=/path/to/parent
export UROBOROS_COZY_MATRIX_NPZ=/path/to/cozy_matrix.npz
```

Перезапустите — `palette.py` начнёт отдавать `source: "color_matrix"`.

**Шаг 6. Постепенно переводите вызовы на новый API.**

Типичные замены:

```python
# было: вручную собирать patch
patch = u.make_patch("scene", "geometry.generate", params={"width": 5.0})

# стало: то же самое, но можно вызвать план целиком
from uroboros import simple_room_plan
state = u.run(simple_room_plan(width=5.0, depth=4.0), require_approval=False)
```

```python
# было: свой glm_propose
def glm_propose(result, iteration):
    return call_my_llm(result)

# стало: либо свой, либо готовый
from uroboros.glm import make_glm_proposer
u = Uroboros(glm_propose=make_glm_proposer())
```

**Шаг 7. Удалите резервные копии после проверки.**

```bash
rm -rf .uroboros.backup patches.backup.tgz
```

### 15.9 Чек-лист проверки после миграции

- [ ] `python -m uroboros patches` показывает все ваши операции.
- [ ] `python -m uroboros inspect --run <старый_run_id>` открывает старый run.
- [ ] `python -m uroboros cache-stats` показывает непустой `cache_entries` (кеш читается).
- [ ] `pytest -q` в `uroboros-0.3.0/` зелёный.
- [ ] Один ваш рабочий план отрабатывает с `--auto-approve` и даёт тот же `outputs` (или объяснимо другой: например, `source` появился).
- [ ] `from engine import ...` (если используете шим) работает.
- [ ] При искусственной ошибке в патче run сохраняется со `status="failed"` и `error` (проверка 15.5 п.2).
- [ ] Параллельный запуск двух процессов `uroboros run` не портит `blobs/` (проверка 15.5 п.1).

### 15.10 Известные ограничения миграции

- **Старые `runs/` не получат `pipeline_cache_key`** — это поле появилось в 0.3.0. `inspect` его просто не покажет.
- **Старые `cache/` без валидации blob'ов.** В старой версии `cache_get` не проверял sha256; новая проверяет. Если блоб повреждён, `cache_get` вернёт `None` и патч выполнится заново — это безопасно, но не «прозрачно» по времени.
- **`read_json` переехал.** Если вы импортировали его из `engine`, а шим не положили — импорт упадёт. Используйте `from uroboros.memory import read_json` или шим.
- **Новые патчи (`validate.scene`, `color.describe`, `cozy.plan_room`) могут конфликтовать по имени**, если у вас в `patches/` уже были одноимённые `OP`. Проверьте: `python -m uroboros patches` не должен падать с `duplicate OP`.