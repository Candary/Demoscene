# Анализ проекта «Unlimited demo»

Посмотрел структуру репозитория (418 файлов, ~4.3 МБ кода). Проект амбициозный: C++ демо-интро + Python-пайплайн генерации (цвета, сцены, шейдеры, оптимизация). Ниже — честная обратная связь по твоим четырём критериям.

---

## 1. Лёгкость реализации ⭐⭐⭐☆☆

### Что хорошо
- **Чёткое разделение**: C++ рантайм (`demo_intro/`) отделен от Python-генерации (`color_matrix/`, `cozy_engine/`, `scripts/`). Это правильно — рантайм должен быть минимальным и быстрым.
- **Декларативные конфиги**: JSON (`booster_final.json`, `btb_stats.json`) как контракт между генератором и рантаймом — отличный выбор. Версионируются, валидируются, не требуют перекомпиляции.
- **Политики в Markdown** (`color_policy.md`, `shader_color_policy.md`, `cozy_policy.md`) — человекочитаемые правила, которые можно править без кода.

### Что усложняет жизнь
| Проблема | Где проявляется | Лечение |
|----------|-----------------|---------|
| **Дублирование логики** | `color_matrix/output/color_matrix_python/` vs `cozy_engine/` vs `scripts/` — похожие утилиты (парсинг цветов, vocab, tools) живут в трёх местах | Вынести shared-ядро в `core/` (pip-пакет или submodule), импортировать везде |
| **Слишком много скриптов-патчей** | 30+ файлов `patch_*.py` в `scripts/` — каждый правка шейдеров/кода ad-hoc | Заменить на **единый кодогенератор** (Jinja2 / string-template) + параметрические пресеты |
| **Нет единого CLI** | `cli.py` есть, но скрипты вызываются напрямую через `python scripts/xxx.py` | `poetry run demo generate --preset X --out build/` — одна точка входа |
| **Тесты разбросаны** | `color_matrix/tests/`, `cozy_engine/tests/`, `pandoc_docx/tests/` — разные фреймворки, нет CI-интеграции | `pytest` + `tox` / GitHub Actions, единый `make test` |

### Практичный совет
```
my-project/
├── core/                 # общий питоний код (colorspace, vocab, json schema)
├── generator/            # пайплайн: scene → shaders → json → optimize
│   ├── __main__.py       # CLI: generate / validate / benchmark
│   └── pipeline.py       # этапы с кэшированием
├── runtime/              # C++ (demo_intro/) — только чтение JSON + рендер
└── presets/              # .json пресеты.demo, валидируемые схемой
```
Уберёшь 60% ad-hoc скриптов.

---

## 2. Оптимизация ⭐⭐⭐⭐☆

### Сильные стороны (видно по артефактам)
- **Shader Minifier / Crinkler ready**: `build_mingw.bat`, `build_msvc.bat`, `opengl_loader.h` — есть инфраструктура для size-coding.
- **Процедурные текстуры/геометрия**: `procedural_fire.py`, `make_fire_texture_h.py`, `embed_fire_tex.py` — правильно, не таскать ассеты.
- **Профилирование в репо**: `perf_analysis.md` (713 строк), `patch_optimize_v1.py`, `patch_shaders_optimize.py` — вы уже меряете.

### Упущенные возможности (GPU)
| Область | Что добавить | Выигрыш |
|---------|--------------|---------|
| **Compute-shader препас** | SDF BVH, lookup-таблицы для noise, превычисление palette LUT | Снимает работу с фрагментного шейдера, стабильный 60fps |
| **Wave/warp ops** | `subgroupQuadSwap`, `subgroupShuffle` для ray-step sharing | −15–30% инструкций в raymarch |
| **Bindless / descriptor indexing** | Один набор дескрипторов на кадр, никаких `glBind*` | CPU overhead → 0 |
| **Indirect draw** | `glDrawArraysIndirect` + compute-culling | GPU-driven pipeline, ноль CPU-drawcalls |

### Упущенные возможности (CPU / генерация)
- **Кэширование этапов пайплайна**: `pipeline.py` с `@lru_cache` / `joblib.Memory` по хешу входных параметров → повторная генерация за миллисекунды.
- **Параллельная генерация сцен**: `concurrent.futures.ProcessPoolExecutor` для независимых сцен / вариантов.
- **Инкрементная компиляция шейдеров**: `glslang` + SPIR-V cache (вижу `tools/glslang/` — используй `glslangValidator --cache-dir`).

### Практичный совет
Добавь в генератор этап `optimize_shaders(spirv)`:
```python
# generator/optimize.py
def optimize_shaders(spirv_bytes: bytes, target: str = "size") -> bytes:
    # 1. spirv-opt -O (size/speed)
    # 2. удаление dead code, объединение констант
    # 3. для size: spirv-remap + strip debug
    return optimized_spirv
```
И в C++ рантайме — загрузку уже оптимизированного SPIR-V (не GLSL-строк).

---

## 3. Гибкость ⭐⭐⭐☆☆

### Что ограничивает
1. **Жёсткая схема JSON** (`booster_final.json` ~1 МБ) — любое изменение структуры ломает совместимость с рантаймом.
2. **Политики в Markdown** — невалидируемые, LLM их «галюцинирует» при генерации.
3. **Нет системы плагинов** — добавить новый тип примитива / эффекта = правка кода в нескольких местах.

### Архитектура, дающая гибкость
```
┌─────────────────────────────────────────────────────────────┐
│  Schema (JSON Schema / msgpack schema) — единственный источник│
│  истины для: runtime, generator, validator, UI               │
├─────────────────────────────────────────────────────────────┤
│  Registry (entry-points)                                      │
│   ├── primitives:  sdBox, sdSphere, sdTorus, custom...       │
│   ├── modifiers:  twist, bend, repeat, morph...              │
│   ├── materials:  glossy, matte, glass, emission...          │
│   ├── postfx:     bloom, chromatic_aberration, film_grain... │
│   └── audio_react: beat, spectrum, onset...                  │
├─────────────────────────────────────────────────────────────┤
│  Graph IR (DAG) → сериализуется в JSON → runtime интерпретирует│
└─────────────────────────────────────────────────────────────┘
```

### Практичный совет
1. **Введи JSON Schema** для `booster_final.json` (храни в `schemas/demo.v1.json`). Генератор и рантайм валидируют при старте.
2. **Сделай `primitives.py` регистром**: `@register_primitive("sdHeart")` — новые примитивы подключаются файлом, без правки ядра.
3. **Graph IR вместо плоского JSON**: сцена = ноды + связи. Тогда «unlimited» становится комбинаторикой нод, а не конкатенацией строк.

---

## 4. Скорость генерации ⭐⭐⭐⭐☆

### Где теряется время сейчас
| Этап | Оценка | Причина |
|------|--------|---------|
| Запуск Python / импорты | 0.5–1.5 с | 58 `.py` файлов, тяжёлые импорты (`numpy`, `glslang`) |
| Генерация шейдеров (строки) | 1–3 с | `patch_*.py` делают много `str.replace`, регэкспов |
| Компиляция GLSL → SPIR-V | 2–5 с | `glslangValidator` на каждом запуске |
| Запись JSON (1 МБ) | 0.2 с | `json.dump` без `orjson` / `msgspec` |

### Целевой бюджет: **< 2 с** (hot reload шейдеров), **< 10 с** (полная перегенерация демо).

### Практичные ускорения
1. **Lazy imports** — `numpy`, `glslang` импортируй только внутри функций, которые их используют.
2. **orjson / msgspec** вместо `json` — в 5–10× быстрее сериализация 1 МБ.
3. **SPIR-V кэш**: `~/.cache/unlimited_demo/spirv/<hash>.spv` — компилируй только изменившиеся шейдеры.
4. **Шаблонизатор вместо патчей**: Jinja2 компилируется в байткод, рендерит за миллисекунды.
5. **Инкрементная генерация**: хеш конфига → если не менялся — берём готовый `booster_final.json` из кэша.

```python
# generator/pipeline.py
from functools import lru_cache
import hashlib, orjson, subprocess, os

SHADER_CACHE = Path.home() / ".cache" / "unlimited_demo" / "spirv"
SHADER_CACHE.mkdir(parents=True, exist_ok=True)

@lru_cache(maxsize=128)
def compile_glsl_to_spirv(glsl: str, stage: str) -> bytes:
    key = hashlib.blake2b(glsl.encode(), digest_size=16).hexdigest()
    path = SHADER_CACHE / f"{key}.{stage}.spv"
    if path.exists():
        return path.read_bytes()
    # glslangValidator -V -S <stage> -o ...
    result = subprocess.run(...)
    path.write_bytes(result.stdout)
    return result.stdout
```

---

## Итоговая таблица приоритетов

| Приоритет | Действие | Влияет на критерии |
|-----------|----------|-------------------|
| **P0** | Вынести `core/` (colorspace, vocab, schema), убрать дубликаты | 🟢 Лёгкость, 🟢 Скорость |
| **P0** | JSON Schema + валидатор для `booster_final.json` | 🟢 Гибкость, 🟢 Лёгкость |
| **P1** | Единый CLI `demo generate/validate/benchmark` | 🟢 Лёгкость |
| **P1** | SPIR-V кэш + `glslang` programmatic API (не subprocess) | 🟢 Скорость, 🟢 Оптимизация |
| **P2** | Graph IR (ноды/связи) вместо плоского JSON | 🟢 Гибкость, 🟢 Оптимизация |
| **P2** | Compute-shader препас (BVH, LUT) | 🟢 Оптимизация |
| **P3** | Реестр примитивов/модификаторов (entry-points) | 🟢 Гибкость |
| **P3** | CI: pytest + размер бинарника + FPS бенчмарк | 🟢 Все |

---

## Что хвалить (ты это уже делаешь правильно)
- **Полный контроль пайплайна** — от цвета до бинарника, никаких «чёрных ящиков».
- **Процедурность везде** — текстуры, геометрия, палитры, звук — кодом.
- **Документация как код** — `pandoc_docx/`, `roadmap.md`, политики — это редкость и сила.
- **Инструментарий для size-coding** — Crinkler, кастомные загрузчики, оптимизаторы шейдеров.

---

## Первый шаг на завтра
Создай `core/schema/demo.v1.json` (JSON Schema для `booster_final.json`) и добавь в `cli.py`:
```bash
demo validate booster_final.json   # выход 0/1, читаемые ошибки
demo generate --preset party --out build/
```
Это сразу даст безопасность рефакторинга и точку входа для CI.

---

