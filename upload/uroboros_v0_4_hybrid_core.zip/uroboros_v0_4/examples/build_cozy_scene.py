from __future__ import annotations
import json
import os
from pathlib import Path

from uroboros import Uroboros, FORMAT
from integration.runtime import runtime_fingerprint

ROOT = Path(__file__).resolve().parents[1]

PLAN = {
    "format": FORMAT,
    "name": "cozy-living-room",
    "nodes": [
        {"id": "atmosphere", "target": "cozy", "operation": "atmosphere.resolve",
         "params": {"room": "living_room", "count": 4, "must_have": ["sofa"]}},
        {"id": "geometry", "target": "cozy", "operation": "geometry.build", "needs": ["atmosphere", "palette"],
         "params": {"room_width": 7.0, "room_depth": 6.0, "margin": 0.45, "gap": 0.18}},
        {"id": "palette", "target": "color", "operation": "palette.build", "needs": ["atmosphere"],
         "params": {"min_delta_e": 0.04}},
        {"id": "scene", "target": "scene", "operation": "scene.assemble",
         "needs": ["atmosphere", "geometry", "palette"],
         "params": {"lighting": "soft_indirect"}},
        {"id": "validation", "target": "validator", "operation": "scene.validate",
         "needs": ["scene", "palette"], "params": {}},
    ],
}


def approve(result):
    validation = result["outputs"]["validation"]["validation"]
    print("\nValidation:", json.dumps(validation, ensure_ascii=False, indent=2))
    if not validation["ok"]:
        print("Есть ошибки; результат не может быть одобрен.")
        return False
    return input("Одобрить результат? [y/N] ").strip().lower() == "y"


def manual_feedback(result, iteration):
    print("\nТекущая итерация:", iteration)
    print("Введите JSON изменения параметров, например:")
    print('{"geometry":{"params":{"placements":{"sofa":{"x":-0.4,"z":0.2}}}}}')
    raw = input("Feedback JSON (Enter — остановить): ").strip()
    if not raw:
        return None
    changes = json.loads(raw)
    engine = app_engine[0]
    return engine.make_feedback(changes, iteration=iteration + 1, reason="manual user feedback")


app_engine = []

if __name__ == "__main__":
    engine = Uroboros(root=ROOT / ".uroboros_memory", patches=ROOT / "patches",
                      workers=2, runtime_fingerprint=runtime_fingerprint())
    app_engine.append(engine)
    result = engine.run(PLAN, max_iterations=3, require_approval=True,
                        approval=approve, feedback=manual_feedback)
    out = ROOT / "artifacts"
    out.mkdir(exist_ok=True)
    (out / "latest_run.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if result.get("approved"):
        (out / "approved_scene.json").write_text(json.dumps(result["final"]["outputs"]["scene"]["scene"],
                                                            ensure_ascii=False, indent=2), encoding="utf-8")
    print("\nRun status:", result["status"])
    print("Run ID:", result["run"])
    print("Saved:", out)
