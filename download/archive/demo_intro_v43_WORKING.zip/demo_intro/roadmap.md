# ROADMAP — рабочая память проекта Demo Intro

**ПЕРЕЧИТЫВАТЬ ПРИ КАЖДОМ ЗАПРОСЕ!** Сохранять в `/home/z/my-project/roadmap.md`
и `/home/z/my-project/download/demo_intro/roadmap.md` (backup).

## 📌 ТЕКУЩЕЕ СОСТОЯНИЕ (v43 — exact-ABI + сплит строк MSVC)

**Проект:** демо-интро на C++/OpenGL 3.3 + WebGL2 preview
**Папка:** `/home/z/my-project/download/demo_intro/`
**Архив:** `/home/z/my-project/download/demo_intro_latest.zip`

**Окружение пользователя:** Windows 11 Pro 23H2, NVIDIA GeForce GTX 750,
driver 560.94, OpenGL 3.3 core.

### КОРНЕВАЯ ПРИЧИНА НАЙДЕНА И ДОКАЗАНА (лог v41 + дизассемблер):

Лог v41 (MSVC): контекст NVIDIA создан отлично (3.3 core, GLSL 3.30,
pixel format 32/24/8), затем 0xC0000005 по адресу 0x6C9D9590 —
диапазон 32-битного nvoglv32.dll → СБОРКА БЫЛА 32-БИТНОЙ (видимо,
запускали не из x64 Native Tools prompt). Краш на первом
глCreateShader/glShaderSource.

**Виновник — вариадик-указатель type (*)(...) из Task 20:**
- MSVC x86: вариадик = cdecl, а GL-функции = stdcall → дрейф ESP →
  краш внутри драйвера (симптом пользователя)
- MinGW/MSVC x64: int/ptr аргументы случайно работают, НО float
  ПРОДВИГАЕТСЯ В DOUBLE (cvtss2sd — доказано дизассемблером,
  scripts/abi_test_proof.cpp): драйвер читает младшие 32 бита XMM1
  как float → мусорные биты → uTime/uResolution/камера = 0/денормалы
  → ЧЁРНЫЙ ЭКРАН (вся история бага с mingw!)
- v42 ФИКС: точные прототипы с APIENTRY (stdcall x86 / пусто x64),
  как GLEW/glad. Дизассемблер: чистый jmp, float в XMM1 без
  конверсии. Лечит ОБА симптома (краш MSVC x86 + чёрный экран mingw).

### Что в v42:
- opengl_loader.h ПОЛНОСТЬЮ ПЕРЕПИСАН: 26 функций с точными
  сигнатурами по спецификации GL 3.3, APIENTRY, без GL-typedef'ов
  (GLchar→char, GLsizeiptr→ptrdiff_t из <stddef.h>, GLboolean→
  unsigned char — этих typedef'ов нет в gl.h 1.1)
- main.cpp: [Start]-лог теперь показывает arch=32/64-bit
- build_msvc.bat: печатает %VSCMD_ARG_TGT_ARCH% (цель сборки)
- Вся диагностика v41 сохранена: лог-файл, CrashHandler,
  GL-строки, имя GL-функции, стек 8 МБ
- ✅ mingw-компиляция: 0 ошибок, 0 варнингов от нашего кода
- ✅ ABI-доказательство: scripts/abi_test_proof.cpp + objdump

### Что добавлено в v43 (фикс C2026 «слишком большая строка»):
При сборке x64 (Target architecture: x64) MSVC выдал C2026 на
shaders.h(344). ПРИЧИНА НАЙДЕНА ТОЧНО: лимит одного строкового
токена в x64 cl = 16,384 байта; наш главный фрагментный шейдер был
разбит на 2 литерала 17,995 + 16,192 байт. Математика совпала
байт-в-байт: 17,995 - 16,384 = 1,611 байт ≈ 27 строк от конца
литерала (строка 371-27 = 344) — ошибка указала на точку отсечения.
Прошлая сборка прошла потому что была 32-битной (адрес краша
0x6C9D9590 = 32-битная nvoglv32.dll), там лимит мягче.
ФИКС: оба литерала разбиты на куски ≤ 8,000 байт (скрипт
scripts/split_shader_literals.py, assert на байт-в-байт склейку;
проверено: суммарный текст шейдеров 37,612 байт идентичен v42).
Смежные строковые литералы C++ склеивает сам (фаза трансляции 6).
Плюс #define _CRT_SECURE_NO_WARNINGS в main.cpp (ушли 4 варнинга
C4996 strcpy/fopen).
✅ mingw-компиляция: 0 ошибок, 0 варнингов.

### Backup: `backup_v42_exact_abi/` (пред.), `backup_v43_msvc_strsplit/` (тек.)
### Архив: demo_intro_latest.zip — 70010 байт, MD5 `c68bbb2d0d0a177f9cdce588abf86ff8`

### ИНСТРУКЦИЯ ПОЛЬЗОВАТЕЛЮ (v42):
1. Пересобрать build_msvc.bat. Батник теперь печатает Target architecture —
   желательно "x64" (из x64 Native Tools Command Prompt for VS 2022).
   С v42 работает и 32-битная сборка (stdcall корректен), но x64 предпочтителен.
2. Запустить demo_intro.exe.
3. Если снова проблема — прислать demo_intro_log.txt (теперь в [Start] виден
   arch=32/64-bit, это подтвердит/опровергнет диагноз).

---

## 📋 ВСЕ ЗАПРОСЫ (кратко)

19 — небула-фон (откачено в Task 34)
20 — opengl_loader.h mingw фикс (GLsizei=int, вариадик PFN)
21 — void* касты (убрать варнинги)
22 — -static (libstdc++-6.dll)
23 — DPI + fullscreen
24 — /MT для MSVC
25 — objdump анализ
26 — расширенное логирование
27 — VAO фикс (GL_INVALID_OPERATION ушёл, но экран чёрный)
28 — glReadPixels: (0,0,0) во всех пикселях → шейдер пишет чёрный
29 — droplets off (рекурсия)
30 — roadmap.md создание
31 — debug gradient mode (G key) → жёлтый = GL pipeline работает
32 — PCG hash (не помог — mode 3/4/5 всё ещё чёрные)
33 — прямые клавиши 0/2/3/4/5
34 — rollback на v18
35 — v18 + minimal fixes
36 — v18 + PCG hash
37 — cleanup старых файлов
38 — MSVC ready (build_msvc.bat обновлён)
39 — MSVC compat: opengl_loader.h без GL typedef'ов + без __stdcall
    в вариадике (C2371/C2165), include order в main.cpp
40 — ПЕРЕСБОРКА АРХИВА (сессия оборвалась): -static восстановлен,
    roadmap.md в zip, компиляция перепроверена
41 — ДИАГНОСТИКА «ничего не происходит»: лог-файл, краш-фильтр,
    имя GL-функции, GL-строки, стек 8 МБ. РЕЗУЛЬТАТ: контекст NVIDIA
    OK, краш 0xC0000005 в nvoglv32.dll на первом GL-вызове → 32-битная
    сборка + cdecl/stdcall-мисматч
42 — КОРНЕВОЙ ФИКС: вариадик-указатель заменён точными APIENTRY-
    прототипами (26 функций). float→double promotion в вариадике
    доказан дизассемблером = причина чёрного экрана; cdecl/stdcall
    мисматч = причина краша. Лечит оба
43 — C2026 string too big при x64-сборке: лимит строкового токена
    x64 cl = 16,384 байт (математика совпала со строкой 344!).
    Оба литерала главного шейдера разбиты на куски ≤ 8 КБ с
    байт-в-байт проверкой склейки; + _CRT_SECURE_NO_WARNINGS

---

## 🛠 ИНСТРУМЕНТЫ

mingw cross-compiler (Linux):
```bash
mkdir -p /home/z/my-project/tools/debs && cd /home/z/my-project/tools/debs && \
apt-get download gcc-mingw-w64-x86-64-posix g++-mingw-w64-x86-64-posix \
  binutils-mingw-w64-x86-64 mingw-w64-common mingw-w64-x86-64-dev && \
mkdir -p extract && for deb in *.deb; do dpkg-deb -x "$deb" extract/ ; done
```

Compile (проверено 2026-10-30, exit 0, 0 варнингов от нашего кода):
```bash
BIN=/home/z/my-project/tools/debs/extract/usr/bin
INC=/home/z/my-project/tools/debs/extract/usr/x86_64-w64-mingw32/include
LIB=/home/z/my-project/tools/debs/extract/usr/x86_64-w64-mingw32/lib
SHAREINC=/home/z/my-project/tools/debs/extract/usr/share/mingw-w64/include
GCCLIB=/home/z/my-project/tools/debs/extract/usr/lib/gcc/x86_64-w64-mingw32/14-posix
export PATH=$BIN:$PATH
cd /home/z/my-project/download/demo_intro
x86_64-w64-mingw32-gcc-posix -x c++ -O2 -std=c++17 -Wall -Wextra -static \
  -static-libgcc -static-libstdc++ -o /tmp/demo_intro.exe main.cpp \
  -I$SHAREINC -I$INC -I. -B$GCCLIB -L$LIB \
  -luser32 -lgdi32 -lopengl32 -lwinpthread -lstdc++ -lm
```
(Варнинги -Wexpansion-to-defined от psdk_inc/intrin-impl.h — это системные
заголовки mingw, НЕ наш код; игнорировать.)

---

## 📝 ПРАВИЛА

1. ПЕРЕЧИТЫВАТЬ roadmap.md в начале каждого запроса.
2. Если primary отсутствует — восстановить из backup.
3. Проверять state через grep — при расхождении пере-применять фиксы
   (State drift guard, см. реальный случай: потеря -static при v39).
4. Перед отправкой архива — пройти чек-лист (v41):
   - opengl_loader.h: НЕТ typedef GLsizei/GLint/... (типы из GL/gl.h) ✓
   - opengl_loader.h: DECL_GL_FN без APIENTRY, вариадик (...) ✓
   - main.cpp: `#include <GL/gl.h>` ПЕРЕД "opengl_loader.h" ✓
   - `-static -static-libgcc -static-libstdc++` в build_mingw.bat ✓
   - `/MT /std:c++17 /Zc:__cplusplus /utf-8` в build_msvc.bat ✓
   - g_defaultVAO в main.cpp ✓
   - SetProcessDpiAwareness в main.cpp ✓
   - g_droplets = false ✓
   - mingw компиляция: 0 ошибок, 0 варнингов нашего кода ✓
   - Log() пишет в demo_intro_log.txt (файл, не только DebugView) ✓
   - SetUnhandledExceptionFilter + CrashHandler в main.cpp ✓
   - g_lastMissingGLFn в opengl_loader.h + лог имени ✓
   - GL_SHADING_LANGUAGE_VERSION 0x8B8C #ifndef в loader ✓
   - /F8388608 в build_msvc.bat, --stack,8388608 в build_mingw.bat ✓
   - в zip включён roadmap.md ✓
   - НИ ОДИН raw-литерал в shaders.h не больше 8,000 байт
     (лимит x64 MSVC 16,384) ✓
   - _CRT_SECURE_NO_WARNINGS в начале main.cpp ✓
5. ВСЕГДА сообщать пользователю: путь к архиву + MD5 + размер.
6. Backup в `backup_v{N}_*/` перед каждым архивом.
7. Параллельно обновлять roadmap.md (primary + backup).
8. ПОСЛЕ КАЖДОГО ЗАПРОСА — ЧИСТИТЬ СТАРЫЕ ФАЙЛЫ:
   - temp .bak_*, *.tmp, /tmp/demo_intro*.exe
   - backup folders старше 3 задач
   - Оставлять: source + build scripts + roadmap.md + 2-3 backups + zip
9. State drift guard: если grep возвращает 0 — пере-применить фиксы.
10. НЕ бросать сессию после правок без сборки архива и сообщения
    (путь + MD5 + размер) — иначе пользователь не может скачать.
