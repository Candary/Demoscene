OP = "atmosphere.resolve"

def apply(context, params):
    from integration.runtime import dispatch_cozy
    room = params.get("room", "living_room")
    plan = dispatch_cozy("cozy_scene_plan", {
        "room": room,
        "count": int(params.get("count", 6)),
        "avoid": params.get("avoid", []),
        "must_have": params.get("must_have", []),
        "include_parts": False,
    })
    if plan.get("error"):
        raise ValueError(plan["error"])
    return {"atmosphere": plan}
