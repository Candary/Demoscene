# Demo Runtime v52 (Iteration 2) — Grain post-effect

Итерация 2 v52: добавлен `grain` post-effect после `vignette`.
Код (`demo_runtime.cpp`, `gl_executor.hpp`, `sm_runtime.hpp`, `opengl_loader.h`) и
существующие шейдеры — **без изменений**. Изменена только `demo.smt`.

## Что изменилось относительно iter.1

| Параметр | iter.1 | iter.2 |
|----------|--------|--------|
| Клипов в .smt | 7 | **8** (добавлен `grn` post) |
| Shader programs (compiled) | 6 | **7** (+ grain) |
| Сегменты | 5 | 5 (та же структура, изменены ops) |
| Pipeline пост-обработки | vig → screen | **vig → fbo1 → grn → screen** |

Новый clip `grn`:
```
clip grn 26 post grain 0.0 120.0 0.0 120.0 normal 88008 - - 0.0
uni uAmount float = 0.20   (20% — заметный кинематографичный grain)
```

Грань анимированная (меняется каждый кадр через `hash3(gl_FragCoord, uTime*60)`),
амплитуда ±0.20 RGB — заметный плёночный шум, хорошо виден на средних тонах
и в тенях (особенно под vignette).

## Pipeline пост-обработки (iter.2)

**Simple segment** (1 сцена):
```
RENDER scene  → fbo0
POST vig      fbo0 → fbo1     (был → screen)
POST grn      fbo1 → screen   (новый)
PRESENT       screen
```

**Transition segment** (2 сцены + переход):
```
RENDER s1     → fbo0
RENDER s2     → fbo1
TRANSITION    fbo0,fbo1 → fbo2
POST vig      fbo2 → fbo3     (был → screen)
POST grn      fbo3 → screen   (новый)
PRESENT       screen
```

Дополнительный FBO (`fbo1` в simple, `fbo3` в transition) создаётся лениво
через `FBOPool::get(name)` — никаких изменений в коде не требуется.

## Состав (без изменений)

```
demo_intro_v51_clean/
├── README.md            (этот файл — обновлён для v52 iter.2)
├── build_demo_runtime.bat
├── demo.smt             (120 с, 8 клипов, 5 сегментов, +grain post)
├── demo_v51_60s.smt.bak (бэкап v51 60-секундной версии)
├── demo_v52_iter1_120s.smt.bak (бэкап iter.1 120-секундной версии)
├── demo_runtime.cpp     (без изменений относительно v51)
├── gl_executor.hpp      (без изменений)
├── opengl_loader.h      (без изменений)
├── sm_runtime.hpp       (без изменений)
└── shaders/             (11 .frag файлов, без изменений)
```

## Сборка и запуск

```bat
build_demo_runtime.bat
demo_runtime.exe
```

ESC — выход. trace.log пишется в текущую папку.

## Что должно произойти

Визуально — **то же самое 120-секундное демо что в iter.1**, но с лёгким
анимированным плёночным зерном поверх всего кадра (после vignette).
Эффект тонкий (8% амплитуды) — должен добавлять «текстуру», не отвлекая.

В `trace.log` ожидается:
```
[OK] 7 shader programs compiled   (было 6, добавился grain)
[Done] Show finished at T=120.0Xs, frames=~7300
```

FPS должен остаться в том же диапазоне (50–60 средний): grain — это
один texture sample + один hash на пиксель, стоимость <5% от vignette.

## Что дальше (iter.3)

После подтверждения, что grain работает чисто, переходим к итерации 3:
добавление `bloom` post-effect **перед** grain (bright-pass → blur → composite).
Это потребует обновления `bloom.frag` (сейчас он одноходовый) и сегментов.
