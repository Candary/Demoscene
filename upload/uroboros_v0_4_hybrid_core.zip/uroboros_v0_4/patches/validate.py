OP = "scene.validate"

def apply(context, params):
    upstream = context["upstream"]
    scene = upstream["scene"]["scene"]
    geom = scene["geometry"]
    w, d = geom["room"]["width"], geom["room"]["depth"]
    boxes = geom["footprints"]
    problems = []
    eps = float(params.get("epsilon", 1e-6))
    for b in boxes:
        if b["min_x"] < -w/2-eps or b["max_x"] > w/2+eps or b["min_z"] < -d/2-eps or b["max_z"] > d/2+eps:
            problems.append({"type": "out_of_room", "object": b["object"], "footprint": b})
    for i, a in enumerate(boxes):
        for b in boxes[i+1:]:
            overlap_x = min(a["max_x"], b["max_x"]) - max(a["min_x"], b["min_x"])
            overlap_z = min(a["max_z"], b["max_z"]) - max(a["min_z"], b["min_z"])
            if overlap_x > eps and overlap_z > eps:
                problems.append({"type": "footprint_overlap", "objects": [a["object"], b["object"]],
                                 "overlap_x": round(overlap_x, 4), "overlap_z": round(overlap_z, 4)})
    palette_validation = upstream["palette"].get("validation", {})
    warnings = []
    if palette_validation and not palette_validation.get("ok", False):
        # CVD separation is a warning for atmospheric/material palettes, not a hard
        # failure by default. UI/text palettes should opt into strict validation.
        if params.get("require_cvd_distinguishability", False):
            problems.append({"type": "palette_validation", "details": palette_validation.get("problems", [])})
        else:
            warnings.append({"type": "palette_cvd_warning", "details": palette_validation.get("problems", [])})
    return {"validation": {"ok": not problems, "problems": problems, "warnings": warnings,
                            "checks": ["room_bounds", "footprint_overlap", "palette_distinguishability"],
                            "limitations": ["No door/window clearance model", "No navigation-path or 3D collision test",
                                            "Footprints are conservative recipe AABBs; not mesh-level collision geometry"]}}
