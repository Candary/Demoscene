SMT 1
meta 35.0 60 1280 720 2026
audio 120.0 0.0 4 20.0 0
sections 0
clip intro 10 scene anxiety_mist 0.0 12.0 0.0 10.0 normal 2107455 - - 0.0
prog opacity 1 n:1.0
prog progress 4 v:p n:0.0 n:1.0 f:clamp
uni uPrimaryColor vec3 3
prog 1 n:0.3
prog 1 n:0.05
prog 1 n:0.1
uni uAccentColor vec3 3
prog 1 n:0.95
prog 1 n:0.1
prog 1 n:0.05
uni uIntensity float 1
prog 1 n:0.8
uni uMotionSpeed float 1
prog 1 n:1.2
uni uWarmth float 1
prog 1 n:0.5
endclip
clip main 10 scene sphere_scene 8.0 27.0 10.0 15.0 normal 7402506 - - 2.0
prog opacity 1 n:1.0
prog progress 4 v:p n:0.0 n:1.0 f:clamp
uni uColor vec3 3
prog 1 n:0.1
prog 1 n:0.5
prog 1 n:0.8
uni uGlow float 1
prog 1 n:1.2
uni uOrbit float 1
prog 4 v:t n:0.3 o:* f:sin
endclip
clip climax 10 scene particle_swarm 23.0 35.0 25.0 10.0 normal 10764635 - - 3.0
prog opacity 1 n:1.0
prog progress 4 v:p n:0.0 n:1.0 f:clamp
uni uColor vec3 3
prog 1 n:0.95
prog 1 n:0.2
prog 1 n:0.55
uni uSwarm float 1
prog 1 n:0.7
uni uBeatKick float 1
prog 5 n:1.0 v:audio.beat_phase o:- n:3.0 f:pow
endclip
clip t1 10 transition crossfade 8.0 12.0 8.0 4.0 normal 5448779 intro main 2.0
prog opacity 1 n:1.0
prog progress 4 n:0.0 n:1.0 v:p f:smoothstep
endclip
clip t2 10 transition flash 23.0 27.0 23.0 4.0 normal 9132820 main climax 3.0
prog opacity 1 n:1.0
prog progress 4 n:0.0 n:1.0 v:p f:smoothstep
uni uColor vec3 3
prog 1 n:1.0
prog 1 n:1.0
prog 1 n:1.0
uni uPeak float 1
prog 1 n:1.5
endclip
clip vig 25 post vignette 0.0 35.0 0.0 35.0 normal 5866140 - - 0.0
prog opacity 1 n:1.0
prog progress 1 n:1.0
uni uStrength float 1
prog 1 n:0.35
uni uSoftness float 1
prog 1 n:0.5
endclip
clip fin 30 event finish 35.0 35.0 0.0 0.0 normal 12345 - - 0.0
prog opacity 1 n:1.0
prog progress 1 n:0.0
endclip
seg 0.0 8.0 3 1 3
op RENDER intro - fbo0 - -
op POST vig fbo0 screen - -
op PRESENT - screen - - -
endseg
seg 8.0 12.0 5 3 5
op RENDER intro - fbo0 - -
op RENDER main - fbo1 - -
op TRANSITION t1 fbo0,fbo1 fbo2 - -
op POST vig fbo2 screen - -
op PRESENT - screen - - -
endseg
seg 12.0 23.0 3 1 3
op RENDER main - fbo0 - -
op POST vig fbo0 screen - -
op PRESENT - screen - - -
endseg
seg 23.0 27.0 5 3 5
op RENDER main - fbo0 - -
op RENDER climax - fbo1 - -
op TRANSITION t2 fbo0,fbo1 fbo2 - -
op POST vig fbo2 screen - -
op PRESENT - screen - - -
endseg
seg 27.0 35.0 3 1 3
op RENDER climax - fbo0 - -
op POST vig fbo0 screen - -
op PRESENT - screen - - -
endseg
end
