OP = "palette.build"

def apply(context, params):
    from integration.runtime import dispatch_color
    from cozy_engine import primitives
    upstream = context["upstream"]
    atmosphere = upstream["atmosphere"]["atmosphere"]
    room = params.get("room", atmosphere.get("room", "living_room"))

    roles = dict(atmosphere.get("palette", {}))
    slot_colors = dict(atmosphere.get("slot_colors", {}))
    if params.get("base"):
        generated = dispatch_color("build_palette", {
            "base": params["base"], "scheme": params.get("scheme", "analogous"),
            "size": int(params.get("size", 5)), "background": params.get("background"),
        })
        # A generated palette has no semantic labels. Map it to the Cozy material-role
        # order explicitly, preserving existing values for roles not overwritten.
        role_order = ("wall", "floor", "textile_main", "textile_accent", "wood", "light")
        for role, color in zip(role_order, generated.get("colors", [])):
            roles[role] = {"hex": color["hex"], "source": "Color Matrix build_palette",
                           "empathy": color.get("empathy"), "intensity": color.get("intensity")}
        for slot, role in primitives.SLOT_ROLE.items():
            if role in roles and isinstance(roles[role], dict) and "hex" in roles[role]:
                slot_colors[slot] = roles[role]["hex"]
        return {"palette": {"room": room, "scheme": generated.get("scheme"),
                             "base": generated.get("base"), "colors": generated.get("colors"),
                             "roles": roles, "provenance": generated.get("provenance")},
                "slot_colors": slot_colors, "validation": generated.get("check", {})}

    colors = [v["hex"] for v in roles.values() if isinstance(v, dict) and "hex" in v]
    validation = dispatch_color("check_palette", {
        "colors": colors, "min_delta_e": float(params.get("min_delta_e", 0.04))
    }) if len(colors) >= 2 else {"ok": True, "note": "No palette roles to validate"}
    return {"palette": {"room": room, "roles": roles,
                         "empirical_hints": atmosphere.get("empirical_color_hints", []),
                         "provenance": atmosphere.get("provenance")},
            "slot_colors": slot_colors, "validation": validation}
