"""Uroboros v0.2: patch-driven, file-backed iterative pipeline."""
from __future__ import annotations
import concurrent.futures as cf
import hashlib, importlib.util, json, os, threading, time, uuid
from pathlib import Path
from typing import Any, Callable

FORMAT = "uroboros.patch/2"


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(value if isinstance(value, bytes) else canonical(value)).hexdigest()


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text("utf-8"))
    except FileNotFoundError:
        return default


class PatchError(RuntimeError): pass


class FileMemory:
    """Append-only event journal + content-addressed blobs. No database server/SQLite."""
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.blobs = self.root / "blobs"
        self.cache = self.root / "cache"
        self.runs = self.root / "runs"
        self.pipeline_cache = self.root / "pipeline_cache"
        for p in (self.blobs, self.cache, self.runs, self.pipeline_cache): p.mkdir(parents=True, exist_ok=True)
        self.journal = self.root / "memory.jsonl"
        self._lock = threading.Lock()

    def put_blob(self, data: bytes) -> dict:
        key = digest(data); path = self.blobs / key[:2] / key
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            tmp = path.with_suffix(".tmp"); tmp.write_bytes(data); os.replace(tmp, path)
        return {"hash": key, "path": str(path.relative_to(self.root)), "size": len(data)}

    def get_blob(self, ref: dict) -> bytes:
        path = self.root / ref["path"]
        data = path.read_bytes()
        if digest(data) != ref["hash"]: raise PatchError(f"Blob checksum mismatch: {path}")
        return data

    def event(self, event: dict) -> None:
        line = canonical({"ts": time.time(), **event}) + b"\n"
        with self._lock:
            with self.journal.open("ab") as f:
                f.write(line); f.flush()

    def cache_get(self, key: str):
        path = self.cache / key[:2] / f"{key}.json"
        record = read_json(path)
        if not record: return None
        # Verify the cached output before reuse.
        for ref in record.get("blob_refs", []): self.get_blob(ref)
        return record

    def cache_put(self, key: str, record: dict) -> None:
        path = self.cache / key[:2] / f"{key}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp"); tmp.write_bytes(canonical(record)); os.replace(tmp, path)

    def save_run(self, run_id: str, record: dict) -> None:
        path = self.runs / f"{run_id}.json"
        tmp = path.with_suffix(".tmp"); tmp.write_bytes(canonical(record)); os.replace(tmp, path)

    def load_pipeline_trace(self, key: str):
        """Return all recorded runs for this pipeline fingerprint."""
        folder = self.pipeline_cache / key[:2] / key
        if not folder.exists(): return []
        return [read_json(p) for p in sorted(folder.glob("*.json"))]

    def save_pipeline_trace(self, key: str, run_id: str, record: dict) -> None:
        """Persist each complete pipeline experience; never overwrite prior runs."""
        folder = self.pipeline_cache / key[:2] / key
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{run_id}.json"
        tmp = path.with_suffix(".tmp"); tmp.write_bytes(canonical(record)); os.replace(tmp, path)


class PatchRegistry:
    """Loads trusted local Python patch scripts from a directory."""
    def __init__(self, folder: str | Path):
        self.folder = Path(folder); self.ops: dict[str, Callable] = {}; self.versions: dict[str, str] = {}
        self.reload()

    def reload(self):
        self.ops.clear(); self.versions.clear()
        for file in sorted(self.folder.glob("*.py")):
            if file.name.startswith("_"): continue
            spec = importlib.util.spec_from_file_location(f"uroboros_patch_{file.stem}", file)
            if not spec or not spec.loader: continue
            mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            name = getattr(mod, "OP", file.stem)
            fn = getattr(mod, "apply", None)
            if callable(fn):
                self.ops[name] = fn
                self.versions[name] = digest(file.read_bytes())

    def apply(self, name: str, context: dict, params: dict):
        if name not in self.ops: raise PatchError(f"Unknown patch operation: {name}")
        return self.ops[name](context, params)


class Uroboros:
    """One Patch format drives operation, feedback, approval and memory."""
    def __init__(self, root=".uroboros", patches="patches", glm_propose: Callable | None = None, workers=4,
                 runtime_fingerprint: str | None = None):
        self.memory = FileMemory(root)
        self.patches = PatchRegistry(patches)
        self.glm_propose = glm_propose  # Bind GLM-5.2 client here; API credentials/provider stay outside core.
        self.workers = max(1, int(workers))
        self.runtime_fingerprint = runtime_fingerprint or "unspecified-runtime"

    def make_patch(self, target: str, operation: str, inputs=None, params=None, **meta) -> dict:
        return {"format": FORMAT, "id": uuid.uuid4().hex, "parent": meta.get("parent"),
                "run": meta.get("run"), "iteration": meta.get("iteration", 0),
                "target": target, "operation": operation, "inputs": inputs or {},
                "params": params or {}, "outputs": {}, "status": "proposed",
                "approval": "pending", "metrics": {}, "memory": {}}

    def make_feedback(self, changes: dict, *, run=None, iteration=0, parent=None, reason="") -> dict:
        return {"format": FORMAT, "id": uuid.uuid4().hex, "parent": parent, "run": run,
                "iteration": iteration, "target": "uroboros", "operation": "feedback.apply",
                "inputs": {}, "params": {"changes": changes, "reason": reason},
                "outputs": {}, "status": "proposed", "approval": "pending", "metrics": {}, "memory": {}}

    def _execute_one(self, patch: dict, context: dict, run_id: str):
        op = patch["operation"]
        input_hash = digest({"inputs": patch["inputs"], "upstream": context.get("upstream", {})})
        key = digest({"target": patch["target"], "op": op, "script": self.patches.versions.get(op),
                      "runtime": self.runtime_fingerprint, "params": patch["params"], "input": input_hash})
        cached = self.memory.cache_get(key)
        if cached:
            outputs = cached["outputs"]
            patch["status"] = "cache_hit"; patch["memory"]["cache_key"] = key
            patch["metrics"] = {"cache_hit": True, "elapsed_ms": 0.0}
            return patch, outputs
        started = time.perf_counter()
        outputs = self.patches.apply(op, {**context, "inputs": patch["inputs"], "patch": patch}, patch["params"])
        elapsed = (time.perf_counter() - started) * 1000
        if not isinstance(outputs, dict): raise PatchError(f"{op} must return dict, got {type(outputs).__name__}")
        blob_refs = []
        # Large byte payloads are stored as blobs; small structured values stay in patch JSON.
        for k, v in list(outputs.items()):
            if isinstance(v, bytes):
                ref = self.memory.put_blob(v); outputs[k] = {"$blob": ref}; blob_refs.append(ref)
        patch["status"] = "executed"; patch["metrics"] = {"cache_hit": False, "elapsed_ms": round(elapsed, 4)}
        patch["memory"]["cache_key"] = key
        self.memory.cache_put(key, {"outputs": outputs, "blob_refs": blob_refs, "operation": op})
        return patch, outputs

    def run(self, plan: dict, *, max_iterations=4, require_approval=True, approval: Callable | None = None,
            feedback: Callable | None = None) -> dict:
        """Plan shape: {name, nodes:[{id,target,operation,params,needs:[node ids]}]}.
        feedback(previous_result, iteration) -> {node_id: {params: {...}}} or None.
        approval(result) -> bool. GLM can be used by passing feedback=self.glm_propose.
        """
        if plan.get("format", FORMAT) != FORMAT: raise PatchError("Unsupported patch format")
        run_id = uuid.uuid4().hex
        pipeline_key = digest({"plan": plan, "patch_versions": self.patches.versions,
                               "runtime_fingerprint": self.runtime_fingerprint})
        nodes = plan.get("nodes", [])
        ids = [n["id"] for n in nodes]
        if len(ids) != len(set(ids)): raise PatchError("Duplicate node id")
        known = set(ids)
        for n in nodes:
            if any(dep not in known for dep in n.get("needs", [])): raise PatchError(f"Unknown dependency in {n['id']}")
        run_started = time.perf_counter()
        state = {"format": FORMAT, "run": run_id, "name": plan.get("name", "untitled"), "status": "running",
                 "iterations": [], "approved": False, "final": None, "mental_checklist": [],
                 "metrics": {"cache_hits": 0, "cache_misses": 0, "btb_predictions": 0,
                             "btb_hits": 0, "prefetch_waste": None, "data_read_time_ms": None,
                             "transfer_time_ms": None, "processing_time_ms": 0.0,
                             "recalculation_ratio": 0.0, "cycle_count": 0,
                             "glm_context_size_bytes": 0}}
        params = {n["id"]: dict(n.get("params", {})) for n in nodes}
        previous = None
        for iteration in range(max_iterations):
            pending = {n["id"]: n for n in nodes}; done = {}; patches = []
            while pending:
                ready = [n for n in pending.values() if all(d in done for d in n.get("needs", []))]
                if not ready: raise PatchError("Pipeline contains a dependency cycle")
                # Independent nodes in one DAG layer may execute concurrently.
                def work(n):
                    patch = self.make_patch(n["target"], n["operation"], inputs={d: done[d] for d in n.get("needs", [])},
                                            params=params[n["id"]], run=run_id, iteration=iteration)
                    ctx = {"run": run_id, "iteration": iteration, "upstream": {d: done[d] for d in n.get("needs", [])},
                            "runtime_fingerprint": self.runtime_fingerprint}
                    return self._execute_one(patch, ctx, run_id)
                # Dependencies in a layer are already complete; each task sees only its own inputs.
                if len(ready) > 1 and self.workers > 1:
                    with cf.ThreadPoolExecutor(max_workers=min(self.workers, len(ready))) as pool:
                        results = list(pool.map(work, ready))
                else: results = [work(n) for n in ready]
                for n, (patch, output) in zip(ready, results):
                    done[n["id"]] = output; patch["outputs"] = output
                    patches.append(patch); del pending[n["id"]]
                    self.memory.event({"type": "patch", "run": run_id, "iteration": iteration, "patch": patch})
            result = {"outputs": done, "patches": patches}
            state["metrics"]["cache_hits"] += sum(p["status"] == "cache_hit" for p in patches)
            state["metrics"]["cache_misses"] += sum(p["status"] == "executed" for p in patches)
            state["metrics"]["processing_time_ms"] += sum(float(p.get("metrics", {}).get("elapsed_ms", 0)) for p in patches)
            state["metrics"]["cycle_count"] = iteration + 1
            state["metrics"]["recalculation_ratio"] = (state["metrics"]["cache_misses"] / max(1, state["metrics"]["cache_hits"] + state["metrics"]["cache_misses"]))
            checklist = self._checklist(result, iteration)
            state["mental_checklist"].append(checklist)
            iter_record = {"iteration": iteration, "result": result, "checklist": checklist, "feedback_proposal": None}
            state["iterations"].append(iter_record); previous = result
            # User approval is a hard commit gate. No generated result is silently treated as approved.
            if approval is not None:
                accepted = bool(approval(result))
            elif require_approval:
                accepted = False
            else:
                accepted = True
            if accepted:
                state.update(status="approved", approved=True, final=result)
                self.memory.event({"type": "approval", "run": run_id, "iteration": iteration, "approved": True})
                break
            if iteration == max_iterations - 1: break
            proposal = feedback(result, iteration) if feedback else (self.glm_propose(result, iteration) if self.glm_propose else None)
            iter_record["feedback_proposal"] = proposal
            self.memory.event({"type": "feedback", "run": run_id, "iteration": iteration, "proposal": proposal})
            if not proposal: break
            if proposal.get("format") != FORMAT or proposal.get("operation") != "feedback.apply":
                raise PatchError("Feedback must use the uroboros.patch/2 feedback.apply format")
            changes = proposal.get("params", {}).get("changes", {})
            for node_id, change in changes.items():
                if node_id not in params: raise PatchError(f"Feedback references unknown node: {node_id}")
                params[node_id].update(change.get("params", change))
            proposal["status"] = "applied"
            proposal["approval"] = "pending"
        if not state["approved"]:
            state["status"] = "awaiting_approval" if previous is not None else "failed"
            state["final"] = previous
        state["metrics"]["wall_time_ms"] = round((time.perf_counter() - run_started) * 1000, 4)
        state["metrics"]["cache_hit_rate"] = state["metrics"]["cache_hits"] / max(1, state["metrics"]["cache_hits"] + state["metrics"]["cache_misses"])
        state["metrics"]["glm_context_size_bytes"] = None  # exact provider token/context usage is not observable by core
        state["pipeline_cache_key"] = pipeline_key
        self.memory.save_run(run_id, state)
        self.memory.save_pipeline_trace(pipeline_key, run_id, state)
        self.memory.event({"type": "run_finished", "run": run_id, "status": state["status"],
                           "iterations": len(state["iterations"])})
        return state

    @staticmethod
    def _checklist(result: dict, iteration: int) -> dict:
        patches = result["patches"]
        return {"iteration": iteration, "all_operations_succeeded": all(p["status"] in ("executed", "cache_hit") for p in patches),
                "cache_hits": sum(p["status"] == "cache_hit" for p in patches),
                "execution_count": sum(p["status"] == "executed" for p in patches),
                "patch_ids": [p["id"] for p in patches],
                "approval_required": True,
                "notes": ["Record user rejection reasons and GLM corrections as feedback events in the next iteration."]}
