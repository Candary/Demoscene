"""Lazy, process-local adapters for the supplied Color Matrix and Cozy Engine."""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path
from functools import lru_cache

ROOT = Path(__file__).resolve().parents[1]
COLOR_ROOT = ROOT / "engines" / "color_matrix"
OUTPUT = COLOR_ROOT / "output"


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


@lru_cache(maxsize=1)
def toolboxes():
    # The original engine packages remain untouched; only their output directory is added.
    p = str(OUTPUT)
    if p not in sys.path:
        sys.path.insert(0, p)
    from color_matrix_python import FullRGBMatrixReader
    from color_matrix_python.tools import ColorToolbox
    from cozy_engine.tools import CozyToolbox

    matrix_path = OUTPUT / "color-matrix-full-rgb-v11.npz"
    data_dir = OUTPUT / "cozy_data"
    color = ColorToolbox(FullRGBMatrixReader(matrix_path))
    cozy = CozyToolbox.from_dir(data_dir, color)
    return color, cozy


def runtime_fingerprint() -> str:
    """Fingerprint engine code + datasets so stale cache entries cannot survive data changes."""
    paths = [
        OUTPUT / "color-matrix-full-rgb-v11.npz",
        OUTPUT / "cozy_data" / "cozy_matrix.npz",
        OUTPUT / "cozy_data" / "cozy_color_stats.json",
    ]
    code_dirs = [OUTPUT / "color_matrix_python", OUTPUT / "cozy_engine"]
    h = hashlib.sha256()
    for path in paths:
        h.update(path.name.encode())
        h.update(_sha(path).encode())
    for folder in code_dirs:
        for path in sorted(folder.glob("*.py")):
            h.update(str(path.relative_to(OUTPUT)).encode())
            h.update(_sha(path).encode())
    return h.hexdigest()


def dispatch_color(name: str, args: dict) -> dict:
    color, _ = toolboxes()
    result = color.dispatch(name, args)
    if "error" in result:
        raise ValueError(f"Color Matrix {name}: {result['error']}")
    return result


def dispatch_cozy(name: str, args: dict) -> dict:
    _, cozy = toolboxes()
    result = cozy.dispatch(name, args)
    if "error" in result:
        raise ValueError(f"Cozy Engine {name}: {result['error']}")
    return result
