"""File-backed BTB predictor. v0.4 ships in safe shadow mode by default."""
from __future__ import annotations
import json, time, hashlib
from pathlib import Path


def _key(signature: str) -> str: return hashlib.sha256(signature.encode()).hexdigest()

class BTB:
    def __init__(self, root: str | Path, *, mode: str = 'shadow', min_confidence: float = 0.75):
        if mode not in {'shadow','prefetch'}: raise ValueError('mode must be shadow or prefetch')
        self.root=Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.path=self.root/'btb_stats.json'; self.mode=mode; self.min_confidence=min_confidence
        self.data=json.loads(self.path.read_text('utf-8')) if self.path.exists() else {'version':1,'signatures':{}}
    def predict(self, signature: str, available_resources: dict | None = None) -> dict:
        rec=self.data['signatures'].get(_key(signature), {})
        resources=rec.get('resources', [])
        hits=int(rec.get('hits',0)); misses=int(rec.get('misses',0))
        confidence=hits/max(1,hits+misses)
        usable=bool(resources) and confidence >= self.min_confidence
        found={k:v for k,v in (available_resources or {}).items() if k in resources}
        missing=[x for x in resources if x not in found]
        return {'signature':signature,'resources':resources,'confidence':confidence,
                'eligible':usable,'prefetched':found if self.mode=='prefetch' and usable else {},
                'missing':missing,'mode':self.mode}
    def observe(self, signature: str, predicted: list[str], actually_used: list[str]):
        k=_key(signature); rec=self.data['signatures'].setdefault(k, {'signature':signature,'resources':[],'hits':0,'misses':0,'waste':0,'uses':0})
        pred=set(predicted); used=set(actually_used)
        if pred:
            if pred & used: rec['hits'] += 1
            else: rec['misses'] += 1
        rec['waste'] += len(pred-used); rec['uses'] += len(used)
        # Delta-only resource set: keep frequently used resources, discard never-used predictions.
        counts=rec.setdefault('resource_counts',{})
        for x in used: counts[x]=counts.get(x,0)+1
        rec['resources']=sorted(counts, key=lambda x:(-counts[x],x))[:32]
        rec['updated_at']=time.time(); self.flush()
    def flush(self):
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(self.data,ensure_ascii=False,sort_keys=True,indent=2),'utf-8'); tmp.replace(self.path)
    def stats(self):
        rows=list(self.data['signatures'].values()); total=sum(r['hits']+r['misses'] for r in rows)
        pred=sum(r['hits']+r['misses'] for r in rows)
        hits=sum(r['hits'] for r in rows); misses=sum(r['misses'] for r in rows)
        waste=sum(r['waste'] for r in rows); uses=sum(r['uses'] for r in rows)
        return {'signatures':len(rows),'predictions':pred,'hits':hits,'misses':misses,
                'wasted_resources':waste,'btb_hit_rate':hits/max(1,total),
                'prefetch_waste':waste/max(1,uses+waste)}
