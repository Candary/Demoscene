"""Unified Data Exchange envelope and in-process router."""
from __future__ import annotations
import time, uuid
from typing import Callable

PROTOCOL = 'uroboros.exchange/1'
MESSAGE_TYPES = {'REQUEST','RESPONSE','FEEDBACK','PREFETCH','EVENT'}

class ExchangeError(ValueError): pass


def envelope(source: str, target: str, message_type: str, payload: dict, *,
             correlation_id: str | None = None, operation: str | None = None,
             metadata: dict | None = None) -> dict:
    if message_type not in MESSAGE_TYPES: raise ExchangeError(f'Invalid message_type: {message_type}')
    if not source or not target or not isinstance(payload, dict): raise ExchangeError('source, target and object payload are required')
    return {'protocol': PROTOCOL, 'message_id': uuid.uuid4().hex,
            'correlation_id': correlation_id or uuid.uuid4().hex,
            'message_type': message_type, 'source': source, 'target': target,
            'operation': operation, 'created_at': time.time(), 'payload': payload,
            'metadata': metadata or {}}


class Router:
    def __init__(self): self._handlers: dict[str, Callable] = {}
    def register(self, name: str, handler: Callable):
        if not name or not callable(handler): raise ExchangeError('Invalid handler')
        self._handlers[name] = handler
    def dispatch(self, message: dict) -> dict:
        if message.get('protocol') != PROTOCOL: raise ExchangeError('Unsupported protocol')
        if message.get('message_type') not in MESSAGE_TYPES: raise ExchangeError('Invalid message type')
        target = message.get('target')
        if target not in self._handlers: raise ExchangeError(f'No handler registered for {target}')
        result = self._handlers[target](message['payload'], message)
        if not isinstance(result, dict): raise ExchangeError('Handler must return dict')
        return envelope(target, message['source'], 'RESPONSE', result,
                        correlation_id=message['correlation_id'], operation=message.get('operation'))
