# `examples/engine.py`

Drop-in шим для обратной совместимости со старым `engine.py` (v0.2).

## Установка в свой проект

Скопировать в корень проекта рядом с `patches/`:

```bash
cp examples/engine.py /path/to/your-project/engine.py
```

После этого старый код продолжает работать без изменений:

```python
from engine import Uroboros, FORMAT, read_json, PatchError
```

## Проверка

Запустить прямо из файла:

```bash
python examples/engine.py
```

Вывод при успехе:

```
engine shim: FORMAT = 'uroboros.patch/2'
engine shim: canonical/digest ok
engine shim: FileMemory ok  (root=/tmp/...)
engine shim: PatchRegistry ok (6 op(s) from /.../patches)
engine shim: Uroboros.run ok  (status=approved)
engine shim: all checks passed
```

Шаги проверки деградируют, если рядом нет `patches/` — файл не падает, а сообщает, что пропущено.

## Отслеживание оставшихся пользователей старого API

```bash
# Мягко: предупреждение в stderr при импорте
UROBOROS_SHIM_WARN=1 pytest

# Жёстко: падать на любом `import engine`
UROBOROS_SHIM_WARN=1 PYTHONWARNINGS=error::DeprecationWarning pytest
```

## Когда удалять

1. Установить `uroboros` (`pip install -e .`).
2. Запустить миграцию импортов:

   ```bash
   python scripts/migrate_v0_2_to_v0_3.py --target . --apply --backup
   ```

3. Проверить, что ничего не осталось:

   ```bash
   python scripts/migrate_v0_2_to_v0_3.py --target . --check
   # exit 0 — миграция завершена
   ```

4. Удалить `engine.py` из проекта. Резервные `<file>.py.bak` — тоже.

## Что не покрыто

- `from engine import *` — `__all__` есть, звёздочный импорт работает, но новых имён (`simple_room_plan`, `full_plan`, ...) через шим не появится. Импортируйте их прямо из `uroboros`.
- Внутренние атрибуты (`engine._warn`, `engine._self_check`) — не публичный контракт, могут меняться.
- `engine.Path`, `engine.Any` — старый модуль их импортировал, но наружу это не API. Если ваш код на них завязан, поправьте на `from pathlib import Path` / `from typing import Any`.